<?php
/**
 * 系统入口
 * 		1 ) 读取配置
 * 		2 ) 设定调试级别
 * 		3 ) 负责调用App
 */
define('APP_FILENAME', isset($_SERVER['SCRIPT_NAME']) ? $_SERVER['SCRIPT_NAME'] : (isset($argv[0]) ? $argv[0] : ''));
$dir = dirname(__FILE__);
$appConfig = include $dir.'/config/adminConfig.php';
//$appConfig = include $dir.'/config/localAppConfig.php';
include $dir.'/core/Mm.php';
Mm::setConfig($appConfig);
Mm::run();