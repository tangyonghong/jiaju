<?php
/**
 * 接口应用类
 * @author mmfei
 */
class ApiApp extends MmServerBase
{
	private static $memcached = null;
	/**
	 * 接口入口 api , action
	 */
	public static function run()
	{
		$api = MmHtml::PG('api');
		$action = MmHtml::PG('action'); 
		$returnType = MmHtml::PG('returnType',0); 
		if(empty($api) || empty($action))
		{
			return self::returnError("argument error![api , action]");
		}
		try
		{
			$return = self::callApi($api, $action, array());
			return self::returnSuccess($return , 0 , $returnType);
		}
		catch(Exception $e)
		{
			if($e instanceof ApiException)
				return self::returnError($e->getMessage() , $e->getCode() , $returnType);
			else
				throw $e;
		}
		
	}
	/**
	 * 调用api
	 * @param string $api
	 * @param string $function
	 * @param array $args
	 * @return mixed
	 */
	public static function callApi($api , $function , $args)
	{
		$class = ucfirst($api)."Api";
		$function .= "Action";
		$file = MM_APP_ROOT . "/apis/".$class.".php";
		MmImport::addMap($class, $file);
		if(file_exists($file))
			$return = call_user_func_array(array($class,$function), $args);
		else
			throw new ApiException("Api action does not exists!");
		return $return;
	}
	/**
	 * 失败返回
	 * @param mixed $data
	 * @param integer $code
	 * @param integer $returnType	(0:json,1:xml)
	 * @return void
	 */
	public static function returnError($data , $code = -1 , $returnType = 0)
	{
		//{ "code":0, "info":"OK", "data":"xxxxxxxxxxxxxxxxxxxxxxxxxx" }
		$result = array(
			'code' 		=> $code,
			'result' 	=> 0,
			'data' 		=> $data,
		);
		echo self::_returnType($result , $returnType);
	}
	/**
	 * 返回成功
	 * @param mixed $data
	 * @param integer $code
	 * @param integer $returnType	(0:json,1:xml)
	 * @return void
	 */
	public static function returnSuccess($data , $code = 0 , $returnType = 0)
	{
		$result = array(
			'code' 		=> $code,
			'result' 	=> 1,
			'data' 		=> $data,
		);
		echo self::_returnType($result , $returnType);
	}
	/**
	 * 返回格式
	 * @param mixed $return
	 * @param integer $returnType
	 * @return string
	 */
	private static function _returnType($return , $returnType = 0)
	{
		if($returnType == 1)
			return self::xmlize($return,'result');
		return json_encode($return);
	}
	/**
	 * Convert array to xml tree
	 *
	 * @param array $array
	 * @param string $root
	 * @return string
	 */
	private static function xmlize($array , $root = 'root') {
		header('Content-Type: text/xml');
		$xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<$root>";
		$xml .= self::_xmlize ( $array );
		$xml .= "\n</$root>";
		return $xml;
	}
	private static function _xmlize($array , $deep = 0) {
		$string = "";
		$front = str_pad("\t", $deep);
		foreach ( $array as $key => $value ) {
			$stag = is_numeric ( $key ) ? "item id=\"$key\"" : $key;
			$etag = is_numeric ( $key ) ? "item" : $key;
			if (is_array ( $value )) {
				$string .= "\n{$front}<" . $stag . ">" . self::_xmlize ( $value , $deep + 1) . "</{$etag}>";
			} else {
				$string .= "\n{$front}<" . $stag . ">" . $value . "</{$etag}>";
			}
		}
		return $string;
	}
	/**
	 * 获取memcached实例
	 * @return Memcached
	 */
	public static function getMemcached()
	{
		if(self::$memcached) return self::$memcached;
		$config = include MM_ROOT."/config/memcachedConfig.php";
		$serverList = $config['memcachedServerList'];
		$serverOptionsList = $config['memcachedServerOptions'];
		if($serverList)
		{
			self::$memcached = MmMemcached::getMemcached($serverList , $serverOptionsList?$serverOptionsList:array());
			return self::$memcached;
		}
	}
}
