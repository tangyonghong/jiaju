<?php
/**
 * 获取允许ip列表
 * @author mmfei
 */
class ApiIpAllowsDAL
{
	const KEY = 'api_allow_ip_list';
	/**
	 * 获取ip列表
	 * @return array(
	 * 		127.0.0.1,
	 * 		127.0.0.1,
	 * 		127.0.0.1,
	 * 		...
	 * )
	 */
	public static function getIpList()
	{
		$data = ApiApp::getMemcached()->get(self::KEY);
		if($data)
		{
			return $data;
		}
		$data = include MM_ROOT.'/config/allowIpConfig.php';
		ApiApp::getMemcached()->set(self::KEY , $data , 7 * 86400);
		return $data;
	}
	/**
	 * 删除缓存
	 * @return boolean
	 */
	public static function deleteCache()
	{
		return ApiApp::getMemcached()->delete(self::KEY);
	}
}