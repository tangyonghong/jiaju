<?php
/**
 * 数据库操作类
 *
 */
class LogSongDAL extends MmActiveRecordExt
{
	/**
	 * 获取主键 , 目前只支持单主键
	 * @return string
	 */
	public function _getPrimaryKey()
	{
		return 'autoId';
	}
	/**
	 * 字段属性规则,每个字段都必须定义
	 * @return array
	 */
	public function rules()
	{
		return array(
			'autoId' => array(
				'label' => '',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
				'autoIncrement' => '1',
				'table' => array(
					'name' => 'AutoDAL',//类名
					'keyField'=>'autoId',//主键名称
					'valueField' => 'autoName',//记录名称
				), //表,字段名首字母大写，name表示类名称
			),
			'hash' => array(
				'label' => '歌曲hash',
				'type' => 'textarea',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'songName' => array(
				'label' => '歌曲的名称',
				'type' => 'textarea',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'bitRate' => array(
				'label' => '歌曲的比特率',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'mac' => array(
				'label' => '设备mac地址',
				'type' => 'textarea',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'srcType' => array(
				'label' => '歌曲来源',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'userId' => array(
				'label' => '用户Id',
				'type' => 'text',
				'value' => '0',
				'valueList' => array(), //数值范围
				'table' => array(
					'name' => 'UserDAL',//类名
					'keyField'=>'userId',//主键名称
					'valueField' => 'userName',//记录名称
				), //表,字段名首字母大写，name表示类名称
			),
			'ver' => array(
				'label' => '当前版本号',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'OSver' => array(
				'label' => '系统版本',
				'type' => 'textarea',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'Ip' => array(
				'label' => 'ip地址',
				'type' => 'textarea',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'addTime' => array(
				'label' => '添加时间',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
		);
// 			'ColumnName' => array(
// 				'Label'=>'名称',
// 				'Type'=>'(Text|Label|Password|Checkbox|Select|Radio|Html|TextArea|File|Date)',
// 				'Range'=>array('RangValue' => 'Text',...,),
// 				'IsRangeMulti' => false,
// 				'Table'=>array('TableName'=>'表名','EqualColumn'=>'数值对应的列','NameColumn'=>'显示的列',),
// 			),
// 			...
	}
	/**
	 * 列表规则
	 * @return array
	 */
	public function listRules()
	{
	
	}
	/**
	 * 类名
	 * @return string
	 */
	public function _getClass()
	{
		return __CLASS__;
	}
	/**
	 * 获取表
	 * @return string
	 */
	public function _getTable()
	{
		$month=$tmp_date=date("m");
		return 't_log_song'.$month;
	}
}