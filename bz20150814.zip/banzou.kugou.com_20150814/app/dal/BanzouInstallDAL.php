<?php
/**
 * 数据库操作类
 *
 */
class BanzouInstallDAL extends MmActiveRecordExt
{
	/**
	 * 获取主键 , 目前只支持单主键
	 * @return string
	 */
	public function _getPrimaryKey()
	{
		return 'mac';
	}
	/**
	 * 字段属性规则,每个字段都必须定义
	 * @return array
	 */
	public function rules()
	{
		return array(
			'mac' => array(
				'label' => '自增主键',
				'type' => 'textarea',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'date' => array(
				'label' => '日期',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'ver' => array(
				'label' => '版本号',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
		);
	}
	/**
	 * 列表规则
	 * @return array
	 */
	public function listRules()
	{
	
	}
	/**
	 * 类名
	 * @return string
	 */
	public function _getClass()
	{
		return __CLASS__;
	}
	/**
	 * 获取表
	 * @return string
	 */
	public function _getTable()
	{
		return 't_banzou_install';
	}
	
	/**
	 * 
	 * 获得该版本现在的人数
	 * @param $ver 版本号
	 */
	public function getNumber($ver,$date)
	{
		if($ver != 0)
			$sql = "SELECT COUNT(*) AS count FROM ".self::_getTable()." WHERE ver=".$ver." AND date<='".$date."'";
		else 
			$sql = "SELECT COUNT(*) AS count FROM ".self::_getTable()." WHERE date<='".$date."'";
//		echo $sql;
		return MmMySqlPdo::query($sql);
	}
	
}