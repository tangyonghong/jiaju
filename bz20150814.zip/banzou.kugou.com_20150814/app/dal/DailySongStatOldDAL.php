<?php
/**
 * 数据库操作类
 *
 */
class DailySongStatOldDAL extends MmActiveRecordExt
{
	/**
	 * 获取主键 , 目前只支持单主键
	 * @return string
	 */
	public function _getPrimaryKey()
	{
		return 'hash';
	}
	/**
	 * 字段属性规则,每个字段都必须定义
	 * @return array
	 */
	public function rules()
	{
		return array(
			'hash' => array(
				'label' => '歌曲哈希',
				'type' => 'textarea',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'songName' => array(
				'label' => '歌曲名',
				'type' => 'textarea',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'rank' => array(
				'label' => '当前排名',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'upRank' => array(
				'label' => '增加的排名',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'dailyCount' => array(
				'label' => '日播放量',
				'type' => 'text',
				'value' => '0',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'addTime' => array(
				'label' => '数据更新时间',
				'type' => 'text',
				'value' => '0',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
		);
// 			'ColumnName' => array(
// 				'Label'=>'名称',
// 				'Type'=>'(Text|Label|Password|Checkbox|Select|Radio|Html|TextArea|File|Date)',
// 				'Range'=>array('RangValue' => 'Text',...,),
// 				'IsRangeMulti' => false,
// 				'Table'=>array('TableName'=>'表名','EqualColumn'=>'数值对应的列','NameColumn'=>'显示的列',),
// 			),
// 			...
	}
	/**
	 * 列表规则
	 * @return array
	 */
	public function listRules()
	{
	
	}
	/**
	 * 类名
	 * @return string
	 */
	public function _getClass()
	{
		return __CLASS__;
	}
	/**
	 * 获取表
	 * @return string
	 */
	public function _getTable()
	{
		return 't_daily_song_stat_old';
	}
}