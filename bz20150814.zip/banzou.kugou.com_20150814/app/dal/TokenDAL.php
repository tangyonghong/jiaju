<?php
/**
 * 数据库操作类
 *
 */
class TokenDAL extends MmActiveRecordExt
{
	/**
	 * 获取主键 , 目前只支持单主键
	 * @return string
	 */
	public function _getPrimaryKey()
	{
		return 'tokenId';
	}
	/**
	 * 字段属性规则,每个字段都必须定义
	 * @return array
	 */
	public function rules()
	{
		return array(
			'tokenId' => array(
				'label' => 'tokenID',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
				'autoIncrement' => '1',
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'tokenKey' => array(
				'label' => '令牌',
				'type' => 'textarea',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'addTime' => array(
				'label' => '添加时间',
				'type' => 'text',
				'value' => '0',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'tokenAppId' => array(
				'label' => '应用ID',
				'type' => 'text',
				'value' => '0',
				'valueList' => array(), //数值范围
				'table' => array(
					'name' => 'TokenAppDAL',//类名
					'keyField'=>'tokenAppId',//主键名称
					'valueField' => 'tokenAppName',//记录名称
				), //表,字段名首字母大写，name表示类名称
			),
			'usedCount' => array(
				'label' => '使用次数',
				'type' => 'text',
				'value' => '0',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'createIp' => array(
				'label' => '创建ip',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'expire' => array(
				'label' => '过期时间[s]',
				'type' => 'text',
				'value' => '300',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'digest' => array(
				'label' => '数字摘要',
				'type' => 'textarea',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'extData' => array(
				'label' => '扩展数据',
				'type' => 'textarea',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
		);
// 			'ColumnName' => array(
// 				'Label'=>'名称',
// 				'Type'=>'(Text|Label|Password|Checkbox|Select|Radio|Html|TextArea|File|Date)',
// 				'Range'=>array('RangValue' => 'Text',...,),
// 				'IsRangeMulti' => false,
// 				'Table'=>array('TableName'=>'表名','EqualColumn'=>'数值对应的列','NameColumn'=>'显示的列',),
// 			),
// 			...
	}
	/**
	 * 列表规则
	 * @return array
	 */
	public function listRules()
	{
	
	}
	/**
	 * 类名
	 * @return string
	 */
	public function _getClass()
	{
		return __CLASS__;
	}
	/**
	 * 获取表
	 * @return string
	 */
	public function _getTable()
	{
		return 't_token';
	}
}