<?php
/**
 * 数据库操作类
 * 伴奏管理
 */
class VerManageDAL extends MmActiveRecordExt
{
	/**
	 * 升级类型 : 提示升级
	 * @var integer
	 */
	const TYPE_0 = '0';
	/**
	 * 升级类型 : 强制升级
	 * @var integer
	 */
	const TYPE_1 = '1';
	/**
	 * 发布状态 : 不发布
	 * @var integer
	 */
	const STATUS_0 = '0';
	/**
	 * 发布状态 : 当前发布
	 * @var integer
	 */
	const STATUS_1 = '1';
	/**
	 * 获取主键 , 目前只支持单主键
	 * @return string
	 */
	public function _getPrimaryKey()
	{
		return 'ver';
	}
	/**
	 * 字段属性规则,每个字段都必须定义
	 * @return array
	 */
	public function rules()
	{
		return array(
			'ver' => array(
				'label' => '版本号',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'name' => array(
				'label' => '版本名',
				'type' => 'textarea',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'type' => array(
				'label' => '升级类型',
				'type' => 'radio',
				'value' => '',
				'valueList' => array(
					'0' => '提示升级',
					'1' => '强制升级',
					'2' => '不提示升级',
				), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'describe' => array(
				'label' => '版本描述',
				'type' => 'textarea',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'url' => array(
				'label' => '文件地址',
				'type' => 'textarea',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'status' => array(
				'label' => '发布状态',
				'type' => 'radio',
				'value' => '',
				'valueList' => array(
					'0' => '不发布',
					'1' => '当前发布',
				), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'mustUpVer' => array(
				'label' => '必须强制升级版本',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'auurl' => array(
				'label' => '自动升级的主程序安装包下载地址',
				'type' => 'textarea',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'aufilesize' => array(
				'label' => '自动升级的主程序安装包文件大小',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'tpver' => array(
				'label' => '第三方库安装包版本',
				'type' => 'textarea',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'tpurl' => array(
				'label' => '第三方库安装包下载地址',
				'type' => 'textarea',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'tpfilesize' => array(
				'label' => '第三方库安装包文件大小',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'upNum' => array(
				'label' => '灰度升级比例',
				'type' => 'textarea',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'addTime' => array(
				'label' => '添加时间',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
		);
// 			'ColumnName' => array(
// 				'Label'=>'名称',
// 				'Type'=>'(Text|Label|Password|Checkbox|Select|Radio|Html|TextArea|File|Date)',
// 				'Range'=>array('RangValue' => 'Text',...,),
// 				'IsRangeMulti' => false,
// 				'Table'=>array('TableName'=>'表名','EqualColumn'=>'数值对应的列','NameColumn'=>'显示的列',),
// 			),
// 			...
	}
	/**
	 * 列表规则
	 * @return array
	 */
	public function listRules()
	{
	
	}
	/**
	 * 类名
	 * @return string
	 */
	public function _getClass()
	{
		return __CLASS__;
	}
	/**
	 * 获取表
	 * @return string
	 */
	public function _getTable()
	{
		return 't_ver_manage';
	}
	
/**
	 * 获得提示的最新的版本
	 */
	public function getPrompt()
	{
		$sql = "SELECT * FROM t_ver_manage WHERE type=0 AND status=1 ORDER BY addTime desc";
		return MmMySqlPdo::query($sql);
	}
	
	/**
	 * 获得上次强制升级版本不为0的
	 */
	public function getLastMustUp()
	{
		$sql = "SELECT * FROM t_ver_manage WHERE mustUpVer>0 ORDER BY addTime desc limit 1";
		return MmMySqlPdo::query($sql);
	}
}