<?php
/**
 * 数据库操作类
 *
 */
class BanzouStatisticsDAL extends MmActiveRecordExt
{
	/**
	 * 获取主键 , 目前只支持单主键
	 * @return string
	 */
	public function _getPrimaryKey()
	{
		return 'autoId';
	}
	/**
	 * 字段属性规则,每个字段都必须定义
	 * @return array
	 */
	public function rules()
	{
		return array(
			'autoId' => array(
				'label' => '自增主键',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'date' => array(
				'label' => '日期',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'ver' => array(
				'label' => '版本号',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'newUser' => array(
				'label' => '新用户数',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'installNum' => array(
				'label' => '安装数',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'startNum' => array(
				'label' => '启动数',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'startUser' => array(
				'label' => '启动人数',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'uninstallUser' => array(
				'label' => '卸载人数',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'searchNum' => array(
				'label' => '搜索次数',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'searchUser' => array(
				'label' => '搜索人数',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'playNum' => array(
				'label' => '播放次数',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'playUser' => array(
				'label' => '播放人数',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'crashNum' => array(
				'label' => '崩溃次数',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'videoStartNum' => array(
				'label' => '视频启用次数',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'videoStartUser' => array(
				'label' => '视频启用人数',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			
		);
// 			'ColumnName' => array(
// 				'Label'=>'名称',
// 				'Type'=>'(Text|Label|Password|Checkbox|Select|Radio|Html|TextArea|File|Date)',
// 				'Range'=>array('RangValue' => 'Text',...,),
// 				'IsRangeMulti' => false,
// 				'Table'=>array('TableName'=>'表名','EqualColumn'=>'数值对应的列','NameColumn'=>'显示的列',),
// 			),
// 			...
	}
	/**
	 * 列表规则
	 * @return array
	 */
	public function listRules()
	{
	
	}
	/**
	 * 类名
	 * @return string
	 */
	public function _getClass()
	{
		return __CLASS__;
	}
	/**
	 * 获取表
	 * @return string
	 */
	public function _getTable()
	{
		return 't_banzou_diary';
	}
	
	/**
	 * 获取ver版本在start到end时间段的每日统计数据
	 * @param unknown_type $ver
	 * @param unknown_type $start
	 * @param unknown_type $end
	 */
	public function getStatistics($ver,$start,$end)
	{
		$sql = "SELECT date,ver,newUser,historyUser,installNum,startNum,startUser,uninstallUser,uninstallNum,searchNum,searchUser,playNum,playUser,crashNum,crashUser,videoStartNum,videoStartUser FROM ".self::_getTable()." WHERE ver='".$ver."' AND date>='".$start."' AND date<='".$end."'";
		return MmMySqlPdo::query($sql);
	}
	/**
	 * 获得数据库中所有的版本
	 */
	public function getVers()
	{
		$sql = "SELECT DISTINCT ver FROM ".self::_getTable();
		return MmMySqlPdo::query($sql);
	}
}