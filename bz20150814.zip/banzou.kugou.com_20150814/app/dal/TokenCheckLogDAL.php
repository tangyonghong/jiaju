<?php
/**
 * 数据库操作类
 *
 */
class TokenCheckLogDAL extends MmActiveRecordExt
{
	/**
	 * 获取主键 , 目前只支持单主键
	 * @return string
	 */
	public function _getPrimaryKey()
	{
		return 'autoId';
	}
	/**
	 * 字段属性规则,每个字段都必须定义
	 * @return array
	 */
	public function rules()
	{
		return array(
			'autoId' => array(
				'label' => '自增ID',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
				'autoIncrement' => '1',
				'table' => array(
					'name' => 'AutoDAL',//类名
					'keyField'=>'autoId',//主键名称
					'valueField' => 'autoName',//记录名称
				), //表,字段名首字母大写，name表示类名称
			),
			'tokenId' => array(
				'label' => 'tokenID',
				'type' => 'text',
				'value' => '0',
				'valueList' => array(), //数值范围
				'table' => array(
					'name' => 'TokenDAL',//类名
					'keyField'=>'tokenId',//主键名称
					'valueField' => 'tokenName',//记录名称
				), //表,字段名首字母大写，name表示类名称
			),
			'addTime' => array(
				'label' => '添加时间',
				'type' => 'text',
				'value' => '0',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'ip' => array(
				'label' => '获取ip',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
		);
// 			'ColumnName' => array(
// 				'Label'=>'名称',
// 				'Type'=>'(Text|Label|Password|Checkbox|Select|Radio|Html|TextArea|File|Date)',
// 				'Range'=>array('RangValue' => 'Text',...,),
// 				'IsRangeMulti' => false,
// 				'Table'=>array('TableName'=>'表名','EqualColumn'=>'数值对应的列','NameColumn'=>'显示的列',),
// 			),
// 			...
	}
	/**
	 * 列表规则
	 * @return array
	 */
	public function listRules()
	{
	
	}
	/**
	 * 类名
	 * @return string
	 */
	public function _getClass()
	{
		return __CLASS__;
	}
	/**
	 * 获取表
	 * @return string
	 */
	public function _getTable()
	{
		return 't_token_check_log';
	}
}