<?php
/**
 * 将用户行为输出到日志
 * @author chenxiaochen
 *
 */
class LogBehaviorDAL{
	
	/**
	 * 
	 * 输出到文件中
	 * @param $data
	 */
	public function insert($data)
	{
		if($data['type']==0)
		{
			//繁星伴奏的行为日志
			$filename = Mm::getByKey("behaviorLogPath")."/".Mm::getByKey("banzou_pre").date("Y-m-d");
		}
		else 
		{
			//繁星客户端的行为日志
			$filename = Mm::getByKey("behaviorLogPath")."/".Mm::getByKey("client_pre").date("Y-m-d");		
		}
		$file = fopen($filename, 'a+');
		$towrite = date("H:i:s").'|'.$data["id"].'|'.$data["mac"].'|'.$data["ver"].'|'.$data["osVer"].'|'.$data['ip'].'|'."\r\n";
		fwrite($file, $towrite);
		fclose($file);
	}
	/**
	 * 输出到高清插件的日志文件
	 */
	public function insertHifi($data)
	{
		//高清插件的行为日志
		$filename = Mm::getByKey("behaviorLogPath")."/".Mm::getByKey("hifi_pre").date("Y-m-d");	
		$file = fopen($filename, 'a+');
		$towrite = date("Y-m-d H:i:s").'|'.$data["id"].'|'.$data["mac"].'|'.$data["ver"].'|'.$data["osVer"].'|'.$data['ip'].'|'.$data['roomId'].'|'.$data['userId'].'|'.$data['Info'].'|'."\r\n";
		fwrite($file, $towrite);
		fclose($file);
	}
	
	/**
	 * 用户的一些日常的功能使用记录到文件中
	 */
	public function insertFunc($id,$mac,$ver,$osVer,$value,$info,$ip)
	{
		$filename = Mm::getByKey("behaviorLogPath")."/".Mm::getByKey("func_pre").date("Y-m-d");	
		$file = fopen($filename, 'a+');
		$towrite = date("H:i:s").'|'.$id.'|'.$mac.'|'.$ver.'|'.$osVer.'|'.$ip.'|'.$value.'|'.$info.'|'."\r\n";
		fwrite($file, $towrite);
		fclose($file);
	}

}