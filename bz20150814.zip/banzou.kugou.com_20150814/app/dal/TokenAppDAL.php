<?php
/**
 * 数据库操作类
 *
 */
class TokenAppDAL extends MmActiveRecordExt
{
	/**
	 * 激活 : 是
	 * @var integer
	 */
	const IS_ACTIVED_1 = '1';
	/**
	 * 激活 : 否
	 * @var integer
	 */
	const IS_ACTIVED_0 = '0';
	/**
	 * 获取主键 , 目前只支持单主键
	 * @return string
	 */
	public function _getPrimaryKey()
	{
		return 'tokenAppId';
	}
	/**
	 * 字段属性规则,每个字段都必须定义
	 * @return array
	 */
	public function rules()
	{
		return array(
			'tokenAppId' => array(
				'label' => '应用ID',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
				'autoIncrement' => '1',
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'tokenAppName' => array(
				'label' => '应用名称',
				'type' => 'textarea',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'isActived' => array(
				'label' => '激活',
				'type' => 'radio',
				'value' => '1',
				'valueList' => array(
					'1' => '是',
					'0' => '否',
				), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'addTime' => array(
				'label' => '添加时间',
				'type' => 'text',
				'value' => '0',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'password' => array(
				'label' => '密码',
				'type' => 'textarea',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'pwdRule' => array(
				'label' => '加密规则',
				'type' => 'textarea',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
		);
// 			'ColumnName' => array(
// 				'Label'=>'名称',
// 				'Type'=>'(Text|Label|Password|Checkbox|Select|Radio|Html|TextArea|File|Date)',
// 				'Range'=>array('RangValue' => 'Text',...,),
// 				'IsRangeMulti' => false,
// 				'Table'=>array('TableName'=>'表名','EqualColumn'=>'数值对应的列','NameColumn'=>'显示的列',),
// 			),
// 			...
	}
	/**
	 * 列表规则
	 * @return array
	 */
	public function listRules()
	{
	
	}
	/**
	 * 类名
	 * @return string
	 */
	public function _getClass()
	{
		return __CLASS__;
	}
	/**
	 * 获取表
	 * @return string
	 */
	public function _getTable()
	{
		return 't_token_app';
	}
}