<?php
/**
 * 数据库操作类
 *
 */
class AdminDAL extends MmActiveRecordExt
{
	/**
	 * 获取主键 , 目前只支持单主键
	 * @return string
	 */
	public function _getPrimaryKey()
	{
		return 'adminId';
	}
	/**
	 * 字段属性规则,每个字段都必须定义
	 * @return array
	 */
	public function rules()
	{
		return array(
			'adminId' => array(
				'label' => '自增ID',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
				'autoIncrement' => '1',
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'adminName' => array(
				'label' => '用户名',
				'type' => 'textarea',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'password' => array(
				'label' => '密码',
				'type' => 'textarea',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'isSuper' => array(
				'label' => '是否超级管理员',
				'type' => 'radio',
				'value' => '0',
				'valueList' => array(
					'0' => '否',
					'1' => '是',
				), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'isActivited' => array(
				'label' => '是否激活',
				'type' => 'radio',
				'value' => '1',
				'valueList' => array(
					'0' => '否',
					'1' => '是',
				), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
		);
// 			'ColumnName' => array(
// 				'Label'=>'名称',
// 				'Type'=>'(Text|Label|Password|Checkbox|Select|Radio|Html|TextArea|File|Date)',
// 				'Range'=>array('RangValue' => 'Text',...,),
// 				'IsRangeMulti' => false,
// 				'Table'=>array('TableName'=>'表名','EqualColumn'=>'数值对应的列','NameColumn'=>'显示的列',),
// 			),
// 			...
	}
	/**
	 * 列表规则
	 * @return array
	 */
	public function listRules()
	{
	
	}
	/**
	 * 类名
	 * @return string
	 */
	public function _getClass()
	{
		return __CLASS__;
	}
	/**
	 * 获取表
	 * @return string
	 */
	public function _getTable()
	{
		return 't_admin';
	}
}