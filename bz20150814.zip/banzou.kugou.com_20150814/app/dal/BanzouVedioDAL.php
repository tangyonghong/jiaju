<?php
/**
 * 数据库操作类
 *
 */
class BanzouVedioDAL extends MmActiveRecordExt
{
	/**
	 * 获取主键 , 目前只支持单主键
	 * @return string
	 */
	public function _getPrimaryKey()
	{
		return 'id';
	}
	/**
	 * 字段属性规则,每个字段都必须定义
	 * @return array
	 */
	public function rules()
	{
		return array(
			'id' => array(
				'label' => '自增主键',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'date' => array(
				'label' => '日期',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'ver' => array(
				'label' => '版本号',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'h1user' => array(
				'label' => '高清模式-一般严重人数',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'h1num' => array(
				'label' => '高清模式-一般严重次数',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'h2user' => array(
				'label' => '高清模式-特别严重人数',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'h2num' => array(
				'label' => '高清模式-特别严重次数',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'nuser' => array(
				'label' => '普通模式人数',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'nnum' => array(
				'label' => '普通模式次数',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			
		);
// 			'ColumnName' => array(
// 				'Label'=>'名称',
// 				'Type'=>'(Text|Label|Password|Checkbox|Select|Radio|Html|TextArea|File|Date)',
// 				'Range'=>array('RangValue' => 'Text',...,),
// 				'IsRangeMulti' => false,
// 				'Table'=>array('TableName'=>'表名','EqualColumn'=>'数值对应的列','NameColumn'=>'显示的列',),
// 			),
// 			...
	}
	/**
	 * 列表规则
	 * @return array
	 */
	public function listRules()
	{
	
	}
	/**
	 * 类名
	 * @return string
	 */
	public function _getClass()
	{
		return __CLASS__;
	}
	/**
	 * 获取表
	 * @return string
	 */
	public function _getTable()
	{
		return 't_banzou_vedio';
	}
	
	/**
	 * 获取版本在start到end时间段的每日统计数据
	 * @param unknown_type $ver
	 * @param unknown_type $start
	 * @param unknown_type $end
	 */
	public function getStatistics($ver,$start,$end)
	{
		$sql = "SELECT * FROM ".self::_getTable()." WHERE ver='".$ver."' AND date>='".$start."' AND date<='".$end."'";
//		echo $sql;
		return MmMySqlPdo::query($sql);
	}
	
	/**
	 * 获得全部版本的信息
	 */
	public function getAllVersion($start,$end)
	{
		$sql = "SELECT date,SUM(h1user) AS h1user,SUM(h1num) AS h1num,SUM(h2user) AS h2user,SUM(h2num) AS h2num,SUM(nuser) AS nuser,SUM(nnum) AS nnum FROM t_banzou_vedio WHERE date>='".$start."' AND date<='".$end."' GROUP BY date";
		
		return MmMySqlPdo::query($sql);
	}
	
/**
	 * 获得数据库中所有的版本
	 */
	public function getVers()
	{
		$sql = "SELECT DISTINCT ver FROM ".self::_getTable();
		return MmMySqlPdo::query($sql);
	}
}