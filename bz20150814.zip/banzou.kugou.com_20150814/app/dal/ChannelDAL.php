<?php
class ChannelDAL
{
	public static function getKeys()
	{
		$memoryId = Mm::getByKey("keyMemoryId");
	/**
		*try read from memory
		**/
		if(@shmop_open($memoryId, "a", 0, 0))
		{
			$memory = new SimpleSHM($memoryId);
			$keys = unserialize($memory->read());
		}
		else
		{
			//if not exist
			//read keys file
			$file = fopen(Mm::getByKey("keydict"),'r') or die("Unable to open file!");
			$content = fgets($file);
			$keys = unserialize($content);
			/**
			*save it to memery
			**/
			$memory = new SimpleSHM($memoryId);
			$memory->write(serialize($keys));
		}
		return $keys;
	}
	
	public static function logChannel($data)
	{
		$filename = Mm::getByKey("channelLogPath")."/".Mm::getByKey("channel_pre").date("Y-m-d");
		$file = fopen($filename, 'a+');
		$towrite = date("H:i:s").'|'.$data["mac"].'|'.$data["harddisk"].'|'.$data["time"].'|'.$data['channel'].'|'.$data['ip'].'|'."\r\n";
		fwrite($file, $towrite);
		fclose($file);
	}
}