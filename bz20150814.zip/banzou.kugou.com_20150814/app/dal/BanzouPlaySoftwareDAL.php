<?php
/**
 * 数据库操作类
 *
 */
class BanzouPlaySoftwareDAL extends MmActiveRecordExt
{
	/**
	 * 获取主键 , 目前只支持单主键
	 * @return string
	 */
	public function _getPrimaryKey()
	{
		return 'date';
	}
	/**
	 * 字段属性规则,每个字段都必须定义
	 * @return array
	 */
	public function rules()
	{
		return array(
			'date' => array(
				'label' => '日期',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'fanxing' => array(
				'label' => '繁星伴奏使用人数',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'9158' => array(
				'label' => '9158使用人数',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'liufang' => array(
				'label' => '六房使用人数',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'videoOther' => array(
				'label' => '其他人数',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'ie' => array(
				'label' => 'ie使用人数',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'firefox' => array(
				'label' => 'firefox使用人数',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'webkit' => array(
				'label' => 'webkit使用人数',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'360' => array(
				'label' => '360安装数',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
			'browerOther' => array(
				'label' => '其他人数',
				'type' => 'text',
				'value' => '',
				'valueList' => array(), //数值范围
//				'table' => array(), //表,字段名首字母大写，name表示类名称
			),
		);
// 			'ColumnName' => array(
// 				'Label'=>'名称',
// 				'Type'=>'(Text|Label|Password|Checkbox|Select|Radio|Html|TextArea|File|Date)',
// 				'Range'=>array('RangValue' => 'Text',...,),
// 				'IsRangeMulti' => false,
// 				'Table'=>array('TableName'=>'表名','EqualColumn'=>'数值对应的列','NameColumn'=>'显示的列',),
// 			),
// 			...
	}
	/**
	 * 列表规则
	 * @return array
	 */
	public function listRules()
	{
	
	}
	/**
	 * 类名
	 * @return string
	 */
	public function _getClass()
	{
		return __CLASS__;
	}
	/**
	 * 获取表
	 * @return string
	 */
	public function _getTable()
	{
		return 't_banzou_play_software';
	}
	
	/**
	 * 获取在start到end时间段的每日统计数据
	 * @param unknown_type $start
	 * @param unknown_type $end
	 */
	public function getStatistics($start,$end)
	{
		$sql = "SELECT * FROM ".self::_getTable()." WHERE date>='".$start."' AND date<='".$end."' order by date desc ";
		return MmMySqlPdo::query($sql);
	}
}