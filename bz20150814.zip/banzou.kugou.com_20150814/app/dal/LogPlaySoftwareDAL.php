<?php

/**
 * 将主播的录像视频软件输出到log日志中记录
 * @author chenxiaochen
 *
 */
class LogPlaySoftwareDAL{
	
	/**
	 * 
	 * 输出到文件中
	 * @param unknown_type $data
	 */
	public function insert($data)
	{
		$filename = Mm::getByKey("playSoftwareLogPath")."/".Mm::getByKey("playSoftware_pre").date("Y-m-d");
		$file = fopen($filename, 'a+');
		$towrite = date("H:i:s").'|'.$data["id"].'|'.$data["brower"].'|'.$data["software"].'|'.$data['ip'].'|'."\r\n";
		fwrite($file, $towrite);
		fclose($file);
	}
}