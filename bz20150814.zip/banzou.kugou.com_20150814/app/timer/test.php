<?php
/**
 * 歌曲日统计定时器
 * 
 * @category Kugou.Com
 * @package StatService
 * @copyright 广州酷狗科技有限公司版权所有 Copyright (c) 2004-2012 (http://www.kugou.com)
 * @author saoyor(345747439@qq.com)
 */

include "common/TimerHeader.php";
//定时器
try {
	DailySongStat::DailyStatSong();
}catch (\Exception $e)
{
	file_put_contents(
		'\temp\logs\php_errors.log',
		date('Y-m-d H:i:s')."    ".$e."\n",
		FILE_APPEND
	);
}

include "common/TimerFooter.php";
		