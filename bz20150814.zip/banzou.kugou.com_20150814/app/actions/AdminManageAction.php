<?php
class AdminManageAction extends MmActionBase
{
	public static function actionLogin()
	{
		$smarty = MyHelper::GetSmarty();
		$smarty->display("admin/login.tpl.php");
	}
	
	public static function actionIndex()
	{
		$smarty = MyHelper::GetSmarty();
		$smarty->display("admin/index.tpl.php");
	}
	
}