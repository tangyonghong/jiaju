<?php

/**
 *视频丢帧弹窗统计
 *
 */
class BanzouVedioAction extends \MmActionBase {
	
	public static function actionVedioPop()
	{
		//版本信息
		$versions = BanzouVedioModule::getVerions();
		$datalist = array();
		$datalist[] = "全部版本";
		foreach ($versions as $ver)
		{
			//过滤buildnum为10的倍数的
			$vernum = MyHelper::versionIntToString($ver['ver']);
			if($vernum!=False)
				$datalist[] = $vernum;
		}
		
		$smarty = MyHelper::GetSmarty();
		$smarty->assign('datalist',$datalist);
		
		$ver = MmHtml::Get('ver','');
		$start = MmHtml::Get('start','');
		$end = MmHtml::Get('end','');
		$action = MmHtml::Get('action','');
		//用户统计信息		
		$statistic = array();
		//如果有提交，无论是查询还是导出excel表
		if($action != '')
		{
			$s = MyHelper::changeDateFormat($start);
			$e = MyHelper::changeDateFormat($end);
			if($ver=="全部版本")
			{
				//用户选择量全部版本
				if($s && $e)
				{
					$smarty->assign('ver',$ver);
					$smarty->assign('start',$start);
					$smarty->assign('end',$end);
					$statistic = BanzouVedioModule::getAllVer($s, $e);
				}
			}
			else
			{
				$v = MyHelper::versionStringToInt($ver);
				if($v && $s && $e)
				{
					$smarty->assign('ver',$ver);
					$smarty->assign('start',$start);
					$smarty->assign('end',$end);
					$statistic = BanzouVedioModule::getRecords($v, $s, $e);
				}
			}
			
//			if($s != $e)
//				$chartData = BanzouStatisticsModule::getStatisticsChartData($statistic);
//			else 
//				$chartData = BanzouStatisticsModule::getOnedayChart($s);//只选择量一天
			$chartData = BanzouVedioModule::getDateChart($ver, $s, $e);
			$smarty->assign('chartData',$chartData);
			
			//现有用户数
//			$install = BanzouInstallModule::getInstall($v,$e);
//			$smarty->assign('install',$install);
		}
		else 
		{
			$date = date("m/d/Y",strtotime('-1 days'));
			$smarty->assign('start',$date);
			$smarty->assign('end',$date);
			//没有查询,进行默认设置
			$smarty->assign('ver','');
		}
		//如果要excel导出
		if($action == 'excel')
		{
			$title = array('日期','版本号','新用户数','累计用户数','新安装量','启动次数','启动人数','卸载人数','卸载次数','搜索次数','搜索人数','播放次数','播放人数','崩溃数','视频启用次数','视频启用人数');
			$file = ExcelHelper::createExcel($title, $statistic);
			@session_start();
			//为了保证用户此时只能下载该文件，不能随便扫描其他文件
			$_SESSION['file'] = $file;
			$smarty->assign('excellocation','/index.php/download/file?name=繁星伴奏版本统计.xlsx&file='.$file);
		}
		
		$smarty->assign('statistic',$statistic);
		$smarty->display("admin/banzouVedio.tpl.php");
	}
	
}