<?php

class VerManageAction extends \MmActionBase {
	
	public static function actionBanzouVers()
	{
		$datalist=array();
		$datalist=VerManageModule::getVerlist();
		foreach ($datalist as $key=>$value)
		{
			$datalist[$key]['JSdesc'] = htmlspecialchars_decode($datalist[$key]['describe'],ENT_QUOTES); //给引号添加转义
			//删掉单引号
			$datalist[$key]['describe'] = str_replace("&#039;",'',$datalist[$key]['describe']);
		}
		$smarty = MyHelper::GetSmarty();
		$smarty->assign('datalist',$datalist);
		$smarty->display("admin/verManage.tpl.php");
		
	}
	public static function actionBanzouAdd()
	{
		$ver=MmHtml::PG('ver','');
		$url=MmHtml::PG('url','');
		$uptype=MmHtml::PG('uptype','');
		$upStatus=MmHtml::PG('verStatus','');
		$verName=MmHtml::PG('verName','');
		//删掉单引号
		$drsc = str_replace("\'",'',MmHtml::PG('drsc',''));
		$drsc=htmlspecialchars(str_replace("\r\n","<br>",$drsc),ENT_QUOTES); 
		$mustUpVer=MmHtml::PG('mustUpVer','');
		$mac = MmHtml::PG('mac','');
		$auurl = MmHtml::PG('auurl','');
		$aufilesize = MmHtml::PG('aufilesize','');
		$tpver = MmHtml::PG('tpver','');
		$tpurl = MmHtml::PG('tpurl','');
		$tpfilesize = MmHtml::PG('tpfilesize','');
		if($ver != '')
		{
			$upArray = array();
			$all = true;
			for($i = 1; $i <= 10; $i ++)
			{
				//遍历所有options
				$tempNum = MmHtml::PG('upNum'.$i,'');
				if($tempNum == '1')
				{
					array_push($upArray,$i);
				}
				//检查是不是全部都升级
				else
				{
					$all = false;//当现在上报没有i,则不是全部升级
				}
			}
			if($all)
				$upNum = 'all';
			else
				$upNum = json_encode($upArray);
			
			/**
			 * 关于强制升级版本
			 */
			//获得上次配置的强制升级版本
			$lastMustUp = VerManageModule::getLastMustUp();
			if((int)$mustUpVer < $lastMustUp[0]['mustUpVer'])
				$mustUpVer=$lastMustUp[0]['mustUpVer'];
			if((int)$mustUpVer > (int)$ver)
				$mustUpVer=$ver;
			VerManageModule::addVer($verName, $ver, $drsc, $url,$auurl,$aufilesize,$tpver,$tpurl,$tpfilesize, $uptype,$upStatus,$mustUpVer,$upNum);
		}
		if($mac != '')
		{
			//提交查询mac地址
			$part = MyHelper::macToPart($mac);
			if(!($part === false))
			{
				$smarty = MyHelper::GetSmarty();
				$smarty->assign('part',$part);
				$smarty->assign('mac',$mac);
			}
		}
		$smarty = MyHelper::GetSmarty();
		$smarty->display("admin/addVer.tpl.php");
	}
	public static function actionBanzouDelver()
	{
		$ver=MmHtml::Get('ver','');
		if(''!=$ver)
		{
			VerManageModule::delVer($ver);
		}
		$datalist=array();
		$datalist=VerManageModule::getVerlist();
			
		$smarty = MyHelper::GetSmarty();
		$smarty->assign('datalist',$datalist);
		$smarty->display("admin/verManage.tpl.php");
	}
	/**
	 * 更新版本
	 */
	public static function actionBanzouUpdateVer()
	{
		$ver=MmHtml::PG('ver','');
		$name=MmHtml::PG('name','');
		$type=MmHtml::PG('type','');
		//删掉单引号
		$describe = str_replace("\'",'',MmHtml::PG('describe',''));
		$describe=htmlspecialchars(str_replace("\r\n","<br>",$describe),ENT_QUOTES); 
		$mustUpVer=MmHtml::PG('mustUpVer','');
		$url=MmHtml::PG('url','');
		$status=MmHtml::PG('status','');
//		$upNum = MmHtml::PG('upNum','');
//		$upNum = 
		$auurl = MmHtml::PG('auurl','');
		$aufilesize = MmHtml::PG('aufilesize','');
		$tpver = MmHtml::PG('tpver','');
		$tpurl = MmHtml::PG('tpurl','');
		$tpfilesize = MmHtml::PG('tpfilesize','');
		if($ver != '')
		{
			//取出之前的灰度数
			$oldVer = VerManageModule::getVer($ver);
			if($oldVer['upNum'] != 'all')
			{
				$oldUpNum = json_decode($oldVer['upNum'],true);
				//检查是不是全部都升级
				$all = true;
				for($i = 1; $i <= 10; $i ++)
				{
					//遍历所有options
					$tempNum = MmHtml::PG('upNum'.$i,'');
					if($tempNum == '1')
					{
						//判断原来有无i
						if(!in_array($i, $oldUpNum))
							array_push($oldUpNum,$i);
					}
					//检查是不是全部都升级
					else 
					{
						//检测原来数组里有没有$i
						if(!in_array($i, $oldUpNum))
							$all = false;//当现在上报的和原来的都没有i,则不是全部升级
					}
				}
				if($all)
					$upNum = 'all';
				else
					$upNum = json_encode($oldUpNum);
			}
			else 
				$upNum = 'all';
			//获得上次配置的强制升级版本
			$lastMustUp = VerManageModule::getLastMustUp();
			if((int)$mustUpVer < $lastMustUp[0]['mustUpVer'])
				$mustUpVer=$lastMustUp[0]['mustUpVer'];
			if((int)$mustUpVer > (int)$ver)
				$mustUpVer=$ver;
			$data=array(
					'name'=>$name,
					'describe'=>$describe,
					'url'=>$url,
					'type'=>$type,
					'status'=>$status,
					'mustUpVer'=>$mustUpVer,
					'upNum'=>$upNum,
					'auurl'=>$auurl,
					'aufilesize'=>$aufilesize,
					'tpver'=>$tpver,
					'tpurl'=>$tpurl,
					'tpfilesize'=>$tpfilesize,
			);
			VerManageModule::upVer($data,$ver);
		}
		
		self::actionBanzouVers();
	}
	/**
	 * 用户的数据统计
	 */
	public static function actionBanzouStatistics()
	{
		//版本信息
		$versions = BanzouStatisticsModule::getVerions();
		$datalist = array();
		foreach ($versions as $ver)
		{
			//过滤buildnum为10的倍数的
			$vernum = MyHelper::versionIntToString($ver['ver']);
			if($vernum!=False)
				$datalist[] = $vernum;
			
		}
		$smarty = MyHelper::GetSmarty();
		$smarty->assign('datalist',$datalist);
		
		$ver = MmHtml::Get('ver','');
		$start = MmHtml::Get('start','');
		$end = MmHtml::Get('end','');
		$action = MmHtml::Get('action','');
		//用户统计信息		
		$statistic = array();
		//如果有提交，无论是查询还是导出excel表
		if($action != '')
		{
			$s = MyHelper::changeDateFormat($start);
			$e = MyHelper::changeDateFormat($end);
			if($ver=="全部版本")
			{
				//用户选择量全部版本
				$v = 0;
				
				if($s && $e)
				{
					
					
					$smarty->assign('ver',$ver);
					$smarty->assign('start',$start);
					$smarty->assign('end',$end);
				}
			}
			else
			{
				$v = MyHelper::versionStringToInt($ver);
				if($v && $s && $e)
				{
					$smarty->assign('ver',$ver);
					$smarty->assign('start',$start);
					$smarty->assign('end',$end);
				}
			}
			$statistic = BanzouStatisticsModule::getStatisticslist($v,$s,$e);
			if($s != $e)
				$chartData = BanzouStatisticsModule::getStatisticsChartData($statistic);
			else 
				$chartData = BanzouStatisticsModule::getOnedayChart($s);//只选择量一天
			$smarty->assign('chartData',$chartData);
			
			//现有用户数
			$install = BanzouInstallModule::getInstall($v,$e);
			$smarty->assign('install',$install);
		}
		else 
		{
			$date = date("m/d/Y");
			$smarty->assign('start',$date);
			$smarty->assign('end',$date);
			//没有查询,进行默认设置
			$smarty->assign('ver','');
		}
		//如果要excel导出
		if($action == 'excel')
		{
			$title = array('日期','版本号','新用户数','累计用户数','新安装量','启动次数','启动人数','卸载人数','卸载次数','搜索次数','搜索人数','播放次数','播放人数','崩溃数','视频启用次数','视频启用人数');
			$file = ExcelHelper::createExcel($title, $statistic);
			@session_start();
			//为了保证用户此时只能下载该文件，不能随便扫描其他文件
			$_SESSION['file'] = $file;
			$smarty->assign('excellocation','/index.php/download/file?name=繁星伴奏版本统计.xlsx&file='.$file);
		}
		
		$smarty->assign('statistic',$statistic);
		$smarty->display("admin/banzouStatistics.tpl.php");
	}
	
	/**
	 * 繁星客户端的管理
	 */
	public static function actionClientVers()
	{
		$datalist=array();
		$datalist=ClientVerManageModule::getVerlist();
		$smarty = MyHelper::GetSmarty();
		$smarty->assign('datalist',$datalist);
		$smarty->display("admin/clientVerManage.tpl.php");
		
	}
	public static function actionClientAdd()
	{
		$ver=MmHtml::PG('ver','');
		$url=MmHtml::PG('url','');
		$uptype=MmHtml::PG('uptype','');
		$upStatus=MmHtml::PG('verStatus','');
		$verName=MmHtml::PG('verName','');
		$drsc=MmHtml::PG('drsc','');
		$mustUpVer=MmHtml::PG('mustUpVer','');
		if(''!=$ver)
		{
			ClientVerManageModule::addVer($verName, $ver, $drsc, $url, $uptype,$upStatus,$mustUpVer);
		}
		$smarty = MyHelper::GetSmarty();
		$smarty->display("admin/clientAddVer.tpl.php");
	}
	public static function actionClientDelver()
	{
		$ver=MmHtml::Get('ver','');
		if(''!=$ver)
		{
			ClientVerManageModule::delVer($ver);
		}
		$datalist=array();
		$datalist=ClientVerManageModule::getVerlist();
		
		$smarty = MyHelper::GetSmarty();
		$smarty->assign('datalist',$datalist);
		$smarty->display("admin/clientVerManage.tpl.php");
	}
	/**
	 * 更新版本
	 */
	public static function actionClientUpdateVer()
	{
		$ver=MmHtml::PG('ver','');
		$name=MmHtml::PG('name','');
		$type=MmHtml::PG('type','');
		$describe=MmHtml::PG('describe','');
		$mustUpVer=MmHtml::PG('mustUpVer','');
		$url=MmHtml::PG('url','');
		$status=MmHtml::PG('status','');
		$data=array(
				'name'=>$name,
				'describe'=>$describe,
				'url'=>$url,
				'type'=>$type,
				'status'=>$status,
				'mustUpVer'=>$mustUpVer,
		);
		if(''!=$ver)
		{
			ClientVerManageModule::upVer($data,$ver);
		}
		self::actionClientVers();
	}
	/**
	 * 用户的数据统计
	 */
	public static function actionClientStatistics()
	{
		//版本信息
		$versions = ClientStatisticsModule::getVerions();
		$datalist = array();
		foreach ($versions as $ver)
		{
			//过滤buildnum为10的倍数的
			$vernum = MyHelper::versionIntToString($ver['ver']);
			if($vernum!=False)
				$datalist[] = $vernum;
		}
		$smarty = MyHelper::GetSmarty();
		$smarty->assign('datalist',$datalist);
		
		$ver = MmHtml::Get('ver','');
		$start = MmHtml::Get('start','');
		$end = MmHtml::Get('end','');
		$action = MmHtml::Get('action','');
		//用户统计信息		
		$statistic = array();
		//如果有提交，无论是查询还是导出excel表
		if($action != '')
		{
			$s = MyHelper::changeDateFormat($start);
			$e = MyHelper::changeDateFormat($end);
			if($ver=="全部版本")
			{
				//用户选择量全部版本
				$v = 0;
				if($e && $s)
				{
					$statistic = ClientStatisticsModule::getStatisticslist($v,$s,$e);
					$smarty->assign('ver',$ver);
					$smarty->assign('start',$start);
					$smarty->assign('end',$end);
				}
			}
			else
			{
				$v = MyHelper::versionStringToInt($ver);
				if($v && $e && $s)
				{
					$statistic = ClientStatisticsModule::getStatisticslist($v,$s,$e);
					$smarty->assign('ver',$ver);
					$smarty->assign('start',$start);
					$smarty->assign('end',$end);
				}
			}
		}
		else 
		{
			$date = date("m/d/Y");
			$smarty->assign('start',$date);
			$smarty->assign('end',$date);
			//没有查询,进行默认设置
			$smarty->assign('ver','');
		}
		//如果要excel导出
		if($action == 'excel')
		{
			$title = array('日期','版本号','新用户数','累计用户数','新安装量','启动次数','启动人数','卸载人数','卸载次数','崩溃数');
			$file = ExcelHelper::createExcel($title, $statistic);
			@session_start();
			//为了保证用户此时只能下载该文件，不能随便扫描其他文件
			$_SESSION['file'] = $file;
			$smarty->assign('excellocation','/index.php/download/file?name=繁星客户端版本统计.xlsx&file='.$file);
		}
		
		$smarty->assign('statistic',$statistic);
		$smarty->display("admin/clientStatistics.tpl.php");
	}
	
	/**
	 * 主播浏览器
	 */
	public static function actionBanzouBrower()
	{
		$smarty = MyHelper::GetSmarty();
		$start = MmHtml::Get('start','');
		$end = MmHtml::Get('end','');
		$action = MmHtml::Get('action','');
		//用户统计信息		
		$statistic = array();
		//如果有提交，无论是查询还是导出excel表
		if($action != '')
		{
			$s = MyHelper::changeDateFormat($start);
			$e = MyHelper::changeDateFormat($end);
			
			$statistic = BanzouPlaySoftwareModule::getRecords($s,$e);
			
			if($s && $e)
			{
				$smarty->assign('start',$start);
				$smarty->assign('end',$end);
			}
		}
		else 
		{
			$date = date("m/d/Y");
			$smarty->assign('start',$date);
			$smarty->assign('end',$date);
		}
		//如果要excel导出
		if($action == 'excel')
		{
			$title = array('日期','繁星伴奏次数','繁星伴奏人数','9158次数','9158人数','6房次数','六房人数','YY次数','YY人数','KK次数','kk人数','其他视频软件次数','其他视频软件人数','MSIE次数','MSIE人数','火狐次数','火狐人数','webkit次数','webkit人数','IE11次数','IE11人数','其他浏览器次数','其他浏览器人数');
			$file = ExcelHelper::createExcel($title, $statistic);
			@session_start();
			//为了保证用户此时只能下载该文件，不能随便扫描其他文件
			$_SESSION['file'] = $file;
			$smarty->assign('excellocation','/index.php/download/file?name=繁星主播开播统计.xlsx&file='.$file);
		}
		
		$smarty->assign('statistic',$statistic);
		$smarty->display("admin/banzouBrower.tpl.php");
	}
	
	/**
	 * 主播录像软件
	 */
	public static function actionBanzouPlaySoftware()
	{
		$smarty = MyHelper::GetSmarty();
		$start = MmHtml::Get('start','');
		$end = MmHtml::Get('end','');
		$action = MmHtml::Get('action','');
		//用户统计信息		
		$statistic = array();
		//如果有提交，无论是查询还是导出excel表
		if($action != '')
		{
			$s = MyHelper::changeDateFormat($start);
			$e = MyHelper::changeDateFormat($end);
			
			$statistic = BanzouPlaySoftwareModule::getRecords($s,$e);
			if($e && $s)
			{
				$smarty->assign('start',$start);
				$smarty->assign('end',$end);
			}
		}
		else 
		{
			$date = date("m/d/Y");
			$smarty->assign('start',$date);
			$smarty->assign('end',$date);
		}
		//如果要excel导出
		if($action == 'excel')
		{
			$title = array('日期','繁星伴奏次数','繁星伴奏人数','9158次数','9158人数','6房次数','六房人数','YY次数','YY人数','KK次数','kk人数','其他视频软件次数','其他视频软件人数','MSIE次数','MSIE人数','火狐次数','火狐人数','webkit次数','webkit人数','IE11次数','IE11人数','其他浏览器次数','其他浏览器人数');
			$file = ExcelHelper::createExcel($title, $statistic);
			@session_start();
			//为了保证用户此时只能下载该文件，不能随便扫描其他文件
			$_SESSION['file'] = $file;
			$smarty->assign('excellocation','/index.php/download/file?name=繁星主播开播统计.xlsx&file='.$file);
		}
		
		$smarty->assign('statistic',$statistic);
		$smarty->display("admin/banzouPlaySoftware.tpl.php");
	}
	
	public static function actionBanzouSearch()
	{
		$smarty = MyHelper::GetSmarty();
		$date = MmHtml::Get('date','');
		$action = MmHtml::Get('action','');
		//用户统计信息		
		$datalist = array();
		//如果有提交，无论是查询还是导出excel表
		if($action != '')
		{
			$d = MyHelper::changeDateFormat($date);
//			echo $d;
			$datalist = SearchRankModule::getRankByDate($d);
			if($d)
				$smarty->assign('date',$date);
		}
		//如果要excel导出
		if($action == 'excel')
		{
			$title = array('序号','搜索内容','搜索次数','日期');
			$file = ExcelHelper::createExcel($title, $datalist);
			@session_start();
			//为了保证用户此时只能下载该文件，不能随便扫描其他文件
			$_SESSION['file'] = $file;
			$smarty->assign('excellocation','/index.php/download/file?name=搜索统计'.$d.'.xlsx&file='.$file);
		}
		$smarty->assign('datalist',$datalist);
		$smarty->display("admin/banzouSearch.tpl.php");
	}
}
