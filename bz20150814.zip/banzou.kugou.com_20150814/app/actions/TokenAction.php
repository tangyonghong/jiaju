<?php
class TokenAction extends MmActionBase
{
	public static function actionMemcached()
	{
		if(!self::isAllowAdminIp())
		{
			echo MmClientInfo::getClientIp(); 
			return 0;
		}
		$key 	= MmHtml::PG('key');
		$value 	= MmHtml::PG('value');
		$type 	= MmHtml::PG('type',0);
		$fix 	= MmHtml::PG('fix',0);
		$config = array(
			'formName' => 'memcache',
			'title' => '查看memcache',
			'inputList' => array(
				array(
					'label' =>'key',
					'list'	=> array(
						array('name'=>'key','value'=>$key,)
					),
				),
				array(
					'label' =>'value',
					'list'	=> array(
						array('name'=>'value','value'=>$value,)
					),
				),
				array(
					'label' =>'type',
					'list'	=> array(
						array('name'=>'type','value'=>$type,'valueList'=>array(0=>'查询',1=>'删除','2'=>'修改',),'type'=>'radio','selected'=>array($type))
					),
				),
				array(
					'label' =>'type',
					'list'	=> array(
						array('name'=>'fix','value'=>$fix,'valueList'=>array(0=>'前缀fxtoken',1=>'无前缀'),'type'=>'radio','selected'=>array($fix))
					),
				),
			),
		);
		$s = '';
		if($key)
		{
			if($fix == 1)
				$memcache = self::getMemcached();
			else
				$memcache = ApiApp::getMemcached();
			if($type == 2)
			{
				if($memcache->set($key , $value))
				{
					$s="修改成功";
				}
				else
				{
					$code = $memcache->getResultCode();
					$message = $memcache->getResultMessage();
					$s="修改失败[$code] : [$message]";
				}
			}
			elseif($type == 0)
			{
				$result = $memcache->get($key);
				$code = $memcache->getResultCode();
				$s = print_r($result , true);
				if($code)
				{
					$message = $memcache->getResultMessage();
					$s.="删除失败[$code] : [$message]";
				}
			}
			else
			{
				if($memcache->delete($key))
					$s="删除成功";
				else
				{
					$code = $memcache->getResultCode();
					$message = $memcache->getResultMessage();
					$s="删除失败[$code] : [$message]";
				}
			}
			if($s)
				$s = "<div style=''>{$s}</div>";
		}
		MmHtml::GetHtml()->InitDefaultCss()->InitDefaultJs()->FormByConfig($config)->AppendFooter($s)->Show();
	}
	private static function getMemcached()
	{
		static $mem = null;
		if($mem) return $mem;
		$config = include MM_ROOT."/config/memcachedConfig.php";
		$serverList = $config['memcachedServerList'];
		$serverOptionsList = $config['memcachedServerOptions'];
		if($serverList)
		{
			if($serverOptionsList)
				$serverOptionsList[Memcached::OPT_PREFIX_KEY] = '';//替换为无前缀
			$mem = MmMemcached::getMemcached($serverList , $serverOptionsList?$serverOptionsList:array());
			return $mem;
		}
		return null;
	}
	public static function actionIndex()
	{
		if(!self::isAllowAdminIp())
		{
			echo MmClientInfo::getClientIp(); 
			return 0;
		}
		$arr = array(
			'create' => '创建token',		
			'checkToken' => '获取token',		
			'createApp' => '创建app',		
		);
		$data = array();
		foreach($arr as $k => $v)
		{
			$data[] = array('value' => $v,'key'=>$k);
		}
		$arrTh = array(
			array('title' => '链接','tpl'=>"<a href='/index.php/token/{key}'>{value}</a>"),	
		);
		MmHtml::GetHtml()->InitDefaultCss()->InitDefaultJs()->DataShow($arrTh, $data)->Show();
	}

	public static function actionCheckToken()
	{
		if(!self::isAllowAdminIp())
		{
			echo MmClientInfo::getClientIp(); 
			return 0;
		}
		$token = MmHtml::PG('token');
		$config = array(
			'formName' => 'checkToken',
			'title' => '检测token',
			'inputList' => array(
				array(
					'label' =>'token',
					'list'	=> array(
						array('name'=>'token','value'=>$token,)		
					),
				),	
			),		
		);
		
		$js=<<<EOT
			$(document).ready(function(){
				var form = $('form[name=checkToken]').submit(function(){
					var token 		= $('input[name=token]',form).val();
					if(token)
					{
						var url = "/api.php";
						$.get(
							url,
							{"api":"token","action":"checkToken","token":token},
							function(data){
								$('#result').text(data);
							}
						);
					}
					else
					{
						alert('参数不全');
					}
					return false;
				});
			});
EOT;
		$s=<<<EOT
	<pre id="result" style="text-align:left;background:#ccc;color:#333;">
		
	</pre>
EOT;

		MmHtml::GetHtml()->InitDefaultCss()->InitDefaultJs()->AppendFooter($s)->AppendJavascript($js)->FormByConfig($config)->Show();
	}
	public static function actionCreateApp()
	{
		if(!self::isAllowAdminIp())
		{
			echo MmClientInfo::getClientIp(); 
			return 0;
		}
		$tokenAppName = MmHtml::PG('tokenAppName');//应用名称
		$isActived = MmHtml::PG('isActived',1);//激活?
		$password = MmHtml::PG('password');//密码
// 		$pwdRule = MmHtml::PG('pwdRule');//加密规则

		$tokenAppDal = new TokenAppDAL();
		if($tokenAppName)
		{
			$dataInsert = array(
				'tokenAppName' => $tokenAppName,
				'isActived' => $isActived,
				'addTime' => time(),
				'password' => $password,
// 				'pwdRule' => $pwdRule,					
			);
			if($tokenAppDal->insert($dataInsert))
				echo "添加成功";
			else
				echo "添加失败";
		}
		
		$rules = array();
		$ignore = array(
			'tokenAppId','addTime','pwdRule',
		);
		foreach($tokenAppDal->rules() as $key => $arr)
		{
			if(in_array($key , $ignore)) continue;
			$arr['name'] = $key;
			if($arr['valueList'])
				$arr['selected'] =$arr['type']=='checkbox'? MmHtml::PG($key): array(MmHtml::PG($key));
			$rules[] = array('label'=>$arr['label'],'list'=>array($arr));
		}
		$config = array(
			'formName' 	=> 'createApp',
			'title' 	=> '创建应用',
			'inputList' => $rules,
		);
		MmHtml::GetHtml()->InitDefaultCss()->InitDefaultCss()->FormByConfig($config)->Show();
	}
	
	public static function actionCreate()
	{
		if(!self::isAllowAdminIp())
		{
			echo MmClientInfo::getClientIp(); 
			return 0;
		}
		$ip 		= MmHtml::PG('ip');
		$appId 		= MmHtml::PG('appId');
		$itemId 	= MmHtml::PG('itemId');
		$expire 	= MmHtml::PG('expire');
		$tokenAppDal = new TokenAppDAL();
		$allAppList = $tokenAppDal->getAll();
		$appDataList = array();
		foreach($allAppList as $arr)
		{
			$appDataList[$arr['tokenAppId']] = $arr['tokenAppName']." ({$arr['tokenAppId']}) " .($arr['isActived']?"[激活]":'[禁止]');
		}
		$config = array(
			'formName' => 'createToken',
			'title' => '创建token',
			'inputList' => array(
				array(
					'label' => 'IP',
					'list' => array(
						array(
							'name' => 'ip',
							'value' => $ip,	
						),
					),	
				),
				array(
					'label' => 'appId',
					'list' => array(
						array(
							'name' => 'appId',
							'type' => 'select',
							'value' => $appId,	
							'valueList' => $appDataList,	
							'selected' => array($appId),
						),
					),	
				),
				array(
					'label' => '流',
					'list' => array(
						array(
							'name' => 'itemId',
							'value' => $itemId,	
						),
					),	
				),
				array(
					'label' => '过期时间',
					'list' => array(
						array(
							'name' => 'expire',
							'value' => $expire,	
						),
					),	
				),
			),
		);
		$js=<<<EOT
			$(document).ready(function(){
				var form = $('form[name=createToken]').submit(function(){
					var ip 		= $('input[name=ip]',form).val();
					var appId 	= $('select[name=appId]',form).val();
					var itemId 	= $('input[name=itemId]',form).val();
					var expire 	= $('input[name=expire]',form).val();
					if(ip && appId && itemId && expire)
					{
						var url = "/index.php/token/getDigest";
						var url1 = "/api.php";
						$.post(url , {"ip":ip,"appId":appId,"itemId":itemId,"expire":expire},function(data){
							$.get(
								url1,
								{"api":"token","action":"createToken","ip":ip,"appId":appId,"itemId":itemId,"expire":expire,"digest":data},
								function(data1){
									$('#result').text("digest:"+data+"\\n"+data1);
								}
							);
						});
					}
					else
					{
						alert('参数不全');
					}
					return false;
				});
			});
EOT;
		$s=<<<EOT
	<pre id="result" style="text-align:left;background:#ccc;color:#333;">
		
	</pre>
EOT;
		MmHtml::GetHtml()->AppendJavascript($js)->appendFooter($s)->InitDefaultCss()->InitDefaultCss()->FormByConfig($config)->Show();
	}
	/**
	 * 获取摘要
	 */
	public static function actionGetDigest()
	{
		if(!self::isAllowAdminIp())
		{
			echo MmClientInfo::getClientIp(); 
			return 0;
		}
		$ip 		= MmHtml::PG('ip');
		$appId 		= MmHtml::PG('appId');
		$itemId 	= MmHtml::PG('itemId');
		$expire 	= MmHtml::PG('expire');
		if($ip)
		{
			$tokenAppDal = new TokenAppDAL();
			$arrWhere = array(
				'tokenAppId' => $appId,
			);
			$tokenAppData = $tokenAppDal->getRowBy($arrWhere);
			if(empty($tokenAppData))
			{
				echo '';
			}
			else
			{
				$password = $tokenAppData['password'];
				$digest = TokenModule::createDigest($password, $ip, $appId, $itemId, $expire);
				echo $digest;
			}
		}
		die();
	}
	private static function isAllowAdminIp()
	{
		$ip = MmClientInfo::getClientIp();
		return in_array($ip , self::getAdminIpList()) ? 1 :  0;
	}
	private static function getAdminIpList()
	{
		return include(MM_ROOT."/config/adminIpConfig.php");
	}
}