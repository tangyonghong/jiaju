<?php
//提供用户的下载接口
class DownloadAction
{
	//文件过期时间
	const timeout = 300;
	
	/**
	 * 下载接口 
	 */
	public static function actionFile()
	{
		$filename = MmHtml::PG('file','');
		$outputname = MmHtml::PG('name','');
		@session_start();
		//如果用户下载别的文件
		if($_SESSION['file'] != $filename)
			Mm::stop();
		if(($filename != '')&&($outputname != ''))
		{
			$time = substr(base64_decode($filename), 0,11);
			$now = time();
			//判断时间是否超时
			if(($now - (int)$time) <= self::timeout)
			{
				$file = Mm::getByKey('ExcelLoc').'/'.$filename;
    			header("Content-type: application/octet-stream");
   		 		//处理中文文件名
    			$ua = $_SERVER["HTTP_USER_AGENT"];
    			$encoded_filename = rawurlencode($outputname);
			    if (preg_match("/MSIE/", $ua)) {
			     header('Content-Disposition: attachment; filename="' . $encoded_filename . '"');
			    } else if (preg_match("/Firefox/", $ua)) {
			     header("Content-Disposition: attachment; filename*=\"utf8''" . $outputname . '"');
			    } else {
			     header('Content-Disposition: attachment; filename="' . $outputname . '"');
			    }
 
			    header("Content-Length: ". filesize($file));
			    readfile($file);
			}
		}
	}
}
