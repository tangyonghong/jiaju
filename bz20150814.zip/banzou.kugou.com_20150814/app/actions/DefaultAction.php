<?php
/**
 * 业务层
 * 		1 ) 负责处理业务发出的请求参数验证
 *  	2 ) 处理业务流程
 *  	3 ) 从M层对象获取所需数据
 *  	4 ) 调用V层进行显示
 *  	5 ) return
 * @author mmfei
 */
class DefaultAction extends MmActionBase
{
	public static function actionDemo()
	{
		MmDebug::printData('class');
		MmDebug::printData(MmUrl::$class);
		MmDebug::printData('function');
		MmDebug::printData(MmUrl::$function);
		MmDebug::printData('params');
		MmDebug::printData(MmUrl::$arrParam);
	}
	/**
	 * 测试
	 * Enter description here ...
	 */
	public static function actionTestDb()
	{
		$db = MmDb::getInstanceByIndex(0);
		$sql = 'show tables';
		MmDebug::printData($db->query($sql));
		$data = array('id' => 2);
		$db->insertBy('test1', $data);
		MmDebug::printData($db->getAll('test1'));
	}
	public static function actionTest()
	{
		$pattern = "/\/\*\*\s*\n(.*\*(.*)\n)*\s*\*\//";
		$content = file_get_contents(__FILE__);
		preg_match_all($pattern,$content,$arr);
		MmDebug::printData($arr);
//		$smarty = MyHelper::GetSmarty();
//		$smarty->assign('a','123');
//		$smarty->assign('arr',array(1,4,6));
//		MmDebug::printData($smarty);//这个调试信息受控于 MM_DEBUG
//		$smarty->display('test.php');
	}

	public static function actionDb()
	{
		$testModule = new TestModule();
		$data = array('name1' => 1);
		$testModule->insert($data);
		
		MmDebug::printData($testModule->getAll());
	}

	private static function isAllowAdminIp()
	{
		$ip = MmClientInfo::getClientIp();
		return in_array($ip , self::getAdminIpList()) ? 1 :  0;
	}
	private static function getAdminIpList()
	{
		return include(MM_ROOT."/config/adminIpConfig.php");
	}
	/**
	 * 首页接口
	 * 		url : ?action=
	 */
	public static function actionIndex()
	{
		if(!self::isAllowAdminIp())
		{
			echo MmClientInfo::getClientIp(); 
			return 0;
		}
		$s=<<<EOT
<pre style='text-align:left;'>
token 说明：
<div style='color:blue;'>================================================
	创建token
================================================</div>
url:
	http://token.fanxing.com/api.php?api=token&action=createToken&ip=127.0.0.1&appId=1&itemId=stream110&expire=600&digest=13ce46a3c466022f31dcbcb9def49092
    
参数：			
	api:token
	action:createToken
	ip:127.0.0.1
	appId:1
	itemId:stream110
	expire:600
	digest:13ce46a3c466022f31dcbcb9def49092
				
返回：
	{"code":0,"result":1,"data":{"token":"9087914a4e042ae69c27577411d3b4aa","streamServerIp":"42.62.20.140"}}


<div style='color:blue;'>================================================
	验证token
================================================</div>
url:
	http://token.fanxing.com/api.php?api=token&action=checkToken&token=f0f096af500ccf8648a387c8d5eac17b

参数:
	api:token
	action:checkToken
	token:f0f096af500ccf8648a387c8d5eac17b

返回:
	{"code":0,"result":1,"data":{"expire":"600","time":"1357214625","used":"0","ip":"127.0.0.1","appId":"1","itemId":"stream110"}}

				
<div style='color:blue;'>================================================
	验证token		-- 返回xml格式 (returnType=1)
================================================</div>
url:
http://token.fanxing.com/api.php?api=token&action=checkToken&returnType=1&token=f0f096af500ccf8648a387c8d5eac17b

参数:
	api:token
	action:checkToken
	token:f0f096af500ccf8648a387c8d5eac17b

返回:
	&lt;?xml version="1.0" encoding="utf-8"?&gt;
	&lt;result&gt;
		&lt;code&gt;903&lt;/code&gt;
		&lt;result&gt;0&lt;/result&gt;
		&lt;data&gt;token is not exists&lt;/data&gt;
	&lt;/result&gt;

				
<div style='color:blue;'>================================================
	获取允许访问的ip列表 	-- 返回xml格式 (returnType=1)
================================================</div>
url:
	http://token.fanxing.com/api.php?api=token&action=getAllowIpList&returnType=0
				
参数:
	api:token
	action:getAllowIpList
	returnType:1

返回:
	{"code":0,"result":1,"data":["202.173.241.77"]}	

				
<div style='color:blue;'>================================================
	api接口返回说明 	-- 返回xml格式 (returnType=1)
================================================</div>
格式:
{"code":0,"result":1,"data":{XXXX}} //XXXX为返回的数据

伪代码:(假设 returnData = api返回的jason数据)

EOT;
		$php=<<<EPT
<?php
	\$return = json_decode(\$returnData);
	if(\$return.result == 1)
	{
		//返回成功
		\$token = \$return.data; //获取token返回的数据,执行业务流程
	}
	else
	{
		//返回失败
		if(\$return.code > 0)
		{
			//约定的错误码,处理对应的异常流程或者直接打印return.data返回的字符串
			echo \$return.data;//直接打印数据,如参数错误，app不存在等信息
		}
		else
		{
			//token服务器异常，如语法错资源不存在之类等提示	
			echo \$return.data;//直接打印数据
		}
	}
EPT;
		print_r($s);
		echo '<br />';
		highlight_string($php);
	}
	
}