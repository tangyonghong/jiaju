<?php

class BanzouFuncAction extends \MmActionBase {
	
	public static function actionClickStat()
	{
		
		include MM_APP_ROOT.'/../config/ID.php';
		
		
		$smarty = MyHelper::GetSmarty();
		$smarty->assign('Id',$Id);
		
		/**
		 * 如果有提交查询
		 */
		$des = MmHtml::PG('des','');
		$start = MmHtml::Get('start','');
		$end = MmHtml::Get('end','');
		$action = MmHtml::Get('action','');
		$datalist = array();
		//如果有提交，无论是查询还是导出excel表
		if($action != '')
		{
			
			/**
			 * 找到对应的id
			 */
			$id = self::findIdByDes($des);
			
			$s = MyHelper::changeDateFormat($start);
			$e = MyHelper::changeDateFormat($end);
			
			$statistic = BanzouFuncModule::getRecords($id,$s,$e);
			
			if($id && $s && $e)
			{
				//传回参数
				$smarty->assign('des',$des);
				$smarty->assign('start',$start);
				$smarty->assign('end',$end);
			}
			$smarty->assign('statistic',$statistic);
		}
		/**
		 * 否则初始化赋值日期
		 */
		else 
		{
			$date = date("m/d/Y");
			$smarty->assign('start',$date);
			$smarty->assign('end',$date);
		}
		//如果要excel导出
		if($action == 'excel')
		{
			$title = array('日期','id','次数','人数','标号','类型');
			$file = ExcelHelper::createExcel($title, $statistic);
			@session_start();
			//为了保证用户此时只能下载该文件，不能随便扫描其他文件
			$_SESSION['file'] = $file;
			$smarty->assign('excellocation','/index.php/download/file?name='.$des.'功能统计.xlsx&file='.$file);
		}
		
		$smarty->display("admin/clickStat.tpl.php");
	}
	
	private static function findIdByDes($des)
	{
		include MM_APP_ROOT.'/../config/ID.php';
		foreach ($Id as $key=>$value)
		{
			if($value == $des)
			{
				return $key;
			}
		}
		return false;
	}
}