<?php
/**
 * 高清插件的相关
 * @author root
 *
 */
class HifiPerformAction extends \MmActionBase {
	
	public static function actionIndex()
	{
		$type = MmHtml::PG('type','');
		$smarty = MyHelper::GetSmarty();
		if($type != "")
		{
			$mac='';
			$content = MmHtml::PG('content','');
			if($type == "3")
			{
				$mac = $content;
			}
			$smarty->assign('content',strip_tags($content));
			$smarty->assign('type',strip_tags($type));
			//循环查询前7天的数据，直到查询到有结果
			for($i = 0; $i <= 6 ; $i ++)
			{
				$t = time();
				$stat = "-".$i." days";
				$t = strtotime($stat, $t);
				$text = "cat ".Mm::getByKey("behaviorLogPath").Mm::getByKey("hifi_pre").date("Y-m-d",$t)."|awk -F '|' '$2==1500 && $".$type." == \"".$content."\"'|tail -1";
			//echo $text."<br>";
				$message = exec($text,$retval,$s);
				if($message != "")
				{			
//					echo $text;
		//			echo $message;
					$m = explode("|",$message);
					$info = array();
					$info[] = $m[0];
					$info[] = $m[2];
					$mac = $m[2];
					$info[] = $m[6];
					$info[] = $m[7];
					$info[] = MyHelper::versionIntToString($m[3]);
					$info[] = $m[8];
					$info[] = $m[4];
					$info[] = $m[5];
					$smarty->assign('info',$info);
					break;
				}
			}
			/**
			 * 获得最近的性能上报
			 */
			$date= MmHtml::Get('date',date("m/d/Y"));
			$smarty->assign('date',$date);
			$number= MmHtml::Get('number',"10");
                        $smarty->assign('number',$number);
			$d = MyHelper::changeDateFormat($date);
			$Perform = array();
			$text = "cat ".Mm::getByKey("behaviorLogPath").Mm::getByKey("hifi_pre").$d."|awk -F '|' '$".$type." == \"".$content."\"'|tail -".$number;
			$message = shell_exec($text);
			if($message != "")
			{			
				$m = explode("\n",$message);
//				echo count($m);
				for($k = 0; $k < count($m)-1;$k ++)
				{
					$one = array();
					$temp = explode("|",$m[$k]);
					$one[] = $temp[0];
					if($temp[1] == '1501')
						$one[] = '开播';
					else if($temp[1] == '1503')
						$one[] = '停播';
					else if($temp[1] == '1504')
						$one[] = '心跳超时';
					else if($temp[1] == '1505')
						$one[] = '异常中断';
					$one[] = $temp[8];
					$one[] = $temp[9];
					$one[] = $temp[10];
					$last = "";
					for($j = 11; $j < count($temp)-1; $j++)
						$last = $last.$temp[$j]."|";
					$one[] = $last;
					$Perform[] = $one;
				}
				$smarty->assign('performs',$Perform);
			}
			
			/**
			 * 获得主播的那一天的操作
			 */
			
			if($d && $mac != "")
			{
				$func = array();
				$text = "cat ".Mm::getByKey("behaviorLogPath").Mm::getByKey("func_pre").$d."|awk -F '|' '$3 == "."\"".$mac."\"'";
//				echo $text;
				$message = shell_exec($text);
				if($message != "")
				{
					//					echo $text;
					//					echo $message;
					$m = explode("\n",$message);
					//					echo count($m);
					for($k = 0; $k < count($m)-1;$k ++)
					{
						$one = array();
						$temp = explode("|",$m[$k]);
						$one[] = $temp[0];
						$one[] = HifiPerformAction::findDesById($temp[1]);
						$one[] = MyHelper::versionIntToString($temp[3]);
						$one[] = $temp[6];
						$last = "";
						for($j = 7; $j < count($temp)-1; $j++)
							$last = $last.$temp[$j]."|";
						$one[] = substr($last,0,-1);
						$func[] = $one;
					}
				}
				//软件使用
				$text = "cat ".Mm::getByKey("behaviorLogPath").Mm::getByKey("banzou_pre").$d."|awk -F '|' '$3 == "."\"".$mac."\"'";
				//echo $text;
				$message = shell_exec($text);
				if($message != "")
				{
					//					echo $text;
					//					echo $message;
					$m = explode("\n",$message);
					//					echo count($m);
					for($k = 0; $k < count($m)-1;$k ++)
					{
						$one = array();
						$temp = explode("|",$m[$k]);
						$one[] = $temp[0];
						$one[] = HifiPerformAction::findbanzouDesById($temp[1]);
						$one[] = MyHelper::versionIntToString($temp[3]);
						$one[] = '';
						$one[] = '';
						$func[] = $one;
						//print_r($one);
					}
				}
				$smarty->assign('func',$func);
				
			}
			
			
		}else 
		{
			$date = date("m/d/Y");
			$smarty->assign('date',$date);
		}
		
//		$smarty->assign('datalist',$datalist);
		$smarty->display("admin/hifiPerform.tpl.php");
	}
	
	/**
	 * 查询丢包的主播，含有v_drop的主播 
	 */
	public static function actionDrop()
	{
		$t = time();
		$t = strtotime("-1 hours" , $t);
		$text = "grep \"v_drop\" ".Mm::getByKey("behaviorLogPath").Mm::getByKey("hifi_pre").date("Y-m-d")."|awk -F '|' '$2 == 1502 && $1 > \"".date("Y-m-d H:i:s",$t)."\" && $13 > \"v_drop,0.001\"'";
//		echo $text;
		$drops = array();
		$messages = shell_exec($text);
		$messages = explode("\n",$messages);
		for($k = 0; $k < count($messages)-1;$k ++)
		{
			$m = explode("|",$messages[$k]);
			$info = array();
			$info[] = $m[0];
			$info[] = $m[2];
			$info[] = MyHelper::versionIntToString($m[3]);
			$info[] = $m[4];
			$info[] = $m[6];
			$info[] = $m[7];
			$info[] = $m[8];
			$info[] = $m[9];
			$info[] = $m[10];
			$last = "";
			for($j = 11; $j < count($m)-1; $j++)
				$last = $last.$m[$j]."|";
			$info[] = $last;
			$drops[] = $info;
		}
		$smarty = MyHelper::GetSmarty();
		$smarty->assign('drops',$drops);
		$smarty->display("admin/hifiDrop.tpl.php");
	}
	
	/**
	 * 版本日志
	 */
	public static function actionVer()
	{
		$smarty = MyHelper::GetSmarty();
		$ver = MmHtml::PG('ver','');
		$smarty->assign('ver',$ver);
		if(strpos($ver,".") != false){
			$ver = MyHelper::versionStringToInt($ver);
		}
		/**
		 * 获得最近的性能上报
		 */
		$drops = array();
		$date= MmHtml::Get('date',date("m/d/Y"));
		$smarty->assign('date',$date);
		$d = MyHelper::changeDateFormat($date);
		if($d)
		{
			$file1 = Mm::getByKey("behaviorLogPath").Mm::getByKey("hifi_pre").$d;
			$text = "awk -F '|' '$2 == 1502 && $4 == ".$ver."' ".$file1." |awk -F '|' '!a[$7]++{print}'";
//			echo $text;
				$message = shell_exec($text);
//				echo $message;
				if($message != "")
				{
					$messages = explode("\n",$message);
					for($k = 0; $k < count($messages)-1;$k ++)
					{
						$m = explode("|",$messages[$k]);
						$info = array();
						$info[] = $m[0];
						$info[] = $m[2];
						$info[] = MyHelper::versionIntToString($m[3]);
						$info[] = $m[4];
						$info[] = $m[6];
						$info[] = $m[7];
						$info[] = $m[8];
						$info[] = $m[9];
						$info[] = $m[10];
						$last = "";
						for($j = 11; $j < count($m)-1; $j++)
							$last = $last.$m[$j]."|";
						$info[] = $last;
						$drops[] = $info;
					}
				}
		}else 
		{
			$date = date("m/d/Y");
			$smarty->assign('date',$date);
		}
		$smarty->assign('drops',$drops);
		$smarty->display("admin/hifiVer.tpl.php");
	}
	
	private static function findDesById($id)
	{
		include MM_APP_ROOT.'/../config/ID.php';
//		foreach ($Id as $key=>$value)
//		{
//			if($key == $id)
//			{
//				return $value;
//			}
//		}
		return $Id[$id];
	}
	private static function findbanzouDesById($id)
	{
		$ID = array(
			'1342' => '安装',
			'1344' => '启动',
			'1345' => '崩溃',
			'1346' => '搜索',
			'1348' => '伴奏播放',
			'1350' => '卸载',
			'1387' => '视频启用',
		);
		if (array_key_exists($id,$ID))
			return $ID[$id];
		else
			return $id;
	}
	
	/**
	 * 开播版本
	 */
	public static function actionStartVer()
	{
		$smarty = MyHelper::GetSmarty();
		/**
		 * 获得最近的性能上报
		 */
		$vers = array();
		$legend = array();
		$date= MmHtml::Get('date',date("m/d/Y"));
		$smarty->assign('date',$date);
		$d = MyHelper::changeDateFormat($date);
		$num = 0;
		$unicnum;
		if($d)
		{
			$file1 = Mm::getByKey("behaviorLogPath").Mm::getByKey("hifi_pre").$d;
			$text = "awk -F '|' '$2 == 1502' ".$file1." |awk -F'|' '!a[$7_$4]++{b[$4]++}END{for(i in b)print i FS b[i]}'";
			//			echo $text;
			$message = shell_exec($text);
			//				echo $message;
			if($message != "")
			{
				$messages = explode("\n",$message);
				for($k = 0; $k < count($messages)-1;$k ++)
				{
					$m = explode("|",$messages[$k]);
					$info = array();
					$info["value"] = (int)$m[1];
					$v = MyHelper::versionIntToString($m[0]);
					if($v)
					{
						$info["name"] = $v;
						$vers[] = $info;
						$legend[] = $info["name"];
						$num += $info["value"];
					}
				}
				
				$text = "awk -F '|' '$2 == 1502' ".$file1." |awk -F '|' '!a[$7]++{print}'|wc -l";
				$unicnum = shell_exec($text);
			}
		}else 
		{
			$date = date("m/d/Y");
			$smarty->assign('date',$date);
		}
		$smarty->assign('vers',json_encode($vers,false));
		$smarty->assign('legend',json_encode($legend,false));
		$smarty->assign("num", $num);
		$smarty->assign("unicnum",$unicnum);
		$smarty->display("admin/hifiStartVer.tpl.php");
	}
}
