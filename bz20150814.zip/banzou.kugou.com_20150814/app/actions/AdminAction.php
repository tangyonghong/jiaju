<?php
class AdminAction
{
	const _SESSION_USER_DATA_ = '';

	
	public static function actionIndex()
	{
		self::show();
	}
	
	public static function getAdminInfo()
	{
		@session_start();
		$userData = isset($_SESSION['username']) ? $_SESSION['username'] : null;
		return $userData;
	}
	
	/**
	public static function actionLogin()
	{
		$html 		= MmHtml::GetHtml();
		$username	= $html->PG('username');
		$password 	= $html->PG('password');
		if('' != $username)
		{
			//验证密码
			$data = AdminModule::getByAdminNameAndPassword($username, $password);
			if($data != null)
			{
				//登录成功
				@session_start();
				$_SESSION['username'] = $username;
				
				$url = '/index.php/admin/index';
				$html->WaitingToUrl($url , '登陆成功!' , '登陆成功!',0);
			}
			else
				Mm::stop('Login faile!Not account exists or password not match!'.$username);
		}
		$smarty = MyHelper::GetSmarty();
		$smarty->display("admin/login.tpl.php");
	}
	**/
	
	/**
	 * 显示主页 
	 */
	public static function show()
	{
		$smarty = MyHelper::GetSmarty();
		$smarty->display("admin/index.tpl.php");
	}
	
	public static function actionLogout()
	{
		session_destroy();
		unset($_SESSION[self::_SESSION_USER_DATA_]);
		header('Location: http://log.fanxing.com/report/index/user_Logout');
	}

	/**
	 * @desc 判断是否登录
	 * @return bool 登录 true,未登录 false
	 */
	public static function checkLogin(){
		$isLogin = false;
		if(self::getAdminInfo() != null)
		{
			$isLogin = true;
			//设置全局页面变量
			$smarty = MyHelper::GetSmarty();
			$smarty->assign("username",self::getAdminInfo());
		}
		
		
		if (isset($_GET['kgLoginTicket'])) {
		    $ticket = $_GET['kgLoginTicket'];
		    $url = 'http://u2.kugou.net:11570/getUserInfoByGet?kgLoginTicket=' . $ticket;
		
		    $ch = curl_init();
		    curl_setopt($ch, CURLOPT_URL, $url);
		    curl_setopt($ch, CURLOPT_TIMEOUT,3); 
		    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		    $result = curl_exec($ch);
		    curl_close($ch);
		    $user = json_decode($result);
			
		    if($user ->returnCode === 0){
		    	@session_start();
		    	$_SESSION['username'] = $user->userInfo->userName;
		    	$isLogin = true;
		    }
		}
		
	    if ($isLogin) {
	    	return true;
		} else {
    		return false;
		}
	    
		exit();
	}
}