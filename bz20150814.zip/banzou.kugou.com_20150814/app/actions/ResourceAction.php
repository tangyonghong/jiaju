<?php
class ResourceAction extends AdminPanel
{
	public function actionIndex()
	{
		$arr = array(
			array(
				'title'=>'test',
				'list'=>array(
					array('text'=>1,),
					array('text'=>'繁星','url'=>'http://fanxing.kugou.com',),
				)
			),
		);
		return self::adminIndex($arr);
	}
}