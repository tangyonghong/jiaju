<?php
/**
 * 伴奏的版本分布
 */
class BanzouVerAction extends \MmActionBase {
	/**
	 * 伴奏现在的版本分布
	 */
	public static function actionExistVer()
	{	
		
		$day = MmHtml::Get('day','');
		$smarty = MyHelper::GetSmarty();
		// 如果有查询
		if($day != '')
		{
			$d = MyHelper::changeDateFormat($day);
			if($d)
			{
				$smarty->assign('date',$day);
			}
			$records = BanzouExistUserModule::getAllVerExist($d);
			$data = array();
			$data['title']="伴奏当前版本已安装分布";
			//版本信息
			$versions = BanzouStatisticsModule::getVerions();
			$legend = array();
			foreach ($versions as $ver)
			{
				//过滤buildnum为10的倍数的
				$vernum = MyHelper::versionIntToString($ver['ver']);
				if($vernum!=False)
				$legend[] = $vernum;
			}
			$data['legend'] = json_encode($legend);
			$series = array();
			foreach ($records as $k=>$record)
			{
				$temp = array();
				$temp['value'] = (int)$record['count'];
				$temp['name'] = MyHelper::versionIntToString($record['ver']);
				$series[] = $temp;
			}
			$data['series'] = json_encode($series);
//			print_r($data);
			$smarty->assign('data',$data);
			
		}
		else 
		{
			$date = date("m/d/Y");
			$smarty->assign('date',$date);
		}
		$smarty->display("admin/banzouVerChart.tpl.php");
	}
}