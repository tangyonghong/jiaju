<?php
class EffectManageAction  extends \MmActionBase {
	public  static $fileDir = "effect/"; 
	public  static $imgDir = "effect/"; 
	public static $imgUrlPre = "http://bzcdn.fanxing.com/";
	public static $fileUrlPre = "http://bzcdn.fanxing.com/";
	public static function actionIndex()
	{
		$kindid = MmHtml::PG('kindid',MmHtml::PG('kind','1'));
		$smarty = MyHelper::GetSmarty();
		$smarty->assign('kindid',$kindid);
		
		$effect = EffectModule::getlist($kindid);
		$smarty->assign('effect',$effect);
		$smarty->display("admin/effectIndex.tpl.php");
	}
	
	public static function actionAdd()
	{
		$status = MmHtml::PG('status','');
		$effectId =  MmHtml::PG('effectId','');
		if($effectId != '')
		{
			EffectModule::updateStatus($effectId,$status);
		}
		else
		{
				
			$kind = MmHtml::PG('kind','');
			//如果有上传参数
			if($status != '')
			{
				$effect = "";
					
				$filemd5="";
				$imgmd5="";
				$imgUrl="";
				$url = "";
				$img = $_FILES['img'];
				$file = $_FILES['file'];
				$temp1 = explode(".", $img["name"]);
				$temp2 = explode(".", $file["name"]);
				if(($temp1[0] == $temp2[0])&&(end($temp1)=="jpg")&&(end($temp2)=="fxi")) //判断文件名是否相等
				{
					//如果上传图片
					if ((($img["type"] == "image/gif")
					|| ($img["type"] == "image/jpeg")
					|| ($img["type"] == "image/png")
					|| ($img["type"] == "image/pjpeg"))
					&& ($img["size"] < 10000000)){
						$imgmd5 = md5_file($img["tmp_name"]);
						EffectManageAction::saveFile($img,EffectManageAction::$imgDir,$img["name"]);
						$imgUrl = EffectManageAction::$imgUrlPre.$img["name"];
					}
					
					
					//如果上传文件
					if (($file["size"] >0)&&($file["size"] < 10000000))
					{
						$filemd5 = md5_file($file["tmp_name"]);
						EffectManageAction::saveFile($file,EffectManageAction::$fileDir,$file["name"]);
						$url = EffectManageAction::$fileUrlPre.$file["name"];
					}
					
					EffectModule::delEffectByName($file["name"]);
					EffectModule::add($kind, $temp1[0], $imgUrl, $url, $filemd5,$imgmd5, $status, time());
				}
				
			}
		}
		
		
		EffectManageAction::actionIndex();
	}
	
	private static function saveFile($file,$dir,$name)
	{
		 if ($file["error"] == 0)
		 {
//		 	echo "Upload: " . $_FILES["file"]["name"] . "<br />";
//		 	echo "Type: " . $_FILES["file"]["type"] . "<br />";
//		 	echo "Size: " . ($_FILES["file"]["size"] / 1024) . " Kb<br />";
//		 	echo "Temp file: " . $_FILES["file"]["tmp_name"] . "<br />";
	
		 	if (file_exists($dir . $name))
		 	{
		 		@unlink ($dir . $name);//删除文件
		 	}
		 	move_uploaded_file($file["tmp_name"],$dir . $name);
		 	return true;
		 }
		 return false;
	}
	
	public static function actionDel()
	{
		$effectId = MmHtml::PG('effectId','');
		$effect = EffectModule::getEffect($effectId);
		EffectModule::delEffectByKey($effectId);
		
		$img = $effect["img"];
		$temp = explode("/", $img);
		@unlink(EffectManageAction::$imgDir.end($temp));
		
		$file = $effect["url"];
		$temp = explode("/", $file);
		@unlink(EffectManageAction::$fileDir.end($temp));
		EffectManageAction::actionIndex();
	}
}
