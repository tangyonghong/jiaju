<?php
/**
 * 接口应用类
 * @author mmfei
 */
class ServiceApp extends MmServerBase
{
	private static $memcached = null;
	/**
	 * serviecr接口
	 */
	public static function run()
	{
		$act = MmHtml::PG('act');
		$mtd = MmHtml::PG('mtd');
		$args= MmHtml::PG('args');
 		$args=json_decode($args,true);
		
		$returnType=0;
		if(empty($act) || empty($mtd))
		{
			return self::returnError("argument error![$act , $mtd]");
		}
		try
		{
			$return = self::callApi($act,$mtd,$args);
			return self::returnSuccess($return , 0 , $returnType);
		}
		catch(Exception $e)
		{
			if($e instanceof ApiException)
				return self::returnError($e->getMessage() , $e->getCode() , $returnType);
			else
				throw $e;
		}	
	}
	/**
	 * 调用api
	 * @param string $api
	 * @param string $function
	 * @param array $args
	 * @return mixed
	 */
	public static function callApi($act,$mtd,$args)
	{
		$class =ucfirst($act);
		$file = MM_APP_ROOT . "/servers/".$class.".php";
		
		MmImport::addMap($class, $file);
		if(file_exists($file))
			$return = call_user_func_array(array($class,$mtd), $args);
		else
			throw new ApiException("Api action does not exists!");
		return $return;
	}
	/**
	 * 失败返回
	 * @param mixed $data
	 * @param integer $code
	 * @param integer $returnType	(0:json,1:xml)
	 * @return void
	 */
	public static function returnError($data , $code = -1 , $returnType = 0)
	{
		
		$result = array(
			'servertime'=>$_SERVER['REQUEST_TIME'],
            'callback'=>array(),    // 绑定事件回调数据
            'data'=>'',
            'status'=>0,
            'errorcode'=>htmlspecialchars($data),
		);
		echo self::_returnType($result , $returnType);
	}
	/**
	 * 返回成功
	 * @param mixed $data
	 * @param integer $code
	 * @param integer $returnType	(0:json,1:xml)
	 * @return void
	 */
	public static function returnSuccess($data , $code = 0 , $returnType = 0)
	{
		$result = array(
			'servertime'=>$_SERVER['REQUEST_TIME'],
            'callback'=>array(),    // 绑定事件回调数据
            'data'=>$data,
            'status'=>1,
            'errorcode'=>'',
		);
		echo self::_returnType($result , $returnType);
	}
	/**
	 * 返回格式
	 * @param mixed $return
	 * @param integer $returnType
	 * @return string
	 */
	private static function _returnType($return , $returnType = 0)
	{
		if($returnType == 1)
			return self::xmlize($return,'result');
		
		//为了解决JS的跨域问题
		if (isset($_GET['jsonCallBack'])) 
		{
			$fun = ($_GET['jsonCallBack']) ? $_GET['jsonCallBack'] : 'jsonCallBack';
			return $fun."(" . json_encode($return) . ")";
		}
		elseif(isset($_GET['_unicode']) && $_GET['_unicode'] == 0)//转换unicode编码
		{
			return preg_replace(
					array("#\\\u([0-9a-f][0-9a-f][0-9a-f][0-9a-f])#ie","/\"(\d+)\"/",),
					array("iconv('UCS-2', 'UTF-8', pack('H4', '\\1'))","\\1"),
					json_encode($return)
			);
		}
		
		return json_encode($return);
	}

	/**
	 * 获取memcached实例
	 * @return Memcached
	 */
	public static function getMemcached()
	{
		if(self::$memcached) return self::$memcached;
		$config = include MM_ROOT."/config/memcachedConfig.php";
		$serverList = $config['memcachedServerList'];
		$serverOptionsList = $config['memcachedServerOptions'];
		if($serverList)
		{
			self::$memcached = MmMemcached::getMemcached($serverList , $serverOptionsList?$serverOptionsList:array());
			return self::$memcached;
		}
	}
}
