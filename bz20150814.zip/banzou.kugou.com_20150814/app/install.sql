CREATE TABLE IF NOT EXISTS `t_token_app`(
	tokenAppId INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '应用ID',
	tokenAppName VARCHAR(255) NOT NULL DEFAULT '' COMMENT '应用名称',
	isActived TINYINT NOT NULL DEFAULT 1 COMMENT '激活?(1:是,0:否)',
	`addTime` INT(10) NOT NULL DEFAULT 0 COMMENT '添加时间',
	PASSWORD VARCHAR(255) NOT NULL DEFAULT '' COMMENT '密码',
	pwdRule VARCHAR(255) NOT NULL DEFAULT '' COMMENT '加密规则',
	PRIMARY KEY(tokenAppId),
	INDEX(isActived)
)ENGINE=INNODB CHARSET=utf8 COMMENT '应用';

CREATE TABLE IF NOT EXISTS `t_token`(
	tokenId INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'tokenID',
	tokenKey VARCHAR(255) NOT NULL DEFAULT '' COMMENT '令牌',
	`addTime` INT(10) NOT NULL DEFAULT 0 COMMENT '添加时间',
	tokenAppId INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '应用ID',
	usedCount INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '使用次数',
	createIp VARCHAR(25) NOT NULL DEFAULT '' COMMENT '创建ip',
	expire INT UNSIGNED NOT NULL DEFAULT 300 COMMENT '过期时间[s]',
	digest VARCHAR(255) NOT NULL DEFAULT '' COMMENT '数字摘要',
	extData VARCHAR(255) NOT NULL DEFAULT '' COMMENT '扩展数据',
	PRIMARY KEY(tokenId),
	UNIQUE(tokenKey)
)ENGINE=INNODB CHARSET=utf8 COMMENT '令牌';

CREATE TABLE IF NOT EXISTS `t_token_check_log`(
	autoId INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '自增ID',
	tokenId INT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'tokenID',
	`addTime` INT(10) NOT NULL DEFAULT 0 COMMENT '添加时间',
	ip VARCHAR(25) NOT NULL DEFAULT '' COMMENT '获取ip',
	PRIMARY KEY(autoId)
)ENGINE=INNODB CHARSET=utf8 COMMENT '检测token日志';

create table if not exists `t_admin`(
	adminId int unsigned not null auto_increment comment '自增ID',
	adminName varchar(255) not null default '' comment '用户名',
	password varchar(255) not null default '' comment '密码',
	isSuper tinyint not null default 0 comment '是否超级管理员(0:否,1:是)',
	isActivited tinyint not null default 1 comment '是否激活(0:否,1:是)',
	primary key(adminId),
	unique(adminName)
)ENGINE=INNODB CHARSET=utf8 COMMENT '管理员表';

insert into t_admin(adminName , password , isSuper , isActivited) values('admin','6a82421d72ae8d753463d2ab5b6ef718',1,1);
