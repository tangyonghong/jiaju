<?php
/**
 * 接口异常类
 * @author mmfei
 */
class ApiException extends Exception
{
// 	/**
// 	 * 
// 	 * @param string $message
// 	 * @param string $code
// 	 * @param string $previous
// 	 * @return void
// 	 */
// 	public function __construct($message = null , $code = null , $previous = null)
// 	{
// 		return parent::__construct($message = null , $code = null , $previous = null);
// 	}
}