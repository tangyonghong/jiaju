<?php

class BehaviorLogModule{
	/**
	 * 
	 * ����һ���û���Ϊ��log��־��¼
	 * @param $id
	 * @param $mac
	 * @param $ver
	 * @param $osVer
	 * @param $type Ϊ0Ϊ���࣬Ϊ1Ϊ�ͻ���
	 */
	public static function insertData($id,$mac,$ver,$osVer,$type) 
	{
		$ip=MmClientInfo::getClientIp();
		$data = array(
			'id'=>$id,
			'mac'=>$mac,
			'ver'=>$ver,
			'osVer'=>$osVer,
			'ip'=>$ip,
			'type'=>$type,
		);
		$Dal = new LogBehaviorDAL();
		return $Dal->insert($data);
	}
	
	/**
	 * �������ļ�¼
	 * @param unknown_type $id
	 * @param unknown_type $mac
	 * @param unknown_type $ver
	 * @param unknown_type $osVer
	 * @param unknown_type $roomId ����id��
	 * @param unknown_type $userId �û�id
	 * @param unknown_type $Info �û���Ϣ
	 */
	public static function insertHifi($id,$mac,$ver,$osVer,$roomId,$userId,$Info)
	{
		$ip=MmClientInfo::getClientIp();
		$data = array(
			'id'=>$id,
			'mac'=>$mac,
			'ver'=>$ver,
			'osVer'=>$osVer,
			'ip'=>$ip,
			'roomId'=>$roomId,
			'userId'=>$userId,
			'Info'=>$Info,
		);
		$Dal = new LogBehaviorDAL();
		return $Dal->insertHifi($data);
	}
	
	/**
	 * ͳ���û���һЩ�ճ��Ĺ���ʹ�ã���ʹ�����յ�
	 */
	public static function insertFunc($id,$mac,$ver,$osVer,$value,$info)
	{
		$ip=MmClientInfo::getClientIp();
//		$data = array(
//			'id'=>$id,
//			'mac'=>$mac,
//			'ver'=>$ver,
//			'osVer'=>$osVer,
//			'ip'=>$ip,
//			'value'=>$value,
//			'info'=>$info
//		);
		$dal = new LogBehaviorDAL();
		return $dal->insertFunc($id,$mac,$ver,$osVer,$value,$info,$ip);
	}
	
}