<?php
class BanzouPlaySoftwareModule
{
	/**
	 * 
	 * 取得数据库的记录
	 * @param $start 起始时间
	 * @param $end 结束时间
	 */
	public static function getRecords($start,$end)
	{
		$dal = new BanzouPlaySoftwareDAL();
		return $dal->getStatistics($start,$end);
	}
}