<?php

class PlaySoftwareLogModule{
	
	public static function insertData($id,$brower,$software) 
	{
		$ip=MmClientInfo::getClientIp();
		$data = array(
			'id'=>$id,
			'brower'=>$brower,
			'software'=>$software,
			'ip'=>$ip,
		);
		$Dal = new LogPlaySoftwareDAL();
		return $Dal->insert($data);
	}
}