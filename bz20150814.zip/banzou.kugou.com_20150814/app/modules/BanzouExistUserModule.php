<?php
class BanzouExistUserModule
{
	/**
	 * 
	 * 取得数据库的记录
	 */
	public static function getExist($ver,$day)
	{
		$dal = new BanzouExistUserDAL();
		return $dal->getNumber($ver,$day);
	}
	
	public static function getAllVerExist($day)
	{
		$dal = new BanzouExistUserDAL();
		return $dal->getAllVers($day);
	}
}