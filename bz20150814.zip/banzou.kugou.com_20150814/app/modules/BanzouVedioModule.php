<?php
class BanzouVedioModule
{
	/**
	 * 
	 * 取得数据库的记录
	 * @param $start 起始时间
	 * @param $end 结束时间
	 */
	public static function getRecords($ver,$start,$end)
	{
		$dal = new BanzouVedioDAL();
		return $dal->getStatistics($ver,$start,$end);
	}
	
	public static function getAllVer($start,$end)
	{
		$dal = new BanzouVedioDAL();
		return $dal->getAllVersion($start,$end);
	}
	
	public static function getVerions()
	{
		$dal = new BanzouVedioDAL();
		return $dal->getVers();
	}
	
	/**
	 * 获得每日的图表数据
	 */
	public static function getDateChart($ver,$start,$end)
	{
		$legend = array(
			"高清-一般严重人数",
			"高清-一般严重次数",
			"高清-特别严重人数",
			"高清-特别严重次数",
			"普通模式人数",
			"普通模式次数",
		);
		$types = array(
			"h1user",
			"h1num",
			"h2user",
			"h2num",
			"nuser",
			"nnum",
		);
		if($ver != "全部版本")
		{
			$v = MyHelper::versionStringToInt($ver);
			$statdata = self::getRecords($v, $start, $end);
		}
		else
			$statdata = self::getAllVer($start, $end);
		$series = array();
		//遍历type
		foreach ($types as $key=>$type)
		{
			$temp = array();
			$temp["name"] = $legend[$key];
			$temp["type"] = "bar";
			$temp["data"] = array();
			$temp["itemStyle"]=array(
				"normal"=>array(
					"label"=>array(
						"show"=>true,
					)
				)
			);
			foreach ($statdata as $row)
			{
				$temp["data"][] = $row[$type];
			}
			if($key == 1 || $key==3 || $key == 5)
			{
				$temp["xAxisIndex"]=1;
			}
			
			$series[] = $temp;
		}
		$category = array();
		foreach ($statdata as $row)
		{
			$category[] = $row["date"];
		}
		$chartData = array();
		$chartData["title"] = $ver."视频丢帧弹窗统计";
		$chartData["legend"] = json_encode($legend);
		$chartData["series"] = json_encode($series);
		$chartData["category"] = json_encode($category);
		return $chartData;
	}
}