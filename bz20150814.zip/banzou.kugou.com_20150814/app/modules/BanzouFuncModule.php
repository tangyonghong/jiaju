<?php
class BanzouFuncModule
{
	/**
	 * 
	 * 取得数据库的记录
	 * @param $start 起始时间
	 * @param $end 结束时间
	 */
	public static function getRecords($id,$start,$end)
	{
		$dal = new BanzouFuncDAL();
		return $dal->getStatistics($id,$start,$end);
	}
}