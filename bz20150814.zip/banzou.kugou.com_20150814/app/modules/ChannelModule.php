<?php

class ChannelModule 
{
	/**
	 * 
	 * 获得RSA的公钥
	 */
	public static function getRSAPublicKey()
	{
		$keys = ChannelDAL::getKeys();
		//random get a key
		$public_key = array_rand($keys);
		return $public_key.time();
	}
	
	/**
	 * 根据公钥获得RSA的私钥
	 */
	public static function getRSAPrivateKey($public_key)
	{
		$keys = ChannelDAL::getKeys();
		return $keys[$public_key];
	}
	/**
	 * 将上传的渠道信息保存下来
	 */
	public static function insertChannelLog($mac,$harddisk,$time,$channel)
	{
		$ip=MmClientInfo::getClientIp();
		$data = array(
			'mac'=>$mac,
			'harddisk'=>$harddisk,
			'time'=>$time,
			'channel'=>$channel,
			'ip'=>$ip,
		);
		$Dal = new ChannelDAL();
		return $Dal->logChannel($data);
	}
	
}