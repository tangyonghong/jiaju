<?php

class ClientVerManageModule {
	public static function getVerlist()
	{
		$dal=new ClientVerManageDAL();
		$lst=$dal->getAll('',null,array('addTime'=>'DESC'));
		return $lst;
	}
	public static function upVer($data,$ver)
	{
		$dal=new ClientVerManageDAL();
		return $dal->updateBy(array('ver'=>$ver), $data);
	}
	public static function addVer($verName,$ver,$drsc,$url,$type,$upStatus,$mustUpVer)
	{
		$dal=new ClientVerManageDAL();
		$data=array(
				'ver'=>$ver,
				'name'=>$verName,
				'describe'=>$drsc,
				'url'=>$url,
				'type'=>$type,
				'status'=>$upStatus,
				'mustUpVer'=>$mustUpVer,
				'addTime'=>time(),
		);
		return $dal->insert($data);
		
	}
	public static function delVer($ver)
	{
		$dal=new ClientVerManageDAL();
		return $dal->deleteByPk($ver);
		
	}
	public static function getpulicVer()
	{
		$dal=new ClientVerManageDAL();
		return $dal->getListBy(array('status'=>1),array('addTime'=>'desc'));	
	}
	/**
	 * 获得最新的提示升级版本
	 */
	public static function getPromtVer()
	{
		$dal=new ClientVerManageDAL();
		return $dal->getPrompt();
	}
}

