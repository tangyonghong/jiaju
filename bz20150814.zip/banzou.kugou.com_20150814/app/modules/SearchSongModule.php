<?php


class SearchSongModule{
	
	public static function insertData($songName,$mac,$ver,$OSver)
	{	
		$ip=MmClientInfo::getClientIp();
		$data=array(
			'songName'=>$songName,
			'mac'=>$mac,
			'ver'=>$ver,
			'osVer'=>$OSver,
			'ip'=>$ip,
//			'addTime'=>date("Y-m-d"),
		);
		
		$Dal = new SearchSongDAL();
		return $Dal->insert($data);
	}

	public static function clearTable()
	{
		$delOldDataSql='delete from t_search_song';
		\MmDatabase::execute($delOldDataSql);
	}
}

