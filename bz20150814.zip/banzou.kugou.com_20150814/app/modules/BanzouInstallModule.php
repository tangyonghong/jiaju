<?php
class BanzouInstallModule
{
	/**
	 * 
	 * 取得数据库的记录
	 * @param $start 起始时间
	 * @param $end 结束时间
	 */
	public static function getInstall($ver,$day)
	{
		$dal = new BanzouInstallDAL();
		return $dal->getNumber($ver,$day);
	}
}