<?php
/**
 * 此文件数据源提供者
 * @author mmfei
 * @var KgAbActiveRecord
 */
class TestModule extends TestDAL
{
	
}