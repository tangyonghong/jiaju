<?php

class BanzouStatisticsModule {
	public static function getStatisticslist($ver,$start,$end)
	{
		$dal=new BanzouStatisticsDAL();
		$lst=$dal->getStatistics($ver,$start,$end);
//		print_r($lst);
		return $lst;
	}
	
	public static function getVerions()
	{
		$dal = new BanzouStatisticsDAL();
		return $dal->getVers();
	}
	
	/**
	 * 图表数据
	 */
	public static function getStatisticsChartData($Statdata)
	{
		$chartData = array();
		$category = array();
		$legend = array(
			'新用户数',
			'新安装量',
			'启动次数',
			'启动人数',
			'卸载人数',
			'卸载次数',
			'搜索次数',
			'搜索人数',	
			'播放次数',
			'播放人数',
			'崩溃次数',	
			'视频启用次数',
			'视频启用人数',
			'崩溃率（次）',
		);
		$chartData['legend'] = json_encode($legend);
		$chartData['series'] = array();
		//每一行就是所有天的某记录
		$names = array(
				'newUser',
				'installNum',
				'startNum',
				'startUser',
				'uninstallUser',
				'uninstallNum',
				'searchNum',
				'searchUser',
				'playNum',
				'playUser',
				'crashNum',
				'videoStartNum',
				'videoStartUser',
				'crushRate',
		);
		foreach ($names as $key=>$name)
		{
			//一行，是某种记录的所有天
			$temp = array();
			$temp['name'] = $legend[$key];
			$temp['type'] = 'line';
			if($name == 'crushRate')
				 $temp['yAxisIndex'] = 1;
			$temp['data'] = array();
			foreach ($Statdata as $row)
			{
				if($name == 'crushRate')
					array_push($temp['data'], 100*round((float)$row['crashNum']/((float)$row['startNum']+1),3));
				else
					array_push($temp['data'], (int)$row[$name]);
			}
			array_push($chartData['series'],$temp);
		}
		$chartData['series']=json_encode($chartData['series']);

		foreach ($Statdata as $row)
		{
			array_push($category,$row['date']);
		}
		$chartData['category'] = json_encode($category);
		$chartData['title'] = ''.$Statdata[0]['ver'].'版本';
		if($Statdata[0]['ver'] == 0)
			$chartData['title'] = '全部版本';
//		print_r($chartData);
		return $chartData;
	}
	
	/**
	 * 获得一天的各版本的比较，横坐标为版本，线为各自参数
	 */
	public static function getOnedayChart($day)
	{
		//获得版本
		$versions = BanzouStatisticsModule::getVerions();
		$chartData = array();
		$category = array();
		$legend = array(
			'新用户数',
			'新安装量',
			'启动次数',
			'启动人数',
			'卸载人数',
			'卸载次数',
			'搜索次数',
			'搜索人数',	
			'播放次数',
			'播放人数',
			'崩溃次数',	
			'视频启用次数',
			'视频启用人数',
			'崩溃率（次）',
		);
		$chartData['legend'] = json_encode($legend);
		$chartData['series'] = array();
		//每一行就是所有天的某记录
		$names = array(
				'newUser',
				'installNum',
				'startNum',
				'startUser',
				'uninstallUser',
				'uninstallNum',
				'searchNum',
				'searchUser',
				'playNum',
				'playUser',
				'crashNum',
				'videoStartNum',
				'videoStartUser',
				'crushRate',
		);
		//先将所有版本的该天记录拿出来
		$stat = array();
		foreach ($versions as $row)
		{
			//版本
			$ver = $row['ver'];
			//获得版本数据
			$stat[$ver] = BanzouStatisticsModule::getStatisticslist($ver, $day,$day);
			if(isset($stat[$ver][0]))
			{
				$stat[$ver] = $stat[$ver][0];
				if($ver == '0')
					array_push($category,'全部版本');
				else
					array_push($category,MyHelper::versionIntToString($ver));
			}
			else 
			{
				//该时间段没有该版本
				unset($stat[$ver]);
			}
		}
		foreach ($names as $key=>$name)
		{
			//一行，是某种记录的所有版本
			$temp = array();
			$temp['name'] = $legend[$key];
			$temp['type'] = 'line';
			if($name == 'crushRate')
				 $temp['yAxisIndex'] = 1;
			$temp['data'] = array();
			foreach ($stat as $ver=>$row)
			{
				if($name == 'crushRate')
					array_push($temp['data'], 100*round((float)$row['crashNum']/((float)$row['startNum']+1),3));
				else
					array_push($temp['data'], (int)$row[$name]);
			}
			array_push($chartData['series'],$temp);
		}
		$chartData['series']=json_encode($chartData['series']);
		$chartData['title']=''.$day.'各版本统计';
		$chartData['category'] = json_encode($category);
//		print_r($chartData);
		return $chartData;
	}
}

