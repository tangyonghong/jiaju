<?php

class SearchRankModule extends DailySongSearchDAL{
	
	public static function searchInsertMulti($data)
	{
		//self::deletecache();
		$Dal=new DailySongSearchDAL();
		$Dal->insertTMulti($data);
	}
	
	/**
	 * 获得排名
	 */
	public static function getRankByDate($date)
	{
		$dal = new DailySongSearchDAL();
		return $dal->getListBy(array('addTime'=>$date,));
	}
	
}
