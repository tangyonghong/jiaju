<?php

class ClientStatisticsModule {
	public static function getStatisticslist($ver,$start,$end)
	{
		$dal=new ClientStatisticsDAL();
		$lst=$dal->getStatistics($ver,$start,$end);
//		print_r($lst);
		return $lst;
	}
	
	public static function getVerions()
	{
		$dal = new ClientStatisticsDAL();
		return $dal->getVers();
	}
}

