<?php
/**
 * admin module
 * @author mmfei
 *
 */
class AdminModule
{
	const PWD_PREFIX = 'token_';
	/**
	 * append admin account
	 * @param string $adminName
	 * @param string $password
	 * @return number
	 */
	public static function add($adminName , $password)
	{
		$adminName = trim($adminName);
		$password = trim($password);
		if(empty($password) || empty($adminName)) return 0;
		$password = self::_getPwd($password);
		$id = 0;
		$data = array(
			'adminName' => $adminName,
			'password' 	=> $password,	
		);
		$admalDal = new AdminDAL();
		$admalDal->insert($data , $id);
		return $id;
	}
	/**
	 * delete account with adminName
	 * @param string $adminName
	 * @return number
	 */
	public static function delete($adminName)
	{
		$admalDal = new AdminDAL();
		return $admalDal->deleteBy(array('adminName'=>$adminName,));
	}
	/**
	 * get account by adminName
	 * @param string $adminName
	 * @return array
	 */
	public static function get($adminName)
	{
		$admalDal = new AdminDAL();
		return $admalDal->getRowBy(array('adminName'=>$adminName,));
	}
	/**
	 * get account by adminName and password
	 * @param string $adminName
	 * @param string $password
	 * @return array
	 */
	public static function getByAdminNameAndPassword($adminName , $password)
	{
		$admalDal = new AdminDAL();
		return $admalDal->getRowBy(array('adminName'=>$adminName,'password'=>self::_getPwd($password),));
	}
	public static function _getPwd($password)
	{
		return md5(self::PWD_PREFIX.$password);
	}
	public static function update($adminId , $data)
	{
		$admalDal = new AdminDAL();
		return $admalDal->updateByPk($adminId , $data);
	}
}