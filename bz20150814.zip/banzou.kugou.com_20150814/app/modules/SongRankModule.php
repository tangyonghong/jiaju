<?php

class SongRankModule extends DailySongStatDAL {
	const HOTSONGRANK='hotsongRank1203';
	const UPSONGRANK='upsongRank1203';
	/**
	 * 获取旧数据表的内容
	 * @return array;
	 */
	public static function  getOldSongData()
	{
		$oldDal=new DailySongStatDAL();
		$retvl=$oldDal->getAll('hash');
		return $retvl;
	}
	public static function songInsertMulti($data)
	{
		//self::deletecache();
		$Dal=new DailySongStatDAL();
		$Dal->insertTMulti($data);
	}
	public static function clearTable()
	{
		$delOldDataSql='delete from t_daily_song_stat';
		\MmDatabase::execute($delOldDataSql);
	}
	/**
	 * 获取热歌榜数据
	 * @param unknown $limit
	 * @return array
	 */
	public static function  getHotSongRank($limit)
	{
		//$memcached=\ServiceApp::getMemcached();
		//$retvl = $memcached->get(self::HOTSONGRANK);
		//if(!empty($retvl)) return $retvl;
		$retvl=array();
		$Dal=new DailySongStatDAL();
		$retvl=$Dal->getListBy(array(),array('rank'=>'asc'),array(),'hash',1,$limit);
// 		$hashs=array_keys($retvl);
// 		$songInfo=self::getSongInfo($hashs);
// 		$singers=array();
		foreach ($retvl as $k=>$v)
		{
			$songName=$v['songName'];
			$songNameArr=explode('-', $songName);
			if(count($songNameArr)>=2)
			{
				$retvl[$k]['singer']=$songNameArr[0];
				$retvl[$k]['songName']=$songNameArr[1];
//				$singers[$v['hash']]=$songNameArr[0];
			}else{
				$retvl[$k]['singer']='';
				$retvl[$k]['songName']=$songNameArr[0];
			}
// 			if(isset($songInfo[$k]))
// 			{
// 				$retvl[$k]['duration']=$songInfo[$k]['timeLength']*1000;
// 				$retvl[$k]['filesize']=$songInfo[$k]['fileSize'];
// 				$retvl[$k]['bitrate']=$songInfo[$k]['bitRate'];
// 			}
			
		}
// 		if(!empty($singers))
// 		{
// 			$singers=array_splice($singers,0,3);
// 			$singerImgs=array();
// 			$singerImgs=self::getSingerImg($singers);
			
// 			foreach ($singerImgs as $k=>$v)
// 			{
// 				$retvl[$k]['singerImg']=$v;
// 			}
// 		}
		
		
		//if(!empty($retvl))
		//	$memcached->set(self::HOTSONGRANK,array_values($retvl),strtotime('today')+86400);
		return array_values($retvl);
	}
	/**
	 * 获取飙升歌榜数据
	 * @param unknown $limit
	 * @return array
	 */
	public static function  getUpSongRank($limit)
	{
		#$memcached=\ServiceApp::getMemcached();
		#$retvl = $memcached->get(self::UPSONGRANK);
		#if(!empty($retvl)) return $retvl;
		$retvl=array();
		$Dal=new DailySongStatDAL();
//		$singers=array();
		$retvl=$Dal->getListBy(array(),array('upRank'=>'desc'),array(),'hash',1,$limit);
// 		$hashs=array_keys($retvl);
// 		$songInfo=self::getSongInfo($hashs);
//		$singers=array();
		foreach ($retvl as $k=>$v)
		{
			$songName=$v['songName'];
			$songNameArr=explode('-', $songName);
			if(count($songNameArr)>=2)
			{
				$retvl[$k]['singer']=$songNameArr[0];
				$retvl[$k]['songName']=$songNameArr[1];
//				$singers[$v['hash']]=$songNameArr[0];
			}else{
				$retvl[$k]['singer']='';
				$retvl[$k]['songName']=$songNameArr[0];
			}
// 			if(isset($songInfo[$k]))
// 			{
// 				$retvl[$k]['duration']=$songInfo[$k]['timeLength']*1000;
// 				$retvl[$k]['filesize']=$songInfo[$k]['fileSize'];
// 				$retvl[$k]['bitrate']=$songInfo[$k]['bitRate'];
// 			}
		}
// 		if(!empty($singers))
// 		{
// 			$singers=array_splice($singers,0,3);
// 			$singerImgs=self::getSingerImg($singers);
// 			$singerImgs=array();
// 			foreach ($singerImgs as $k=>$v)
// 			{
// 				$retvl[$k]['singerImg']=$v;
// 			}
// 		}
		#if(!empty($retvl))
		#	$memcached->set(self::UPSONGRANK,array_values($retvl),strtotime('today')+86400);
		return array_values(array_values($retvl));
	}
	/**
	 * 获取歌手图片
	 * @param array $singers
	 * @return array
	 */
	public static function getSingerImg($singers)
	{
		if(empty($singers))
			return false;
		$singerImgs=array();
		foreach ($singers as $k=>$v)
		{
			$v=trim($v);
			$url='http://mobilecdn.kugou.com/new/app/i/yueku.php?cmd=104&type=softhead&singer='.$v.'&size=120';
			$fp=fopen($url,'r');
			$fconten=fread($fp,4096);
			fclose($fp);
			$singer=json_decode($fconten);
			$singerImgs[$k]=$singer->url;
		}
		return $singerImgs;
	}
	/**
	 * 批量获取歌曲信息
	 * @param int $hashArr
	 * @return multitype:multitype:NULL
	 */
	public static function getSongInfo($hashArr)
	{	
		$n=ceil(count($hashArr)/10);
		
		$retvl=array();
		for($i=0;$i<$n;$i++)
		{
			$hashs=array_splice($hashArr,0,10);
			
			$hash='';
			foreach ($hashs as $k=>$v)
			{
				if($k==0)
					$hash=$v;
				else
					$hash.=','.$v;
			}
			$key=md5($hash.'kgcloud');
			$url='http://trackercdn.kugou.com/i/?cmd=9&hash='.$hash.'&key='.$key.'&pid=12';
			$fp=fopen($url,'r');
			$fconten=fread($fp,4096);
			fclose($fp);
			$songInfo=json_decode($fconten);
			
			if(1==$songInfo->status)
			{
				$content=$songInfo->data;
				foreach ($hashs as $k=>$v)
				{
					if(isset($content->$v))
					{
						$retvl[$v]=array(
							'bitRate'=>	$content->$v->bitRate,
							'timeLength'=>$content->$v->timeLength,
							'fileSize'=>	$content->$v->fileSize,
						);
					}
				}		
			}
		}
		return $retvl;
	}
	public static function deletecache()
	{
		$memcached=\ServiceApp::getMemcached();
		$memcached->delete(self::UPSONGRANK);
		$memcached->delete(self::HOTSONGRANK);
	}
}
