<?php
/**
 * token模块
 * @author mmfei
 */
class TokenModule
{
	/**
	 * 检测token
	 * 
	 * 
	 * @param string $token
	 * @return array
	 */
	public static function checkToken($token)
	{
		$tokenDal = new TokenDAL();
		$tokenData= $tokenDal->getRowBy(array('tokenKey' => $token,));
		if(empty($tokenData))
			throw new ApiException('Token is not exists' , 903);

		$time = time();
		if($tokenData['addTime'] + $tokenData['expire'] <= $time)
			throw new ApiException('This key has expired' , 904);
		
		//{"code":0, "info":"OK", "expire":600,"time":12456789,"used":0,"ip":"1.2.3.4","appId":1,"itemId":"1234567" }
		$data = array(
			'expire' 	=> $tokenData['expire'],
			'time' 		=> $tokenData['addTime'],
			'used' 		=> $tokenData['usedCount'],
			'ip' 		=> $tokenData['createIp'],
			'appId' 	=> $tokenData['tokenAppId'],
			'itemId' 	=> $tokenData['extData'],
		);
		
		return $data;
	}
	/**
	 * 创建token
	 * 
	 * @param string $ip			IP
	 * @param integer $appId		应用ID
	 * @param integer $itemId		流
	 * @param integer $expire		过期时间(s)
	 * @param string $digest		摘要
	 * @return string
	 */
	public static function createToken($ip , $appId , $itemId , $expire , $digest)
	{
		$time = time();
		$tokenAppDal = new TokenAppDAL();
		$tokenAppData = $tokenAppDal->getRowByPk($appId);
		
		if(empty($tokenAppData))
			throw new ApiException('argumengs error ! [appId]');
		
		if($tokenAppData['isActived'] == TokenAppDAL::IS_ACTIVED_0)
			throw new ApiException('Access deny![app]' , 902);
		
		$password = $tokenAppData['password'];
		$newDigest = TokenModule::createDigest($password, $ip, $appId, $itemId, $expire);
		
// 		if($digest != $newDigest)
// 			throw new ApiException('Digest is not match!' , 901);
		
		$tokenKey = self::_createTokenKey($time, $appId, $ip, $digest, $itemId, $password);
		
		$data = array(
	        'tokenKey' 		=> $tokenKey,
	        'addTime' 		=> $time,
	        'tokenAppId' 	=> $appId,
	        'usedCount' 	=> 0,
	        'createIp' 		=> $ip,
	        'expire' 		=> $expire,
	        'digest' 		=> $digest,
	        'extData' 		=> $itemId,
		);
		$tokenDal = new TokenDAL();
		if($tokenDal->insert($data))
			return array(
				'token'			=>	$tokenKey,
	        	'streamServerIp'=>	Mm::getByKey('streamServerIp'),
			);
		else
			return '';
	}
	/**
	 * 生成token
	 * @param integer $time
	 * @param integer $appId
	 * @param string $ip
	 * @param string $digest
	 * @param integer $itemId
	 * @param string $password
	 * @return string
	 */
	public static function _createTokenKey($time , $appId , $ip , $digest , $itemId , $password)
	{
		return md5($ip . $time . $appId . $digest . $itemId .'!@#$$!'.$password);
	}
	/**
	 * 创建摘要
	 * @param string $password	app密码
	 * @param string $ip
	 * @param integer $appId
	 * @param string $itemId
	 * @param integer $expire
	 * @return string
	 */
	public static function createDigest($password , $ip , $appId , $itemId , $expire)
	{
		//ip=127.0.0.1  appId=2 itemId=123456 expire=600 
		//md5(08Src20#@*127.0.0.12123456600)=ba90fa38bdb9728640dec81a2be2a931
		return md5($password.$ip.$itemId.$expire);
	}
}