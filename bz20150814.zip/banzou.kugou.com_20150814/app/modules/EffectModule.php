<?php

class EffectModule {
	public static function getAll()
	{
		$dal = new EffectDAL();
		$lst=$dal->getAll();
		return $lst;
	}
	public static function getlist($kind)
	{
		$dal=new EffectDAL();
		$lst=$dal->getListBy(array('kind'=>$kind),array('name'=>'asc'));
		return $lst;
	}
	public static function updateStatus($effectId,$status)
	{
		$dal=new EffectDAL();
		$data = array(
			'status'=>$status,
		);
		$dal->updateBy(array('id'=>$effectId), $data);
	}
	public static function add($kind,$name,$img,$url,$md5,$imgmd5,$status,$time)
	{
		$dal=new EffectDAL();
		$data=array(
				'kind'=>$kind,
				'name'=>$name,
				'img'=>$img,
				'url'=>$url,
				'md5'=>$md5,
				'imgmd5'=>$imgmd5,
				'status'=>$status,
				'time'=>$time,
		);
		return $dal->insert($data);
		
	}
	public static function delEffectByKey($id)
	{
		$dal=new EffectDAL();
		return $dal->deleteByPk($id);
	}
	
	public static function delEffectByName($name)
	{
		$dal=new EffectDAL();
		$data=array(
			'name'=>$name,
		);
		return $dal->deleteBy($data);
	}
	
	public static function getEffect($id)
	{
		$dal=new EffectDAL();
		return $dal->getRowBy(array('id'=>$id,));
	}
}

