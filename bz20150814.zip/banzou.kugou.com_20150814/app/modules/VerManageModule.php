<?php

class VerManageModule {
	public static function getVerlist()
	{
		$dal=new VerManageDAL();
		$lst=$dal->getAll('',null,array('addTime'=>'DESC'));
		return $lst;
	}
	public static function upVer($data,$ver)
	{
		$dal=new VerManageDAL();
		return $dal->updateBy(array('ver'=>$ver), $data);
	}
	public static function addVer($verName,$ver,$drsc,$url,$auurl,$aufilesize,$tpver,$tpurl,$tpfilesize,$type,$upStatus,$mustUpVer,$upNum)
	{
		$dal=new VerManageDAL();
		$data=array(
				'ver'=>$ver,
				'name'=>$verName,
				'describe'=>$drsc,
				'url'=>$url,
				'auurl'=>$auurl,
				'aufilesize'=>$aufilesize,
				'tpver'=>$tpver,
				'tpurl'=>$tpurl,
				'tpfilesize'=>$tpfilesize,
				'type'=>$type,
				'status'=>$upStatus,
				'mustUpVer'=>$mustUpVer,
				'upNum'=>$upNum,
				'addTime'=>time(),
		);
		return $dal->insert($data);
		
	}
	public static function delVer($ver)
	{
		$dal=new VerManageDAL();
		return $dal->deleteByPk($ver);
		
	}
	public static function getpulicVer()
	{
		$dal=new VerManageDAL();
		return $dal->getListBy(array('status'=>1),array('addTime'=>'desc'));	
	}
	/**
	 * 获得最新的提示升级版本
	 */
	public static function getPromtVer()
	{
		$dal=new VerManageDAL();
		return $dal->getPrompt();
	}
	public static function getVer($ver)
	{
		$dal=new VerManageDAL();
		return $dal->getRowBy(array('ver'=>$ver,));
	}
	
	public static function getLastMustUp()
	{
		$dal = new VerManageDAL();
		return $dal->getLastMustUp();
	}
}

