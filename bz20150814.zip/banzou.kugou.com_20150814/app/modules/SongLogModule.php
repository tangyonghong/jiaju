<?php


class SongLogModule{
	
	public static function insertData($hash,$songName,$bitRate,$mac,$srcType,$userId,$ver,$OSver)
	{	
		$ip=MmClientInfo::getClientIp();
		$data=array(
			'hash'=>$hash,
			'songName'=>$songName,
			'bitRate'=>$bitRate,
			'mac'=>$mac,
			'srcType'=>$srcType,
			'userId'=>$userId,
			'ver'=>$ver,
			'OSver'=>$OSver,
			'addTime'=>time(),
			'Ip'=>$ip,		
		);
		
		$Dal = new LogSongDAL();
		return $Dal->insert($data);
	}

}

