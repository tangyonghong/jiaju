<?php
class MyHelper
{
	/**
	 * 获取smarty实例
	 * @return Smarty
	 */
	public static function GetSmarty()
	{
		static $smarty = null ;
		if($smarty) return $smarty;
		include MM_APP_ROOT.'/ext/smarty/Smarty.class.php';
		$smarty = new Smarty();
		$smarty->debugging = false;
		$smarty->caching = false;
		$smarty->cache_lifetime = 0;
		
		$smartyPath = MM_APP_ROOT.'/data/smarty';
		$smarty->template_dir = MM_ROOT.'/static/tpl';
		$smarty->compile_dir = $smartyPath.'/templates_c';
		$smarty->config_dir =$smartyPath.'/configs';
		$smarty->cache_dir = $smartyPath.'/cache';
		$smarty->left_delimiter="<!--{";
		$smarty->right_delimiter="}-->";
		
		$arrVars = array(
			'pageTitle' => '标题',		
		);
		
		foreach($arrVars as $k => $v)
			$smarty->assign($k , $v);
		
		return $smarty;
	}
	
	/**
	 * 判断ip地址是否在合法范围内
	 */
	public static function checkAllowIp()
	{
		$ip=MmClientInfo::getClientIp();
		$allow = Mm::getByKey("allow_ip");
		//判断是否是在ip白名单
		if(!in_array($ip,$allow))
		{
			echo "Access Denyed!";
			Mm::stop();
		}
	}
	
	/**
	 * 改变日期的格式
	 * 02/16/12 变成 2012-02-16
	 */
	public static function changeDateFormat($str)
	{
		$temp = explode('/',$str);
		/**
		 * 判断是否为数字
		 */
		foreach($temp as $key=>$value)
		{
			if(!is_numeric($value))
			 return false;
		}
		return $temp[2].'-'.$temp[0].'-'.$temp[1];	
	}
	/**
	 * int 型的版本号转为string型的版本号
	 */
	public static function versionIntToString($ver)
	{
		$ver = (int)$ver;
		$main = $ver>>24;
		$temp = $ver - ($main<<24);
		$sub = $temp>>16;
		$temp = $temp - ($sub<<16);
		$patch = $temp>>12;
		$build = $temp - ($patch<<12);
		/**
		 * 过滤build为10的倍数的
		 */
		if(($build%10)!=0)
			return FALSE;
		return $main.'.'.$sub.'.'.$patch.'.'.$build;
	}
	
	/**
	 * string型的版本号转int型
	 */
	public static function versionStringToInt($ver)
	{
		$temp = explode('.', $ver);
		/**
		 * 判断是否为数字
		 */
		foreach($temp as $key=>$value)
		{
			if(!is_numeric($value))
			 return false;
		}
		
		return ($temp[0]<<24)+($temp[1]<<16)+($temp[2]<<12)+$temp[3];
	}
	
	/**
	 * mac地址转1-9（所有位数相加再除以10）返回所属部分
	 */
	public static function macToPart($mac)
	{
		$hex = array(
			'0'=>0,
			'1'=>1,
			'2'=>2,
			'3'=>3,
			'4'=>4,
			'5'=>5,
			'6'=>6,
			'7'=>7,
			'8'=>8,
			'9'=>9,
			'A'=>10,
			'a'=>10,
			'B'=>11,
			'b'=>11,
			'C'=>12,
			'c'=>12,
			'D'=>13,
			'd'=>13,
			'E'=>14,
			'e'=>14,
			'F'=>15,
			'f'=>15,
		);
		//取mac地址所有位相加,
		$numbers = str_split($mac);
		$num = 0;
		foreach ($numbers as $number)
		{
			if(!isset($hex[$number]))
				return false;
			$num += hexdec($number);
			
		}
		$part = ($num % 10) + 1;//所属升级部分
		return $part;
	}
}
