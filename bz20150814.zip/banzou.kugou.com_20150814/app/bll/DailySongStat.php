<?php
/**
 * 日播放统计相关逻辑
 * 
 * @category Kugou.Com
 * @package bll\songStat
 * @copyright 广州酷狗科技有限公司版权所有 Copyright (c) 2004-2012 (http://www.kugou.com)
 * @author saoyor(345747439@qq.com)
 */

class DailySongStat{
	const EFFECTIVETIME='effectiveTime';
	const EFFECTIVECOUNT='effectiveCount';
	/**
	 * 对歌名的过滤
	 * @param string $songName
	 * @return string|boolean
	 */
	public static function songNameFilter($songName)
	{
		$index=strpos($songName,'伴奏');
		if($index!=false)
		{
			$songNameItem=explode('-',$songName);
			if(count($songNameItem)==1)
				return $songName;
			elseif(count($songNameItem)>=2)
				return $songNameItem[0].' - '.$songNameItem[1];
		}else{
			return false;
		}
	}
	/**
	 * 判断是否为有效的统计
	 * @param string $mac
	 */
	public static function effectiveTime($mac)
	{
		$key=self::EFFECTIVETIME.$mac;
		$memcached=\ServiceApp::getMemcached();
		$retvl = $memcached->get($key);
		if ($memcached->getResultCode() == $memcached::RES_NOTFOUND)
		{
			$memcached->set($key,1,30);
			return 1;
		}
		return 0;
	}
	/**
	 * 添加同一首哥曲 同一台电脑的 播放的次数
	 * @param int $mac
	 * @param int $hash
	 * @return int
	 */
	public static function addStatSongCount($mac,$hash)
	{
		$key=self::EFFECTIVECOUNT.$mac.$hash;
		$memcached=\ServiceApp::getMemcached();
		$retvl = $memcached->increment($key,1);
		return $retvl;
	}
	/**
	 * 数据统计（定时器使用） 
	 */
	public static function DailyStatSong()
	{
		$today=strtotime('today');
		$starTime=strtotime('today')-86400;
		$dal=new \LogSongDAL();
		$sql='SELECT hash,songName,count(*) AS dailyCount FROM '.$dal->_getTable().' WHERE addTime>='.$starTime.' AND addTime<='.$today.' GROUP BY songName ORDER BY dailyCount DESC limit 200';
		$retvl=\MmDatabase::query($sql);
		
		$oldSongData=SongRankModule::getOldSongData();


		foreach ($retvl as $k=>$v)
		{
			$retvl[$k]['rank']=$k+1;
			if(isset($oldSongData[$v['hash']]))
			{
				$retvl[$k]['upRank']=$retvl[$k]['rank']-$oldSongData[$v['hash']]['rank'];
			}else {
				$retvl[$k]['upRank']=$retvl[$k]['rank'];
			}
		}	
		SongRankModule::clearTable();
		SongRankModule::songInsertMulti(array_values($retvl));

	}
	
}
