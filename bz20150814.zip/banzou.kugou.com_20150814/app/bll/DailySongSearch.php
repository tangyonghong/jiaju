<?php

class DailySongSearch
{
	/**
	 * 数据统计，定时器用
	 */
	public static function dailyCount()
	{
		$dal = new SearchSongDAL();
		$sql = 'SELECT songName,count(*) AS dailyCount FROM '.$dal->_getTable().' GROUP BY songName ORDER BY dailyCount DESC limit 200';
		$retvl=\MmDatabase::query($sql);
		print_r($retvl);
		if(!empty($retvl))
		{
			foreach ($retvl as $k=>$v)
			{
				$retvl[$k]['rank']=$k+1;
				$retvl[$k]['addTime'] = date("Y-m-d",strtotime("-1 day"));
			}
			var_dump($retvl);
			echo "0";
			//清空搜索记录
			SearchSongModule::clearTable();
			echo "1";
			SearchRankModule::searchInsertMulti(array_values($retvl));
			echo "2";
		}
	}
}