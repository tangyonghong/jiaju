<?php
class ExcelHelper
{
	public static function createExcel($title,$results)
	{
		/** Error reporting */
		error_reporting(E_ALL);
		ini_set('display_errors', TRUE);
		ini_set('display_startup_errors', TRUE);
		date_default_timezone_set('Europe/London');

		define('EOL',(PHP_SAPI == 'cli') ? PHP_EOL : '<br />');
		/** Include PHPExcel */
		require_once MM_APP_ROOT.'/../Classes/PHPExcel.php';

		$letter = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z');
		
		$objPHPExcel = new PHPExcel();

		$objPHPExcel->getProperties()->setCreator("Maarten Balliauw")
										->setLastModifiedBy("Maarten Balliauw")
										->setTitle("PHPExcel Test Document")
										->setSubject("PHPExcel Test Document")
										->setDescription("Test document for PHPExcel, generated using PHP classes.")
										->setKeywords("office PHPExcel php")
										->setCategory("Test result file");

		//在第一行插入title信息
		$i = 0;
		foreach ($title as $t)
		{
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue($letter[$i].'1',$t);
			$i += 1;
		}
		//从第二行开始
		$i = 2;
		foreach ($results as $data)
		{
			$keys = array_keys($data);
			$j = 0;
			foreach ($keys as $key)
			{
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue($letter[$j].$i,$data[$key]);
				$j += 1;
			}			
			$i += 1;
		}
		$objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
		//存储文件名为时间搓和md5值
		$name = time().md5(json_encode($results));
		//再进行base64编码
		$name = base64_encode($name);
		$fileLocation = Mm::getByKey("ExcelLoc").'/'.$name;
		$objWriter->save($fileLocation);
		return $name;
	}	
}
