<?php
/**
 * 默认App类
 * @author mmfei
 */
class DefaultApp extends MmAppBase
{
	public static function actionDbToCode()
	{
		return MmHelper::DbToCode();
	}
	public static function actionAdmin()
	{
		AdminAction::index();
	}
	public static function actionAc()
	{
		MmGenerator::ActiveRecord();
	}
	public static function actionCv()
	{
		return MmCodeReview::run();
	}
	public static function actionInstall()
	{
		$sqlFile = MM_APP_ROOT . '/install.sql';
		$installLock = MM_APP_DATA_DIR.'/install.lock';
		if(file_exists($installLock))
			Mm::stop('App has been installed!');
		if(file_exists($sqlFile))
		{
			//execute sql
			$s = file_get_contents($sqlFile);
			$arrSql = explode(';', $s);
			foreach($arrSql as $sql)
			{
				$sql = trim($sql);
				if($sql)
					MmDatabase::execute($sql);
			}
		}
		file_put_contents($installLock, date('Y-m-d H:i:s'));
		Mm::stop('Install completed!Thanks!');
	}
/**
	 * 重写run方法
	 */
	public function run()
	{
		//拦截检查是否是已经登录
		MyHelper::checkAllowIp();
		if(!AdminAction::checkLogin())
		{
			//未登录
//			AdminAction::actionLogin();
			header('Location: http://log.fanxing.com/report');
		}
		else 
		{
			//已经登录
			$base = new MmAppBase();
			$base->run();
		}
		
	}
}