<?php

class OffvocalService extends \MmServerBase{
	/**
	 * 获取版本信息
	 * @param int $ver
	 * @return array
	 */
	public function Version($ver,$mac = '0')
	{
		$vers=VerManageModule::getPromtVer();
		if(empty($vers))
		{
			return array('isnew'=>0,'ver'=>(int)$ver);
		}else{
			$retvl=$vers[0];
			if($ver>=$retvl['ver'])
			{
				return array('isnew'=>0,'ver'=>(int)$ver);
			}else{
				if($ver>=$retvl['mustUpVer'])
				{
					//提示升级，灰度升级
					if($retvl['upNum'] == 10)
					{
						//全部提示升级
						return array(
									'isnew'=>1,
									'ver'=>(int)$retvl['ver'],
									'type'=>(int)$retvl['type'],
									'describe'=>htmlspecialchars_decode($retvl['describe'],ENT_QUOTES),
									'url'=>$retvl['url'],
									'auurl'=>$retvl['auurl'],
									'aufilesize'=>$retvl['aufilesize'],
									'tpver'=>$retvl['tpver'],
									'tpurl'=>$retvl['tpurl'],
									'tpfilesize'=>$retvl['tpfilesize'],
						);
					}
					else{
						//如果默认为0的，则直接提示升级
						if($mac == '0')
						{
							return array(
									'isnew'=>1,
									'ver'=>(int)$retvl['ver'],
									'type'=>(int)$retvl['type'],
									'describe'=>htmlspecialchars_decode($retvl['describe'],ENT_QUOTES),
									'url'=>$retvl['url'],
									'auurl'=>$retvl['auurl'],
									'aufilesize'=>$retvl['aufilesize'],
									'tpver'=>$retvl['tpver'],
									'tpurl'=>$retvl['tpurl'],
									'tpfilesize'=>$retvl['tpfilesize'],
							);
						}
						//如果全部升级，则直接提示升级
						if($retvl['upNum'] == 'all')
						{
							return array(
									'isnew'=>1,
									'ver'=>(int)$retvl['ver'],
									'type'=>(int)$retvl['type'],
									'describe'=>htmlspecialchars_decode($retvl['describe'],ENT_QUOTES),
									'url'=>$retvl['url'],
									'auurl'=>$retvl['auurl'],
									'aufilesize'=>$retvl['aufilesize'],
									'tpver'=>$retvl['tpver'],
									'tpurl'=>$retvl['tpurl'],
									'tpfilesize'=>$retvl['tpfilesize'],
							);
						}
							
						$part = MyHelper::macToPart($mac);
						$upNum = json_decode($retvl['upNum'],true);
						//属于数组则提示升级
						if( in_array($part,$upNum))
						{
							return array(
									'isnew'=>1,
									'ver'=>(int)$retvl['ver'],
									'type'=>(int)$retvl['type'],
									'describe'=>htmlspecialchars_decode($retvl['describe'],ENT_QUOTES),
									'url'=>$retvl['url'],
									'auurl'=>$retvl['auurl'],
									'aufilesize'=>$retvl['aufilesize'],
									'tpver'=>$retvl['tpver'],
									'tpurl'=>$retvl['tpurl'],
									'tpfilesize'=>$retvl['tpfilesize'],
							);
						}
						else
						{
							//不提示升级
							return array('isnew'=>0,'ver'=>(int)$ver);
						}
					}
				}else{
					//强制升级
					return array(
								'isnew'=>1,
								'ver'=>(int)$retvl['ver'],
								'type'=>1,
								'describe'=>htmlspecialchars_decode($retvl['describe'],ENT_QUOTES),
								'url'=>$retvl['url'],
								'auurl'=>$retvl['auurl'],
									'aufilesize'=>$retvl['aufilesize'],
									'tpver'=>$retvl['tpver'],
									'tpurl'=>$retvl['tpurl'],
									'tpfilesize'=>$retvl['tpfilesize'],
							
					);
				}
					
			}

		}

	}
			
	/**
	 * 获取热歌排行榜
	 */
	public function getHotSongRank()
	{
		Log::debug(MmClientInfo::getClientIp()." start query hot song rank");
		$answer = SongRankModule::getHotSongRank(100);
		Log::debug("answer is ").json_encode($answer);
		return $answer;
	}
	/**
	 * 获取飙升歌排行榜
	 */
	public function getUpSongRank()
	{
		return SongRankModule::getUpSongRank(100);
	}
	public function getSongInfo()
	{
		return SongRankModule::getSongInfo();
	}
	/**
	 * 获取最新版本
	 */
	public function getNewVer()
	{
		$retvl=array();
		$vers=VerManageModule::getpulicVer();
		if(!empty($vers))
			$retvl=$vers[0];
		return $retvl;
	}
	/**
	 * test
	 */
	public static function test()
	{
		$dal = new MyTestDAL();
		$vers = $dal->getListBy(array('status'=>1),array('addTime'=>'desc'));
		return $vers[0];
	}
	
	/********************************************************************************************************************
	 * 繁星客户端的api
	 ********************************************************************************************************************/
	/**
	 * 获取版本信息
	 * @param int $ver
	 * @return array
	 */
	public static function clientVersion($ver)
	{
		$vers=ClientVerManageModule::getPromtVer();	

		if(empty($vers))
		{
			return array('isnew'=>0,'ver'=>$ver);
		}else{
			$retvl=$vers[0];
			if($ver>=$retvl['ver'])
			{
				return array('isnew'=>0,'ver'=>$ver);
			}else{
				if(1==$retvl['type'])
				{
					return array(
							'isnew'=>1,
							'ver'=>(int)$retvl['ver'],
							'type'=>(int)$retvl['type'],
							'describe'=>$retvl['describe'],
							'url'=>$retvl['url']
					);
				}else{
					if($ver>$retvl['mustUpVer'])
					{
						return array(
								'isnew'=>1,
								'ver'=>(int)$retvl['ver'],
								'type'=>(int)$retvl['type'],
								'describe'=>$retvl['describe'],
								'url'=>$retvl['url']
						);
					}else{
						return array(
								'isnew'=>1,
								'ver'=>(int)$retvl['ver'],
								'type'=>1,
								'describe'=>$retvl['describe'],
								'url'=>$retvl['url']
						);
					}
					
				}
				
			}
				
		}
	}
	/**
	 * 获取客户端最新版本
	 */
	public static function getClientNewVer()
	{
		$retvl=array();
		$vers=ClientVerManageModule::getpulicVer();
		if(!empty($vers))
			$retvl=$vers[0];
		return $retvl;
	}
}

