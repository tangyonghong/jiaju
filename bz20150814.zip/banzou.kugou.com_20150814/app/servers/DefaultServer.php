<?php
/**
 * 默认接口类
 * @author mmfei
 */
class DefaultServer extends MmServerBase
{
	/**
	 * 正常返回接口
	 * @return array
	 */
	public static function index()
	{
		return array(
			'haha'
		);
	}
	/**
	 * 异常接口
	 * @throws Exception
	 */
	public static function error()
	{
		throw new Exception('Error Test');
		
		echo '这里程序不会返回';
	}
}