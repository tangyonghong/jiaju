<?php
/**
 * 
 * 
 * @category Kugou.Com
 * @package StatService
 * @copyright 广州酷狗科技有限公司版权所有 Copyright (c) 2004-2012 (http://www.kugou.com)
 * @author saoyor(345747439@qq.com)
 */
class StatService extends \MmServerBase {
	
	public function playStat($hash,$songName,$bitRate,$mac,$srcType,$userId,$ver,$OSver)
	{
		
		$songName=DailySongStat::songNameFilter($songName);	
 		if(false==$songName) return false;
//  		$effectiveTime=DailySongStat::effectiveTime($mac);
//  		if(0==$effectiveTime) return false;
//  		$StatSongCount=DailySongStat::addStatSongCount($mac, $hash);
//  		if(10<=$StatSongCount) return false;
 		
		SongLogModule::insertData($hash,$songName,$bitRate,$mac,$srcType,$userId,$ver,$OSver);
		return true;
		
	}
	/**
	 * 搜索信息收集
	 */
	public static function searchStat($songName,$mac,$ver,$OSver)
	{
		SearchSongModule::insertData($songName, $mac, $ver, $OSver);
		return true;
	}
}
