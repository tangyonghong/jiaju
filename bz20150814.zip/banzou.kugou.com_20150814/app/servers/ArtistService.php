<?php

/**
 * 艺人客户端
 * @author root
 *
 */
class ArtistService extends \MmServerBase{
	
	public static function behavior($id,$mac,$ver,$osVer,$userId)
	{
		//繁星伴奏的行为日志
		$filename = Mm::getByKey("behaviorLogPath")."/".Mm::getByKey("artist_pre").date("Y-m-d");
		
		$file = fopen($filename, 'a+');
		$towrite = date("H:i:s").'|'.$id.'|'.$mac.'|'.$ver.'|'.$osVer.'|'.MmClientInfo::getClientIp().'|'.$userId.'|'."\r\n";
		fwrite($file, $towrite);
		fclose($file);
	}
}