<?php
/**
 * token
 * @author mmfei
 */
class TokenService extends MmServerBase
{
	
}