<?php
class EffectService extends \MmServerBase
{
	public static function all()
	{
		//返回所有
		$effect = EffectModule::getAll();
		$res1 = array();
		$res2 = array();
		foreach ($effect as $key=>$value)
		{
			if($value['status'] == 1)
			{
				$temp = array();
				$temp['file'] = $value["url"];
				$temp['img'] = $value["img"];
				$temp['filemd5'] = $value["md5"];
				$temp['imgmd5'] = $value["imgmd5"];
				if($value["kind"]==1)
					$res1[] = $temp;
				if($value["kind"]==2)
					$res2[] = $temp;
			}
		}
		$retval = array();
		$retval["widget"] = array(
			"length" => count($res1),
			"data" => $res1,
		);
		$retval["light"] = array(
			"length" => count($res2),
			"data" => $res2,
		);
		
		return $retval;
	}
}