<?php
/**
 * 
 * 渠道上包的接口服务
 * @author chenxiaochen
 *
 */
class ChannelService extends \MmServerBase
{
	/**
	 * 渠道获取RSA加密公钥
	 */
	public static function certification($ver)
	{
		return ChannelModule::getRSAPublicKey();
	}
	
	public static function verify($ver,$key,$val)
	{
//		$filename = $_SERVER['DOCUMENT_ROOT'].'/'.date('Y-m-d');
//		$file = fopen($filename, 'a+');
//		$towrite = $ver.'|'.$key.'|'.$val."|\r\n";
//		fwrite($file, $towrite);
//		$ver = mysql_real_escape_string($v);
//		$key = mysql_real_escape_string($k);
//		$val = mysql_real_escape_string($va);
		$private_key = ChannelModule::getRSAPrivateKey($key);
//		echo $private_key;
		$temp = explode('|',$private_key);
		$n = $temp[0];
		$d = $temp[1];
		$data =  escapeshellarg($val);
		$length =  strlen(escapeshellarg($val))/2;
		$message = shell_exec(Mm::getByKey("RSAProgram").' '.$data.' '.$length.' '.$n.' '.$d);
		$message = str_replace(array(chr(13)," "), "", $message);
//		echo $message;
		$userInfo = json_decode($message);
		//check is a valid json 
		if(!is_null($userInfo))
		{
//			$mac = mysqli::real_escape_string($userInfo->mac);
//			$harddisk = mysqli::real_escape_string($userInfo->harddisk);
//			$time = mysqli::real_escape_string($userInfo->time);
//			$channel = mysqli::real_escape_string($userInfo->channel);
			$mac = $userInfo->mac;
			$harddisk = $userInfo->harddisk;
			$time = $userInfo->time;
			$channel = $userInfo->channel;
			ChannelModule::insertChannelLog($mac,$harddisk,$time,$channel);
			return true;
		}
		return false;
	}
}