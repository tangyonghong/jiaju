<?php
/**
 * log用户的日常行为
 * @category Kugou.Com
 * @copyright 广州酷狗科技有限公司版权所有 Copyright (c) 2004-2012 (http://www.kugou.com)
 * @author chenxiaochen
 */
class BehaviorService extends \MmServerBase{
	
	/**
	 * 
	 * 伴奏的用户行为的记录
	 * @param $id 用户行为的id
	 * @param $mac 用户的mac地址
	 * @param $ver 客户端的版本号
	 * @param $osVer 客户操作系统
	 */
	public static function behavior($id,$mac,$ver,$osVer)
	{
		BehaviorLogModule::insertData($id, $mac, $ver, $osVer,0);
		return true;
	}
	
	/**
	 * 记录主播使用的录像设备
	 * @param $id 主播id
	 * @param $brower 浏览器
	 * @param $software 设备描述
	 */
	public static function playSoftware($id,$brower,$software)
	{
		PlaySoftwareLogModule::insertData($id,$brower,$software);
		return true;
	}
	
	/**
	 * 繁星客户端的用户行为记录
	 */
	public static function client($id,$mac,$ver,$osVer)
	{
		BehaviorLogModule::insertData($id, $mac, $ver, $osVer,1);
		return true;
	}
	
	
	/**
	 * 高清插件的记录
	 * @param unknown_type $id
	 * @param unknown_type $mac
	 * @param unknown_type $ver
	 * @param unknown_type $osVer
	 * @param unknown_type $roomId 房间id号
	 * @param unknown_type $userId 用户id
	 * @param unknown_type $Info 用户信息
	 */
	public static function hifi($id,$mac,$ver,$osVer,$roomId,$userId,$Info)
	{
		BehaviorLogModule::insertHifi($id,$mac,$ver,$osVer,$roomId,$userId,$Info);
		return true;
	}
	
	
	/**
	 * 统计用户的一些日常的功能使用，如使用拍照等
	 * @param unknown_type $id
	 * @param unknown_type $mac
	 * @param unknown_type $ver
	 * @param unknown_type $osVer
	 * @param unknown_type $value
	 * @param unknown_type $info
	 */
	public static function func($id,$mac,$ver,$osVer,$value,$info)
	{
		BehaviorLogModule::insertFunc($id,$mac,$ver,$osVer,$value,$info);
		return true;
	}
}