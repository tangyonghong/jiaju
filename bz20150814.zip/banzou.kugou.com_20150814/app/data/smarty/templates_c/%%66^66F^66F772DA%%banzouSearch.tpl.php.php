<?php /* Smarty version 2.6.26, created on 2014-03-24 18:03:45
         compiled from admin/banzouSearch.tpl.php */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/header.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php if ($this->_tpl_vars['excellocation']): ?>
<head><meta http-equiv="refresh" content="0;<?php echo $this->_tpl_vars['excellocation']; ?>
"></head>
<?php endif; ?>
<body>
	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/topbar.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/menus.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
	<!-- external javascript================================================== -->
	<!-- Placed at the end of the document so the pages load faster -->
	<div id="content" class="span10">
		<form action="/index.php/VerManage/banzouSearch" method="get" name="mainForm">
			查询日期：
			<input type="text" class="input-xlarge datepicker" id="date" name="date" value="<?php echo $this->_tpl_vars['date']; ?>
"> 
			<input type="hidden" name="action" value="query">
			<button type="submit" class="btn btn-primary" onclick="submitFun('query')">查询</button> 
			<button type="submit" class="btn btn-primary" onclick="submitFun('excel')">excel导出</button> 
		</form>
		<div class="box-content">
			<table class="table table-striped table-bordered bootstrap-datatable datatable" >
				<thead>
					<tr>
						<th>序号</th>
						<th>搜索内容</th>
						<th>搜索次数</th>
					</tr>
				</thead>
				<tbody>
					<?php if ($this->_tpl_vars['datalist']): ?>
	        		<?php $_from = $this->_tpl_vars['datalist']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['vo']):
?>
					<tr>
						<td class="center"><?php echo $this->_tpl_vars['vo']['rank']; ?>
</td>
						<td class="center"><?php echo $this->_tpl_vars['vo']['songName']; ?>
</td>
						<td class="center"><?php echo $this->_tpl_vars['vo']['dailyCount']; ?>
</td>
					</tr>
					<?php endforeach; endif; unset($_from); ?>
	       			<?php endif; ?>
				</tbody>
			</table>            
		</div>
	</div>
</body>
</html>
<script type="text/javascript">
function submitFun(act)
{
	mainForm.action.value = act;
	mainForm.submit();
}
</script>