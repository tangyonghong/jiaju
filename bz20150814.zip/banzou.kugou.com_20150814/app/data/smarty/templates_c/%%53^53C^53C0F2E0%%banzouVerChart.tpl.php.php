<?php /* Smarty version 2.6.26, created on 2014-08-07 10:35:21
         compiled from admin/banzouVerChart.tpl.php */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/header.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<body>
	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/topbar.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/menus.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
	<script src="http://s1.bdstatic.com/r/www/cache/ecom/esl/1-6-10/esl.js"></script>
	
	<!-- external javascript================================================== -->
	<!-- Placed at the end of the document so the pages load faster -->
	<div id="content" class="span10">
		<form action="/index.php/BanzouVer/existVer" method="get" name="mainForm">
			查询日期：
			<input type="text" class="input-xlarge datepicker" id="day" name="day" value="<?php echo $this->_tpl_vars['date']; ?>
"> 
			<button type="submit" class="btn btn-primary" onclick="submitFun('query')">查询</button> 
		</form>
		<div id="main" style="height:600px"></div>
	</div>
					
	</div>
	
</body>
</html>
<?php if (isset ( $this->_tpl_vars['data'] )): ?>
<script type="text/javascript">
        // 路径配置
    require.config({
        paths:{ 
            'echarts' : 'http://echarts.baidu.com/build/echarts',
            'echarts/chart/pie' : 'http://echarts.baidu.com/build/echarts'
        }
    });
    
    // 使用
    require(
        [
            'echarts',
            'echarts/chart/pie' // 使用柱状图就加载bar模块，按需加载
        ],
        function (ec) {
            // 基于准备好的dom，初始化echarts图表
            var myChart = ec.init(document.getElementById("main")); 
            
            var option =  {
            	    title : {
            	        text: '<?php echo $this->_tpl_vars['data']['title']; ?>
',
            	        x:'center'
            	    },
            	    tooltip : {
            	        trigger: 'item',
            	        formatter: "{a} <br/>{b} : {c} ({d}%)"
            	    },
            	    legend: {
            	        data:<?php echo $this->_tpl_vars['data']['legend']; ?>
,
            	        orient:'vertical',
            	        x : 'left',
            	    },
            	    toolbox: {
            	        show : true,
            	        feature : {
            	            mark : {show: true},
            	            dataView : {show: true, readOnly: false},
            	            restore : {show: true},
            	            saveAsImage : {show: true}
            	        }
            	    },
            	    calculable : true,
            	    series : [
            	              {
            	                  name:'',
            	                  type:'pie',
            	                  radius : '55%',
            	                  center: ['50%', '60%'],
            	                  data:<?php echo $this->_tpl_vars['data']['series']; ?>

            	              }
            	          ]
            	};
                
    
            // 为echarts对象加载数据 
            myChart.setOption(option); 
        }
    );
</script>
<?php endif; ?>