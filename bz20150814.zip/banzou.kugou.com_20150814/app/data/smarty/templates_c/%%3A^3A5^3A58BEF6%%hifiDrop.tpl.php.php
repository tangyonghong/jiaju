<?php /* Smarty version 2.6.26, created on 2014-09-29 17:17:25
         compiled from admin/hifiDrop.tpl.php */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/header.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php if ($this->_tpl_vars['excellocation']): ?>
<head><meta http-equiv="refresh" content="0;<?php echo $this->_tpl_vars['excellocation']; ?>
"></head>
<?php endif; ?>
	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/topbar.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/menus.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
	<!-- external javascript================================================== -->
	<!-- Placed at the end of the document so the pages load faster -->
	
	<h3>最近1个小时的丢包主播</h3>
	<div id="content" class="span10">
		<table class="table table-striped table-bordered bootstrap-datatable datatable">
			<thead>
				<tr>
					<th>时间</th>
					<th>mac</th>
					<th>版本</th>
					<th>os</th>
					<th>房间id</th>
					<th>用户id</th>
					<th>audio</th>
					<th>video</th>
					<th>cpu</th>
					<th>v_rate</th>
					<th>操作</th>
				</tr>
			</thead>
			<tbody>
				<?php if ($this->_tpl_vars['drops']): ?>
        		<?php $_from = $this->_tpl_vars['drops']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['vo']):
?>
				<tr>
					<?php $_from = $this->_tpl_vars['vo']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['v']):
?>
					<td class="center"><?php echo $this->_tpl_vars['v']; ?>
</td>
					<?php endforeach; endif; unset($_from); ?>
					<td class="center">
					<a target="_blank" href="http://fanxing.kugou.com/<?php echo $this->_tpl_vars['vo'][4]; ?>
"  >
									<i class="icon-edit icon-white"></i>
									房间
						</a>
					</td>
				</tr>
				<?php endforeach; endif; unset($_from); ?>
       			<?php endif; ?>
			</tbody>
		</table>            
					
	</div>
	
</body>
<script type="text/javascript">
function submitFun(act)
{
	mainForm.action.value = act;
	mainForm.submit();
}
</script>
</html>