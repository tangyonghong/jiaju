<?php /* Smarty version 2.6.26, created on 2014-01-10 14:12:50
         compiled from admin/clientAddVer.tpl.php */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/header.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<body>
	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/topbar.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/menus.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
	<!-- external javascript================================================== -->
	<!-- Placed at the end of the document so the pages load faster -->
	<div id="content" class="span10">
		<div class="row-fluid sortable">
			<div class="box span12">
				<div class="box-header well" data-original-title>
					<h2><i class="icon-edit"></i> Form Elements</h2>
						<div class="box-icon">
						<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
						<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
						<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
					</div>
				</div>
				<div class="box-content">
					<form class="form-horizontal" method="post" enctype="multipart/form-data" name="myform">
						 <fieldset>
						 	<legend>添加版本</legend>
						 	<div class="control-group">
							  <label class="control-label" for="typeahead">版本号</label>
							  <div class="controls">
								<input type="text" class="span6 typeahead" name='ver' value=''>
							  </div>
							</div>
							<div class="control-group">
							  <label class="control-label" for="typeahead">版本名</label>
							  <div class="controls">
								<input type="text" class="span6 typeahead" name='verName' value=''>
							  </div>
							</div>
							<div class="control-group">
							  <label class="control-label" for="typeahead">必须更新的版本</label>
							  <div class="controls">
								<input type="text" class="span6 typeahead" name='mustUpVer' value=''>
							  </div>
							</div>
							<div class="control-group">
							  <label class="control-label" for="typeahead">版本地址</label>
							  <div class="controls">
								<input type="text" class="span6 typeahead" name='url' value=''>
							  </div>
							</div>
							<div class="control-group">
								<label class="control-label">当前发布版本</label>
								<div class="controls">
								  <label class="radio">
									<input type="radio" name="verStatus" id="optionsRadios1" value="0" checked="">
									 不是
								  </label>
								  <div style="clear:both"></div>
								  <label class="radio">
									<input type="radio" name="verStatus" id="optionsRadios2" value="1">
									是
								  </label>
								</div>
							 </div>
							<div class="control-group">
								<label class="control-label">升级类型</label>
								<div class="controls">
								  <label class="radio">
									<input type="radio" name="uptype" id="optionsRadios1" value="0" checked="">
									 提示升级
								  </label>
								  <div style="clear:both"></div>
								  <label class="radio">
									<input type="radio" name="uptype" id="optionsRadios2" value="1">
									强制升级
								  </label>
								  <div style="clear:both"></div>
								  <label class="radio">
									<input type="radio" name="uptype" id="optionsRadios2" value="2">
									不提示升级
								  </label>
								</div>
							 </div>
						 	<div class="control-group">
								  <label class="control-label" for="textarea2">版本说明</label>
								  <div class="controls">
									<textarea name='drsc' class="cleditor" id="textarea2" rows="3"></textarea>
								  </div>
							</div>
						 	<div class="form-actions">
								  <button type="submit" class="btn btn-primary">保存</button>
								  <button type="reset" class="btn">取消</button>
							</div>
						 </fieldset>
					</form>
				</div>
			</div>
			
		</div>
	</div>
	
</body>
</html>