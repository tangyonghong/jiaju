<?php /* Smarty version 2.6.26, created on 2012-12-08 21:32:10
         compiled from /mnt/develop/works/www/mmfei.cn/fw.mmfei.cn/static/themes/default/tpl/index.tpl.php */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'default', '/mnt/develop/works/www/mmfei.cn/fw.mmfei.cn/static/themes/default/tpl/index.tpl.php', 5, false),)), $this); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "common/blog.header.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
		<div class='wrap'>
			<section class='content'>
				<header id='blogHeader'>
					<h1><a href="<?php echo ((is_array($_tmp=@$this->_tpl_vars['blogData']['url'])) ? $this->_run_mod_handler('default', true, $_tmp, "/") : smarty_modifier_default($_tmp, "/")); ?>
" title="<?php echo $this->_tpl_vars['blogData']['blogName']; ?>
 <?php echo $this->_tpl_vars['blogData']['blogKey']; ?>
"><?php echo $this->_tpl_vars['blogData']['blogName']; ?>
</a></h1>
					<form action="/" method="get">
						<input name="tag" type="text" class="search" placeholder="Search..." />
					</form>
					<p id='blogDesc'><?php echo $this->_tpl_vars['blogData']['desc']; ?>
</p>
				</header>

				<article id="1">
					<figure>
						<a href="#">
							<img src="http://m3.img.libdd.com/farm5/2012/1121/09/6DE3CFC3BA9A4ADD407872E2DCA1988104A1A642BFDBC_500_375.jpg" large="http://m2.img.libdd.com/farm5/2012/1121/09/6DE3CFC3BA9A4ADD407872E2DCA198813C41076AFD6DA_1280_960.jpg" alt="" />
							<mark>查看大图</mark>
						</a>
					</figure>
					<section class='description'><p>文章描述</p></section>
					<footer>
						<ul>
							<li class='date'><time pubdate='三天前'>三天前</time></li>
							<li class='tags'>
								<dl>
									<dt>标签</dt>
									<dd><a href="#" target="_blank">标签1</a></dd>
									<dd><a href="#" target="_blank">标签1</a></dd>
									<dd><a href="#" target="_blank">标签1</a></dd>
								</dl>
							</li>
							<li class='category'><a href="#">类型2</a></li>
						</ul>
					</footer>
				</article>

				<footer class="pageNav">
					<nav>
						<ul>
							<li class="next"><a href="http://iphonegraphy.diandian.com/page/2">下一页</a></li>
						</ul>
					</nav>
				</footer>
			</section>
		</div>

		<aside>
			<dl>
				<dt>木木飞</dt>
				<dd><a href="#" title="木木飞"><img src="#2012-11-24" alt="木木飞" /></a></dd>
			</dl>
		</aside>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "common/blog.footer.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>