<?php /* Smarty version 2.6.26, created on 2014-01-10 11:32:42
         compiled from admin/banzouPlaySoftware.tpl.php */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'string_format', 'admin/banzouPlaySoftware.tpl.php', 43, false),)), $this); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/header.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php if ($this->_tpl_vars['excellocation']): ?>
<head><meta http-equiv="refresh" content="0;<?php echo $this->_tpl_vars['excellocation']; ?>
"></head>
<?php endif; ?>
<body>
	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/topbar.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/menus.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
	<!-- external javascript================================================== -->
	<!-- Placed at the end of the document so the pages load faster -->
	<div id="content" class="span10">
	<form action="/index.php/VerManage/banzouPlaySoftware" method="get" name="mainForm">
		查询日期：
		<input type="text" class="input-xlarge datepicker" id="start" name="start" value="<?php echo $this->_tpl_vars['start']; ?>
"> 
		至：
		<input type="text" class="input-xlarge datepicker" id="end" name="end" value="<?php echo $this->_tpl_vars['end']; ?>
"> 
		<input type="hidden" name="action" value="query">
		<button type="submit" class="btn btn-primary" onclick="submitFun('query')">查询</button> 
		<button type="submit" class="btn btn-primary" onclick="submitFun('excel')">excel导出</button> 
	</form>
	</div>
	<div id="content" class="span10">
		<table class="table table-striped table-bordered bootstrap-datatable datatable">
			<thead>
				<tr>
					<th>日期</th>
					<th>总次数/人数</th>
					<th>繁星伴奏次数/人数/人数比例</th>
					<th>9158次数/人数/人数比例</th>
					<th>六间房次数/人数/人数比例</th>
					<th>YY次数/人数/人数比例</th>
					<th>KK房次数/人数/人数比例</th>
					<th>其他次数/人数/人数比例</th>
				</tr>
			</thead>
			<tbody>
				<?php if ($this->_tpl_vars['statistic']): ?>
        		<?php $_from = $this->_tpl_vars['statistic']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['vo']):
?>
        		<?php $this->assign('sumNum', $this->_tpl_vars['vo']['FanXingBanZouNum']+$this->_tpl_vars['vo']['9158Num']+$this->_tpl_vars['vo']['6RoomsNum']+$this->_tpl_vars['vo']['YYNum']+$this->_tpl_vars['vo']['KKNum']+$this->_tpl_vars['vo']['videoOtherNum']); ?>
        		<?php $this->assign('sumUser', $this->_tpl_vars['vo']['FanXingBanZouUser']+$this->_tpl_vars['vo']['9158User']+$this->_tpl_vars['vo']['6RoomsUser']+$this->_tpl_vars['vo']['YYUser']+$this->_tpl_vars['vo']['KKUser']+$this->_tpl_vars['vo']['videoOtherUser']); ?>
				<tr>
					<td class="center"><?php echo $this->_tpl_vars['vo']['date']; ?>
</td>
					<td class="center"><?php echo $this->_tpl_vars['sumNum']; ?>
/<?php echo $this->_tpl_vars['sumUser']; ?>
</td>
					<td class="center"><?php echo $this->_tpl_vars['vo']['FanXingBanZouNum']; ?>
/<?php echo $this->_tpl_vars['vo']['FanXingBanZouUser']; ?>
/<?php echo ((is_array($_tmp=$this->_tpl_vars['vo']['FanXingBanZouUser']/$this->_tpl_vars['sumUser']*100)) ? $this->_run_mod_handler('string_format', true, $_tmp, '%.1f') : smarty_modifier_string_format($_tmp, '%.1f')); ?>
%</td>
					<td class="center"><?php echo $this->_tpl_vars['vo']['9158Num']; ?>
/<?php echo $this->_tpl_vars['vo']['9158User']; ?>
/<?php echo ((is_array($_tmp=$this->_tpl_vars['vo']['9158User']/$this->_tpl_vars['sumUser']*100)) ? $this->_run_mod_handler('string_format', true, $_tmp, '%.1f') : smarty_modifier_string_format($_tmp, '%.1f')); ?>
%</td>
					<td class="center"><?php echo $this->_tpl_vars['vo']['6RoomsNum']; ?>
/<?php echo $this->_tpl_vars['vo']['6RoomsUser']; ?>
/<?php echo ((is_array($_tmp=$this->_tpl_vars['vo']['6RoomsUser']/$this->_tpl_vars['sumUser']*100)) ? $this->_run_mod_handler('string_format', true, $_tmp, '%.1f') : smarty_modifier_string_format($_tmp, '%.1f')); ?>
%</td>
					<td class="center"><?php echo $this->_tpl_vars['vo']['YYNum']; ?>
/<?php echo $this->_tpl_vars['vo']['YYUser']; ?>
/<?php echo ((is_array($_tmp=$this->_tpl_vars['vo']['YYUser']/$this->_tpl_vars['sumUser']*100)) ? $this->_run_mod_handler('string_format', true, $_tmp, '%.1f') : smarty_modifier_string_format($_tmp, '%.1f')); ?>
%</td>
					<td class="center"><?php echo $this->_tpl_vars['vo']['KKNum']; ?>
/<?php echo $this->_tpl_vars['vo']['KKUser']; ?>
/<?php echo ((is_array($_tmp=$this->_tpl_vars['vo']['KKUser']/$this->_tpl_vars['sumUser']*100)) ? $this->_run_mod_handler('string_format', true, $_tmp, '%.1f') : smarty_modifier_string_format($_tmp, '%.1f')); ?>
%</td>
					<td class="center"><?php echo $this->_tpl_vars['vo']['videoOtherNum']; ?>
/<?php echo $this->_tpl_vars['vo']['videoOtherUser']; ?>
/<?php echo ((is_array($_tmp=$this->_tpl_vars['vo']['videoOtherUser']/$this->_tpl_vars['sumUser']*100)) ? $this->_run_mod_handler('string_format', true, $_tmp, '%.1f') : smarty_modifier_string_format($_tmp, '%.1f')); ?>
%</td>
				</tr>
				<?php endforeach; endif; unset($_from); ?>
       			<?php endif; ?>
			</tbody>
		</table>            
					
	</div>
	
</body>
</html>
<script type="text/javascript">
function submitFun(act)
{
	mainForm.action.value = act;
	mainForm.submit();
}
</script>