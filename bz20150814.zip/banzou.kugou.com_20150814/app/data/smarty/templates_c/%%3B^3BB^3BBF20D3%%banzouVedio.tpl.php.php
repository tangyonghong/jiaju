<?php /* Smarty version 2.6.26, created on 2014-08-28 16:19:21
         compiled from admin/banzouVedio.tpl.php */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/header.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php if ($this->_tpl_vars['excellocation']): ?>
<head><meta http-equiv="refresh" content="0;<?php echo $this->_tpl_vars['excellocation']; ?>
"></head>
<?php endif; ?>
<body>
	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/topbar.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/menus.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
	<script src="http://s1.bdstatic.com/r/www/cache/ecom/esl/1-6-10/esl.js"></script>
	
	<!-- external javascript================================================== -->
	<!-- Placed at the end of the document so the pages load faster -->
	<div id="content" class="span10">
	<form action="/index.php/BanzouVedio/vedioPop" method="get" name="mainForm">
		版本号
			<select id="ver" name="ver" data-rel="chosen">
				<?php if ($this->_tpl_vars['datalist']): ?>
        		<?php $_from = $this->_tpl_vars['datalist']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['vo']):
?>
        		<option <?php if ($this->_tpl_vars['vo'] == $this->_tpl_vars['ver']): ?>selected="true"<?php endif; ?>><?php echo $this->_tpl_vars['vo']; ?>
</option> 
        		<?php endforeach; endif; unset($_from); ?>
       			<?php endif; ?>
			</select> 
		查询日期：
		<input type="text" class="input-xlarge datepicker" id="start" name="start" value="<?php echo $this->_tpl_vars['start']; ?>
"> 
		至：
		<input type="text" class="input-xlarge datepicker" id="end" name="end" value="<?php echo $this->_tpl_vars['end']; ?>
"> 
		<input type="hidden" name="action" value="query">
		<button type="submit" class="btn btn-primary" onclick="submitFun('query')">查询</button> 
		<button type="submit" class="btn btn-primary" onclick="submitFun('excel')">excel导出</button> 
	</form>
	</div>
	<div id="content" class="span10">
		<table class="table table-striped table-bordered bootstrap-datatable datatable">
			<thead>
				<tr>
					<th>日期</th>
					<th>高清-一般严重人数</th>
					<th>高清-一般严重次数</th>
					<th>高清-特别严重人数</th>
					<th>高清-特别严重次数</th>
					<th>普通模式人数</th>
					<th>普通模式次数</th>
				</tr>
			</thead>
			<tbody>
				<?php if ($this->_tpl_vars['statistic']): ?>
        		<?php $_from = $this->_tpl_vars['statistic']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['vo']):
?>
				<tr>
					<td class="center"><?php echo $this->_tpl_vars['vo']['date']; ?>
</td>
					<td class="center"><?php echo $this->_tpl_vars['vo']['h1user']; ?>
</td>
					<td class="center"><?php echo $this->_tpl_vars['vo']['h1num']; ?>
</td>
					<td class="center"><?php echo $this->_tpl_vars['vo']['h2user']; ?>
</td>
					<td class="center"><?php echo $this->_tpl_vars['vo']['h2num']; ?>
</td>
					<td class="center"><?php echo $this->_tpl_vars['vo']['nuser']; ?>
</td>
					<td class="center"><?php echo $this->_tpl_vars['vo']['nnum']; ?>
</td>
				</tr>
				<?php endforeach; endif; unset($_from); ?>
       			<?php endif; ?>
			</tbody>
		</table>
		<div id="main" style="height:450px"></div>				
	</div>
	
</body>
</html>
<script type="text/javascript">
function submitFun(act)
{
	mainForm.action.value = act;
	mainForm.submit();
}
</script>
<?php if (isset ( $this->_tpl_vars['chartData'] )): ?>
<script type="text/javascript">
//	document.getElementById("main").style.height = "1000px";
        // 路径配置
    require.config({
        paths:{ 
            'echarts' : 'http://echarts.baidu.com/build/echarts',
            'echarts/chart/bar' : 'http://echarts.baidu.com/build/echarts'
        }
    });
    
    // 使用
    require(
        [
            'echarts',
            'echarts/chart/bar' // 使用柱状图就加载bar模块，按需加载
        ],
        function (ec) {
            // 基于准备好的dom，初始化echarts图表
            var myChart = ec.init(document.getElementById("main")); 
            
            var option =   {
            	    title : {
            	        text: '<?php echo $this->_tpl_vars['chartData']['title']; ?>
',
            	    },
            	    tooltip : {
            	        trigger: 'axis'
            	    },
            	    legend: {
            	        data:<?php echo $this->_tpl_vars['chartData']['legend']; ?>

            	    },
            	    toolbox: {
            	        show : true,
            	        feature : {
            	            mark : {show: true},
            	            dataView : {show: true, readOnly: false},
            	            magicType : {show: true, type: ['line', 'bar']},
            	            restore : {show: true},
            	            saveAsImage : {show: true}
            	        }
            	    },
            	    calculable : true,
            	    grid: {y: 70, y2:30, x2:20},
            	    xAxis : [
            	        {
            	            type : 'category',
            	            data : <?php echo $this->_tpl_vars['chartData']['category']; ?>

            	        },
            	        {
            	            type : 'category',
            	            data : <?php echo $this->_tpl_vars['chartData']['category']; ?>

            	        }
            	    ],
            	    yAxis : [
            	        {
            	            type : 'value',
            	            axisLabel:{formatter:'{value}'}
            	        }
            	    ],
            	    series :  <?php echo $this->_tpl_vars['chartData']['series']; ?>

            	};
                
    
            // 为echarts对象加载数据 
            myChart.setOption(option); 
        }
    );
</script>
<?php endif; ?>