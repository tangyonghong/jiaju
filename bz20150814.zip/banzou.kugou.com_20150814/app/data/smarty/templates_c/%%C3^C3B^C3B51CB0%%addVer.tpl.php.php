<?php /* Smarty version 2.6.26, created on 2015-02-04 14:07:40
         compiled from admin/addVer.tpl.php */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/header.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<body>
	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/topbar.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/menus.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
	<!-- external javascript================================================== -->
	<!-- Placed at the end of the document so the pages load faster -->
	<div id="content" class="span10">
		<div class="row-fluid sortable">
			<div class="box span12">
				<div class="box-header well" data-original-title>
					<h2><i class="icon-edit"></i> Form Elements</h2>
						<div class="box-icon">
						<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
						<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
						<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
					</div>
				</div>
				<div class="box-content">
					<form class="form-horizontal" method="post" enctype="multipart/form-data" name="myform">
						 <fieldset>
						 	<legend>添加版本</legend>
						 	<div class="control-group">
							  <label class="control-label" for="typeahead">版本号</label>
							  <div class="controls">
								<input type="text" class="span6 typeahead" name='ver' value=''>
							  </div>
							</div>
							<div class="control-group">
							  <label class="control-label" for="typeahead">版本名</label>
							  <div class="controls">
								<input type="text" class="span6 typeahead" name='verName' value=''>
							  </div>
							</div>
							<div class="control-group">
							  <label class="control-label" for="typeahead">小于该版本全部强制升级</label>
							  <div class="controls">
								<input type="text" class="span6 typeahead" name='mustUpVer' value=''>
							  </div>
							</div>
							<div class="control-group">
							  <label class="control-label" for="typeahead">版本地址</label>
							  <div class="controls">
								<input type="text" class="span6 typeahead" name='url' value=''>
							  </div>
							</div>
							<div class="control-group">
							  <label class="control-label" for="typeahead">自动升级的主程序安装包下载地址</label>
							  <div class="controls">
								<input type="text" class="span6 typeahead" name='auurl' value=''>
							  </div>
							</div>
							<div class="control-group">
							  <label class="control-label" for="typeahead">自动升级的主程序安装包文件大小</label>
							  <div class="controls">
								<input type="text" class="span6 typeahead" name='aufilesize' value=''>
							  </div>
							</div>
							<div class="control-group">
							  <label class="control-label" for="typeahead">第三方库安装包版本</label>
							  <div class="controls">
								<input type="text" class="span6 typeahead" name='tpver' value=''>
							  </div>
							</div>
							<div class="control-group">
							  <label class="control-label" for="typeahead">第三方库安装包下载地址</label>
							  <div class="controls">
								<input type="text" class="span6 typeahead" name='tpurl' value=''>
							  </div>
							</div>
							<div class="control-group">
							  <label class="control-label" for="typeahead">第三方库安装包文件大小</label>
							  <div class="controls">
								<input type="text" class="span6 typeahead" name='tpfilesize' value=''>
							  </div>
							</div>
							<div class="control-group">
								<label class="control-label">当前发布版本</label>
								<div class="controls">
								  <label class="radio">
									<input type="radio" name="verStatus" id="optionsRadios1" value="0" checked="">
									 不是
								  </label>
								  <div style="clear:both"></div>
								  <label class="radio">
									<input type="radio" name="verStatus" id="optionsRadios2" value="1">
									是
								  </label>
								</div>
							 </div>
							<div class="control-group">
								<label class="control-label">升级类型</label>
								<div class="controls">
								  <label class="radio">
									<input type="radio" name="uptype" id="optionsRadios1" value="0" checked="">
									 提示升级
								  </label>
								  <div style="clear:both"></div>
								  <label class="radio">
									<input type="radio" name="uptype" id="optionsRadios2" value="2">
									不提示升级
								  </label>
								</div>
							 </div>
							 <div class="control-group">
								<label class="control-label">灰度升级部分</label>
								<div class="controls">
								  <label class="checkbox inline">
									<input type="checkbox" id="Checkbox1" name="upNum1" value="1"> 1
								  </label>
								  <label class="checkbox inline">
									<input type="checkbox" id="Checkbox2" name="upNum2" value="1"> 2
								  </label>
								  <label class="checkbox inline">
									<input type="checkbox" id="Checkbox3" name="upNum3" value="1"> 3
								  </label>
								  <label class="checkbox inline">
									<input type="checkbox" id="Checkbox4" name="upNum4" value="1"> 4
								  </label>
								  <label class="checkbox inline">
									<input type="checkbox" id="Checkbox5" name="upNum5" value="1"> 5
								  </label>
								</div>
								<div class="controls">
									<label class="checkbox inline">
										<input type="checkbox" id="Checkbox6"  name="upNum6" value="1"> 6
									  </label>
									  <label class="checkbox inline">
										<input type="checkbox" id="Checkbox7"  name="upNum7"  value="1"> 7
									  </label>
									  <label class="checkbox inline">
										<input type="checkbox" id="Checkbox8"  name="upNum8"  value="1"> 8
									  </label>
									  <label class="checkbox inline">
										<input type="checkbox" id="Checkbox9"  name="upNum9"  value="1"> 9
									  </label>
									  <label class="checkbox inline">
										<input type="checkbox" id="Checkbox10"  name="upNum10"  value="1"> 10
									  </label>
								</div>
							  </div>
						 	<div class="control-group">
								  <label class="control-label" for="textarea2">版本说明</label>
								  <div class="controls">
									<textarea name='drsc' id="textarea2" rows="3"></textarea>
								  </div>
							</div>
						 	<div class="form-actions">
								  <button type="submit" class="btn btn-primary">保存</button>
								  <button type="reset" class="btn">取消</button>
							</div>
						 </fieldset>
					</form>
				</div>
			</div>
			<div class="box span10">
				<div class="box-header well" data-original-title>
					<h2><i class="icon-edit"></i> 测试MAC地址属于部分数</h2>
						<div class="box-icon">
						<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
						<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
						<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
					</div>
				</div>
				<div class="box-content">
					<form class="form-horizontal" method="post" enctype="multipart/form-data" name="myform">
						 <fieldset>
						 	<legend></legend>
							<div class="control-group">
							  <label class="control-label" for="typeahead">MAC地址</label>
							  <div class="controls">
								<input type="text" class="span6 typeahead" name='mac' value='<?php echo $this->_tpl_vars['mac']; ?>
'>
							  </div>
							</div>
							<?php if (isset ( $this->_tpl_vars['part'] )): ?>
							<div class="control-group">
							  <label class="control-label" for="typeahead">MAC所属升级部分</label>
							  <div class="controls">
								<input class="input-xlarge uneditable-input" type="text"  readonly="readonly"  value='<?php echo $this->_tpl_vars['part']; ?>
'>
							  </div>
							</div>
							<?php endif; ?>
						 	<div class="form-actions">
								  <button type="submit" class="btn btn-primary">提交查询</button>
							</div>
						 </fieldset>
					</form>
				</div>
			</div>
			
		</div>
	</div>
	
</body>
</html>