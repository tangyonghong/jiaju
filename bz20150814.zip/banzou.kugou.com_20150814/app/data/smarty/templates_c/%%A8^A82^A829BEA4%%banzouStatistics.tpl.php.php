<?php /* Smarty version 2.6.26, created on 2014-11-03 09:38:39
         compiled from admin/banzouStatistics.tpl.php */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'string_format', 'admin/banzouStatistics.tpl.php', 70, false),)), $this); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/header.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php if ($this->_tpl_vars['excellocation']): ?>
<head><meta http-equiv="refresh" content="0;<?php echo $this->_tpl_vars['excellocation']; ?>
"></head>
<?php endif; ?>
<body>
	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/topbar.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/menus.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
	<script src="http://s1.bdstatic.com/r/www/cache/ecom/esl/1-6-10/esl.js"></script>
	
	<!-- external javascript================================================== -->
	<!-- Placed at the end of the document so the pages load faster -->
	<div id="content" class="span10">
	<form action="/index.php/VerManage/banzouStatistics" method="get" name="mainForm">
		版本号
			<select id="ver" name="ver" data-rel="chosen">
				<?php if ($this->_tpl_vars['datalist']): ?>
        		<?php $_from = $this->_tpl_vars['datalist']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['vo']):
?>
        		<option <?php if ($this->_tpl_vars['vo'] == $this->_tpl_vars['ver']): ?>selected="true"<?php endif; ?>><?php if ($this->_tpl_vars['vo'] == '0.0.0.0'): ?>全部版本<?php else: ?><?php echo $this->_tpl_vars['vo']; ?>
<?php endif; ?></option> 
        		<?php endforeach; endif; unset($_from); ?>
       			<?php endif; ?>
			</select> 
		查询日期：
		<input type="text" class="input-xlarge datepicker" id="start" name="start" value="<?php echo $this->_tpl_vars['start']; ?>
"> 
		至：
		<input type="text" class="input-xlarge datepicker" id="end" name="end" value="<?php echo $this->_tpl_vars['end']; ?>
"> 
		<input type="hidden" name="action" value="query">
		<button type="submit" class="btn btn-primary" onclick="submitFun('query')">查询</button> 
		<button type="submit" class="btn btn-primary" onclick="submitFun('excel')">excel导出</button> 
	</form>
	</div>
	<div id="content" class="span10">
		<table class="table table-striped table-bordered bootstrap-datatable datatable">
			<thead>
				<tr>
					<th>日期</th>
					<th>新用户数</th>
					<th>新安装量</th>
					<th>启动次数</th>
					<th>启动人数</th>
					<th>卸载人数</th>
					<th>卸载次数</th>
					<th>搜索次数</th>
					<th>搜索人数</th>
					<th>播放次数</th>
					<th>播放人数</th>
					<th>崩溃次数</th>
					<th>崩溃率（次）</th>
					<th>崩溃人数</th>
					<th>崩溃率（人数）</th>
					<th>视频启用次数</th>
					<th>视频启用人数</th>
				</tr>
			</thead>
			<tbody>
				<?php if ($this->_tpl_vars['statistic']): ?>
        		<?php $_from = $this->_tpl_vars['statistic']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['vo']):
?>
				<tr>
					<td class="center"><?php echo $this->_tpl_vars['vo']['date']; ?>
</td>
					<td class="center"><?php echo $this->_tpl_vars['vo']['newUser']; ?>
</td>
					<td class="center"><?php echo $this->_tpl_vars['vo']['installNum']; ?>
</td>
					<td class="center"><?php echo $this->_tpl_vars['vo']['startNum']; ?>
</td>
					<td class="center"><?php echo $this->_tpl_vars['vo']['startUser']; ?>
</td>
					<td class="center"><?php echo $this->_tpl_vars['vo']['uninstallUser']; ?>
</td>
					<td class="center"><?php echo $this->_tpl_vars['vo']['uninstallNum']; ?>
</td>
					<td class="center"><?php echo $this->_tpl_vars['vo']['searchNum']; ?>
</td>
					<td class="center"><?php echo $this->_tpl_vars['vo']['searchUser']; ?>
</td>
					<td class="center"><?php echo $this->_tpl_vars['vo']['playNum']; ?>
</td>
					<td class="center"><?php echo $this->_tpl_vars['vo']['playUser']; ?>
</td>
					<td class="center"><?php echo $this->_tpl_vars['vo']['crashNum']; ?>
</td>
					<td class="center"><?php echo ((is_array($_tmp=$this->_tpl_vars['vo']['crashNum']/$this->_tpl_vars['vo']['startNum']*100)) ? $this->_run_mod_handler('string_format', true, $_tmp, '%.1f') : smarty_modifier_string_format($_tmp, '%.1f')); ?>
%</td>
					<td class="center"><?php echo $this->_tpl_vars['vo']['crashUser']; ?>
</td>
					<td class="center"><?php echo ((is_array($_tmp=$this->_tpl_vars['vo']['crashUser']/$this->_tpl_vars['vo']['startUser']*100)) ? $this->_run_mod_handler('string_format', true, $_tmp, '%.1f') : smarty_modifier_string_format($_tmp, '%.1f')); ?>
%</td>
					<td class="center"><?php echo $this->_tpl_vars['vo']['videoStartNum']; ?>
</td>
					<td class="center"><?php echo $this->_tpl_vars['vo']['videoStartUser']; ?>
</td>
				</tr>
				<?php endforeach; endif; unset($_from); ?>
       			<?php endif; ?>
			</tbody>
		</table>            
			<div><h3>截止<?php echo $this->_tpl_vars['end']; ?>
 <?php echo $this->_tpl_vars['ver']; ?>
 累计新用户数：<?php echo $this->_tpl_vars['install'][0]['count']; ?>
 (第一次安装伴奏)</h3></div>            
		<div id="main" style="height:450px"></div>				
	</div>
	
</body>
</html>
<script type="text/javascript">
function submitFun(act)
{
	mainForm.action.value = act;
	mainForm.submit();
}
</script>
<?php if (isset ( $this->_tpl_vars['chartData'] )): ?>
<script type="text/javascript">
        // 路径配置
    require.config({
        paths:{ 
            'echarts' : 'http://echarts.baidu.com/build/echarts',
            'echarts/chart/line' : 'http://echarts.baidu.com/build/echarts'
        }
    });
    
    // 使用
    require(
        [
            'echarts',
            'echarts/chart/line' // 使用柱状图就加载bar模块，按需加载
        ],
        function (ec) {
            // 基于准备好的dom，初始化echarts图表
            var myChart = ec.init(document.getElementById("main")); 
            
            var option =  {
            	    title : {
            	        text: '<?php echo $this->_tpl_vars['chartData']['title']; ?>
',
            	    },
            	    tooltip : {
            	        trigger: 'axis'
            	    },
            	    legend: {
            	    	 selected: {
                	    	 '新安装量' : false,
            	             '新用户数' : false,
            	             '启动次数' : false,
            	             '卸载人数' : false,
            	             '卸载次数' : false,
            	             '搜索次数' : false,
            	             '搜索人数' : false,
            	             '播放次数' : false,
            	             '播放人数' : false,
            	             '崩溃次数' : false,
            	             '搜索人数' : false,
            	             '视频启用次数' : false,
            	             '视频启用人数' : false,
            	         },
            	        data:<?php echo $this->_tpl_vars['chartData']['legend']; ?>

            	    },
            	    toolbox: {
            	        show : true,
            	        orient : 'vertical',
            	        feature : {
            	            mark : {show: true},
            	            dataZoom : {show: true},
            	            dataView : {show: true, readOnly: false},
            	            magicType : {show: true, type: ['line', 'bar']},
            	            restore : {show: true},
            	            saveAsImage : {show: true}
            	        }
            	    },
            	    calculable : true,
            	    xAxis : [
            	        {
            	            type : 'category',
            	            data : <?php echo $this->_tpl_vars['chartData']['category']; ?>

            	        }
            	    ],
            	    yAxis : [
            	        {
            	            type : 'value'
            	        },
            	        {
            	            type : 'value',
            	            axisLabel : { formatter: '{value} %', }
            	        }
            	    ],
            	    series : <?php echo $this->_tpl_vars['chartData']['series']; ?>

            	};
                
    
            // 为echarts对象加载数据 
            myChart.setOption(option); 
        }
    );
</script>
<?php endif; ?>