<?php /* Smarty version 2.6.26, created on 2015-06-02 11:00:39
         compiled from admin/hifiPerform.tpl.php */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/header.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php if ($this->_tpl_vars['excellocation']): ?>
<head><meta http-equiv="refresh" content="0;<?php echo $this->_tpl_vars['excellocation']; ?>
"></head>
<?php endif; ?>
<body>
	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/topbar.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/menus.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
	<!-- external javascript================================================== -->
	<!-- Placed at the end of the document so the pages load faster -->
	<div id="content" class="span10">
	<form action="/index.php/hifiPerform/index" method="get" name="mainForm">
		查询方式：
			<select name="type" data-rel="chosen">
				<option <?php if ('7' == $this->_tpl_vars['type']): ?>selected="true"<?php endif; ?> value="7">房间id</option>
				<option <?php if ('3' == $this->_tpl_vars['type']): ?>selected="true"<?php endif; ?> value="3">mac地址</option>
				<option <?php if ('8' == $this->_tpl_vars['type']): ?>selected="true"<?php endif; ?> value="8">用户id</option>
			</select> 
		查询：
		<input type="text" id="content" name="content" value="<?php echo $this->_tpl_vars['content']; ?>
"> 
		<input type="text" class="input-xlarge datepicker" id="date" name="date" value="<?php echo $this->_tpl_vars['date']; ?>
"> 
		用户性能显示条数：<input type="text" id="number" name="number" value="<?php echo $this->_tpl_vars['number']; ?>
">
		<button type="submit" class="btn btn-primary" onclick="submitFun('query')">查询</button> 
	<div class="row-fluid sortable">		
			<div class="box span12">
				<div class="box-header well" data-original-title>
					<h2><i class="icon-user"></i> 用户信息(只查询了7天内)</h2>
							<div class="box-icon">
								<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
								<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
								<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
							</div>
				</div>
				<div class="box-content">
					<table class="table table-striped table-bordered bootstrap-datatable datatable">
						<thead>
							<tr>
								<th>最近时间</th>
								<th>mac</th>
								<th>房间id</th>
								<th>用户id</th>
								<th>版本</th>
								<th>cpu</th>
								<th>os</th>
								<th>ip</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td class="center"><?php echo $this->_tpl_vars['info'][0]; ?>
</td>
								<td class="center"><?php echo $this->_tpl_vars['info'][1]; ?>
</td>
								<td class="center"><?php echo $this->_tpl_vars['info'][2]; ?>
</td>
								<td class="center"><?php echo $this->_tpl_vars['info'][3]; ?>
</td>
								<td class="center"><?php echo $this->_tpl_vars['info'][4]; ?>
</td>
								<td class="center"><?php echo $this->_tpl_vars['info'][5]; ?>
</td>
								<td class="center"><?php echo $this->_tpl_vars['info'][6]; ?>
</td>
								<td class="center"><?php echo $this->_tpl_vars['info'][7]; ?>
</td>
							</tr>
						</tbody>
					</table>            		
				</div>
			</div>
		</div>
		<div class="row-fluid sortable">		
			<div class="box span12">
				<div class="box-header well" data-original-title>
					<h2><i class="icon-user"></i> 用户性能(仅显示最近10条)</h2>
							<div class="box-icon">
								<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
								<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
								<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
							</div>
				</div>
				<div class="box-content">
					<table class="table table-striped table-bordered bootstrap-datatable datatable">
						<thead>
							<tr>
								<th>时间</th>
								<th>audio</th>
								<th>video</th>
								<th>cpu</th>
								<th>v_rate</th>
							</tr>
						</thead>
						<tbody>
							<?php if ($this->_tpl_vars['performs']): ?>
			        		<?php $_from = $this->_tpl_vars['performs']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['vo']):
?>
							<tr>
								<td class="center"><?php echo $this->_tpl_vars['vo'][0]; ?>
</td>
								<td class="center"><?php echo $this->_tpl_vars['vo'][1]; ?>
</td>
								<td class="center"><?php echo $this->_tpl_vars['vo'][2]; ?>
</td>
								<td class="center"><?php echo $this->_tpl_vars['vo'][3]; ?>
</td>
								<td class="center"><?php echo $this->_tpl_vars['vo'][4]; ?>
</td>
							</tr>
							<?php endforeach; endif; unset($_from); ?>
			       			<?php endif; ?>
						</tbody>
					</table>   
				</div>
			</div>         
		</div>
		<div class="row-fluid sortable">		
			<div class="box span12">
				<div class="box-header well" data-original-title>
					<h2><i class="icon-user"></i> 用户操作</h2>
							<div class="box-icon">
								<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
								<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
								<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
							</div>
				</div>
				<div class="box-content">
					<table class="table table-striped table-bordered bootstrap-datatable datatable">
						<thead>
							<tr>
								<th>时间</th>
								<th>操作</th>
								<th>版本号</th>
								<th>key</th>
								<th>value</th>
							</tr>
						</thead>
						<tbody>
							<?php if ($this->_tpl_vars['func']): ?>
			        		<?php $_from = $this->_tpl_vars['func']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['vo']):
?>
							<tr>
								<td class="center"><?php echo $this->_tpl_vars['vo'][0]; ?>
</td>
								<td class="center"><?php echo $this->_tpl_vars['vo'][1]; ?>
</td>
								<td class="center"><?php echo $this->_tpl_vars['vo'][2]; ?>
</td>
								<td class="center"><?php echo $this->_tpl_vars['vo'][3]; ?>
</td>
								<td class="center"><?php echo $this->_tpl_vars['vo'][4]; ?>
</td>
							</tr>
							<?php endforeach; endif; unset($_from); ?>
			       			<?php endif; ?>
						</tbody>
					</table>   
				</div>
			</div>         
		</div>
	</div>
</body>
<script type="text/javascript">
function submitFun(act)
{
	mainForm.action.value = act;
	mainForm.submit();
}
</script>
</html>