<?php /* Smarty version 2.6.26, created on 2014-06-12 18:12:43
         compiled from admin/clickStat.tpl.php */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/header.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php if ($this->_tpl_vars['excellocation']): ?>
<head><meta http-equiv="refresh" content="0;<?php echo $this->_tpl_vars['excellocation']; ?>
"></head>
<?php endif; ?>
<body>
	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/topbar.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/menus.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
	<!-- external javascript================================================== -->
	<!-- Placed at the end of the document so the pages load faster -->
	<div id="content" class="span10">
	<form action="/index.php/BanzouFunc/clickStat" method="get" name="mainForm">
		功能
			<select id="des" name="des" data-rel="chosen">
				<?php if ($this->_tpl_vars['Id']): ?>
        		<?php $_from = $this->_tpl_vars['Id']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['vo']):
?>
        		<option <?php if ($this->_tpl_vars['vo'] == $this->_tpl_vars['des']): ?>selected="true"<?php endif; ?>><?php echo $this->_tpl_vars['vo']; ?>
</option> 
        		<?php endforeach; endif; unset($_from); ?>
       			<?php endif; ?>
			</select> 
		查询日期：
		<input type="text" class="input-xlarge datepicker" id="start" name="start" value="<?php echo $this->_tpl_vars['start']; ?>
"> 
		至：
		<input type="text" class="input-xlarge datepicker" id="end" name="end" value="<?php echo $this->_tpl_vars['end']; ?>
"> 
		<input type="hidden" name="action" value="query">
		<button type="submit" class="btn btn-primary" onclick="submitFun('query')">查询</button> 
		<button type="submit" class="btn btn-primary" onclick="submitFun('excel')">excel导出</button> 
	</form>
	</div>
	<div id="content" class="span10">
		<table class="table table-striped table-bordered bootstrap-datatable datatable">
			<thead>
				<tr>
					<th>日期</th>
					<th>类型</th>
					<th>次数</th>
					<th>人数</th>
				</tr>
			</thead>
			<tbody>
				<?php if ($this->_tpl_vars['statistic']): ?>
        		<?php $_from = $this->_tpl_vars['statistic']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['vo']):
?>
				<tr>
					<td class="center"><?php echo $this->_tpl_vars['vo']['date']; ?>
</td>
					<td class="center"><?php echo $this->_tpl_vars['vo']['info']; ?>
</td>
					<td class="center"><?php echo $this->_tpl_vars['vo']['num']; ?>
</td>
					<td class="center"><?php echo $this->_tpl_vars['vo']['user']; ?>
</td>
				</tr>
				<?php endforeach; endif; unset($_from); ?>
       			<?php endif; ?>
			</tbody>
		</table>            
					
	</div>
	
</body>
</html>
<script type="text/javascript">
function submitFun(act)
{
	mainForm.action.value = act;
	mainForm.submit();
}
</script>