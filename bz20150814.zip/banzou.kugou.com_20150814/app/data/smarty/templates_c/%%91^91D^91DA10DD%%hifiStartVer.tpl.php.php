<?php /* Smarty version 2.6.26, created on 2015-03-06 17:32:24
         compiled from admin/hifiStartVer.tpl.php */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/header.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<body>
	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/topbar.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/menus.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
	<script src="http://s1.bdstatic.com/r/www/cache/ecom/esl/1-6-10/esl.js"></script>
	
	<!-- external javascript================================================== -->
	<!-- Placed at the end of the document so the pages load faster -->
	<div id="content" class="span10">
		<form action="/index.php/HifiPerform/startver" method="get" name="mainForm">
			查询日期：
			<input type="text" class="input-xlarge datepicker" id="date" name="date" value="<?php echo $this->_tpl_vars['date']; ?>
"> 
			<button type="submit" class="btn btn-primary" onclick="submitFun('query')">查询</button> 
		</form>
		<div id="main" style="height:600px"></div>
		<h3>按版本去重总人数：<?php echo $this->_tpl_vars['num']; ?>
</h1>
		<h3>总体去重总人数：<?php echo $this->_tpl_vars['unicnum']; ?>
</h1>
		备注：图中的都是按照版本去重的人数，如果某个用户该天用了两个版本，则会在两个版本的人数里面都算一次
	</div>
					
	</div>
	
</body>
</html>
<?php if (isset ( $this->_tpl_vars['vers'] )): ?>
<script type="text/javascript">
        // 路径配置
    require.config({
        paths:{ 
            'echarts' : 'http://echarts.baidu.com/build/echarts',
            'echarts/chart/pie' : 'http://echarts.baidu.com/build/echarts'
        }
    });
    
    // 使用
    require(
        [
            'echarts',
            'echarts/chart/pie' // 使用柱状图就加载bar模块，按需加载
        ],
        function (ec) {
            // 基于准备好的dom，初始化echarts图表
            var myChart = ec.init(document.getElementById("main")); 
            
            var option =  {
            	    title : {
            	        text: '<?php echo $this->_tpl_vars['data']['title']; ?>
',
            	        x:'center'
            	    },
            	    tooltip : {
            	        trigger: 'item',
            	        formatter: "{a} <br/>{b} : {c} ({d}%)"
            	    },
            	    legend: {
            	        data:<?php echo $this->_tpl_vars['legend']; ?>
,
            	        orient:'vertical',
            	        x : 'left',
            	    },
            	    toolbox: {
            	        show : true,
            	        feature : {
            	            mark : {show: true},
            	            dataView : {show: true, readOnly: false},
            	            restore : {show: true},
            	            saveAsImage : {show: true}
            	        }
            	    },
            	    calculable : true,
            	    series : [
            	              {
            	                  name:'',
            	                  type:'pie',
            	                  radius : '55%',
            	                  center: ['50%', '60%'],
            	                  data:<?php echo $this->_tpl_vars['vers']; ?>

            	              }
            	          ]
            	};
                
    
            // 为echarts对象加载数据 
            myChart.setOption(option); 
        }
    );
</script>
<?php endif; ?>