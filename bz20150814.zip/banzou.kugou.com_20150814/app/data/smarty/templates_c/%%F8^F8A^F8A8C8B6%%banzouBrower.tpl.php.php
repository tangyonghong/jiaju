<?php /* Smarty version 2.6.26, created on 2014-11-26 14:44:53
         compiled from admin/banzouBrower.tpl.php */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'string_format', 'admin/banzouBrower.tpl.php', 42, false),)), $this); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/header.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php if ($this->_tpl_vars['excellocation']): ?>
<head><meta http-equiv="refresh" content="0;<?php echo $this->_tpl_vars['excellocation']; ?>
"></head>
<?php endif; ?>
<body>
	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/topbar.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/menus.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
	<!-- external javascript================================================== -->
	<!-- Placed at the end of the document so the pages load faster -->
	<div id="content" class="span10">
	<form action="/index.php/VerManage/banzouBrower" method="get" name="mainForm">
		查询日期：
		<input type="text" class="input-xlarge datepicker" id="start" name="start" value="<?php echo $this->_tpl_vars['start']; ?>
"> 
		至：
		<input type="text" class="input-xlarge datepicker" id="end" name="end" value="<?php echo $this->_tpl_vars['end']; ?>
"> 
		<input type="hidden" name="action" value="query">
		<button type="submit" class="btn btn-primary" onclick="submitFun('query')">查询</button> 
		<button type="submit" class="btn btn-primary" onclick="submitFun('excel')">excel导出</button> 
	</form>
	</div>
	<div id="content" class="span10">
		<table class="table table-striped table-bordered bootstrap-datatable datatable">
			<thead>
				<tr>
					<th>日期</th>
					<th>总次数/人数</th>
					<th>MSIE次数/人数/百分比</th>
					<th>Mozilla次数/人数</th>
					<th>WebKit次数/人数</th>
					<th>IE11次数/人数</th>
					<th>其他</th>
				</tr>
			</thead>
			<tbody>
				<?php if ($this->_tpl_vars['statistic']): ?>
        		<?php $_from = $this->_tpl_vars['statistic']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['vo']):
?>
        		<?php $this->assign('sumNum', $this->_tpl_vars['vo']['MSIENum']+$this->_tpl_vars['vo']['MozillaNum']+$this->_tpl_vars['vo']['WebKitNum']+$this->_tpl_vars['vo']['IE11Num']+$this->_tpl_vars['vo']['browerOtherNum']); ?>
        		<?php $this->assign('sumUser', $this->_tpl_vars['vo']['MSIEUser']+$this->_tpl_vars['vo']['MozillaUser']+$this->_tpl_vars['vo']['WebKitUser']+$this->_tpl_vars['vo']['IE11User']+$this->_tpl_vars['vo']['browerOtherUser']); ?>
				<tr>
					<td class="center"><?php echo $this->_tpl_vars['vo']['date']; ?>
</td>
					<td class="center"><?php echo $this->_tpl_vars['sumNum']; ?>
/<?php echo $this->_tpl_vars['sumUser']; ?>
</td>
					<td class="center"><?php echo $this->_tpl_vars['vo']['MSIENum']; ?>
/<?php echo $this->_tpl_vars['vo']['MSIEUser']; ?>
/<?php echo ((is_array($_tmp=$this->_tpl_vars['vo']['MSIEUser']/$this->_tpl_vars['sumUser']*100)) ? $this->_run_mod_handler('string_format', true, $_tmp, '%.1f') : smarty_modifier_string_format($_tmp, '%.1f')); ?>
%</td>
					<td class="center"><?php echo $this->_tpl_vars['vo']['MozillaNum']; ?>
/<?php echo $this->_tpl_vars['vo']['MozillaUser']; ?>
/<?php echo ((is_array($_tmp=$this->_tpl_vars['vo']['MozillaUser']/$this->_tpl_vars['sumUser']*100)) ? $this->_run_mod_handler('string_format', true, $_tmp, '%.1f') : smarty_modifier_string_format($_tmp, '%.1f')); ?>
%</td>
					<td class="center"><?php echo $this->_tpl_vars['vo']['WebKitNum']; ?>
/<?php echo $this->_tpl_vars['vo']['WebKitUser']; ?>
/<?php echo ((is_array($_tmp=$this->_tpl_vars['vo']['WebKitUser']/$this->_tpl_vars['sumUser']*100)) ? $this->_run_mod_handler('string_format', true, $_tmp, '%.1f') : smarty_modifier_string_format($_tmp, '%.1f')); ?>
%</td>
					<td class="center"><?php echo $this->_tpl_vars['vo']['IE11Num']; ?>
/<?php echo $this->_tpl_vars['vo']['IE11User']; ?>
/<?php echo ((is_array($_tmp=$this->_tpl_vars['vo']['IE11User']/$this->_tpl_vars['sumUser']*100)) ? $this->_run_mod_handler('string_format', true, $_tmp, '%.1f') : smarty_modifier_string_format($_tmp, '%.1f')); ?>
%</td>
					<td class="center"><?php echo $this->_tpl_vars['vo']['browerOtherNum']; ?>
/<?php echo $this->_tpl_vars['vo']['browerOtherUser']; ?>
/<?php echo ((is_array($_tmp=$this->_tpl_vars['vo']['browerOtherUser']/$this->_tpl_vars['sumUser']*100)) ? $this->_run_mod_handler('string_format', true, $_tmp, '%.1f') : smarty_modifier_string_format($_tmp, '%.1f')); ?>
%</td>
				</tr>
				<?php endforeach; endif; unset($_from); ?>
       			<?php endif; ?>
			</tbody>
		</table>            
					
	</div>
	
</body>
</html>
<script type="text/javascript">
function submitFun(act)
{
	mainForm.action.value = act;
	mainForm.submit();
}
</script>