<?php /* Smarty version 2.6.26, created on 2015-03-06 17:31:46
         compiled from admin/menus.tpl.php */ ?>
	<div class="container-fluid">
		<div class="row-fluid">
				
			<!-- left menu starts -->
			<div class="span2 main-menu-span">
				<div class="well nav-collapse sidebar-nav">
					<ul class="nav nav-tabs nav-stacked main-menu">
						<li class="nav-header hidden-tablet">繁星伴奏统计</li>
						<li><a class="ajax-link" href="/index.php"><i class="icon-home"></i><span class="hidden-tablet">首页</span></a></li>
						<li><a class="ajax-link" href="/index.php/VerManage/banzouStatistics"><i class="icon-eye-open"></i><span class="hidden-tablet">用户数据</span></a></li>
						<li><a class="ajax-link" href="/index.php/BanzouVer/existVer"><i class="icon-eye-open"></i><span class="hidden-tablet">版本分布</span></a></li>
						<li><a class="ajax-link" href="/index.php/VerManage/banzouBrower"><i class="icon-eye-open"></i><span class="hidden-tablet">主播开播浏览器</span></a></li>
						<li><a class="ajax-link" href="/index.php/VerManage/banzouPlaySoftware"><i class="icon-eye-open"></i><span class="hidden-tablet">主播开播软件</span></a></li>
						<li><a class="ajax-link" href="/index.php/VerManage/banzouSearch"><i class="icon-eye-open"></i><span class="hidden-tablet">搜索统计</span></a></li>
						<li><a class="ajax-link" href="/index.php/BanzouFunc/clickStat"><i class="icon-eye-open"></i><span class="hidden-tablet">功能使用统计</span></a></li>
						<li><a class="ajax-link" href="/index.php/BanzouVedio/vedioPop"><i class="icon-eye-open"></i><span class="hidden-tablet">视频丢帧弹窗统计</span></a></li>
						<li class="nav-header hidden-tablet">繁星伴奏管理</li>
						<li><a class="ajax-link" href="/index.php/VerManage/banzouVers"><i class="icon-eye-open"></i><span class="hidden-tablet">版本管理</span></a></li>
						<li><a class="ajax-link" href="/index.php/VerManage/banzouAdd"><i class="icon-eye-open"></i><span class="hidden-tablet">添加版本</span></a></li>
						<li><a class="ajax-link" href="/index.php/EffectManage/index"><i class="icon-eye-open"></i><span class="hidden-tablet">特效管理</span></a></li>
						<li class="nav-header hidden-tablet">高清插件</li>
						<li><a class="ajax-link" href="/index.php/HifiPerform/index"><i class="icon-eye-open"></i><span class="hidden-tablet">主播性能</span></a></li>
						<li><a class="ajax-link" href="/index.php/HifiPerform/drop"><i class="icon-eye-open"></i><span class="hidden-tablet">卡的主播</span></a></li>
						<li><a class="ajax-link" href="/index.php/HifiPerform/ver"><i class="icon-eye-open"></i><span class="hidden-tablet">版本日志</span></a></li>
						<li><a class="ajax-link" href="/index.php/HifiPerform/startver"><i class="icon-eye-open"></i><span class="hidden-tablet">开播版本分布</span></a></li>
						<li class="nav-header hidden-tablet">繁星客户端管理</li>
						<li><a class="ajax-link" href="/index.php/VerManage/clientStatistics"><i class="icon-eye-open"></i><span class="hidden-tablet">用户数据</span></a></li>
						<li><a class="ajax-link" href="/index.php/VerManage/clientVers"><i class="icon-eye-open"></i><span class="hidden-tablet">版本管理</span></a></li>
						<li><a class="ajax-link" href="/index.php/VerManage/clientAdd"><i class="icon-eye-open"></i><span class="hidden-tablet">添加版本</span></a></li>
					</ul>
					<label id="for-is-ajax" class="hidden-tablet" for="is-ajax"><input id="is-ajax" type="checkbox"> Ajax on menu</label>
				</div><!--/.well -->
			</div><!--/span-->
			<!-- left menu ends -->