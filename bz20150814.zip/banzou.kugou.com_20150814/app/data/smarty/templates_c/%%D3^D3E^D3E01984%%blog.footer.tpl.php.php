<?php /* Smarty version 2.6.26, created on 2012-12-07 04:01:21
         compiled from common/blog.footer.tpl.php */ ?>
	
	</body>
</html>