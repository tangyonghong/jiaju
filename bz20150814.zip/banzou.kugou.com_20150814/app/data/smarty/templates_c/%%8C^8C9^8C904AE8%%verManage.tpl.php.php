<?php /* Smarty version 2.6.26, created on 2015-03-17 10:50:06
         compiled from admin/verManage.tpl.php */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'date_format', 'admin/verManage.tpl.php', 35, false),)), $this); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/header.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<body>
	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/topbar.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/menus.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
	<!-- external javascript================================================== -->
	<!-- Placed at the end of the document so the pages load faster -->
	<div id="content" class="span10">
		<table class="table table-striped table-bordered bootstrap-datatable datatable">
			<thead>
				<tr>
					<th>版本名称</th>
					<th>版本号</th>
					<th>升级类型</th>
					<th>版本说明</th>
					<th>强制升级版本</th>
					<th>版本地址</th>
					<th>发布版本</th>
					<th>灰度升级部分</th>
					<th>添加时间</th>
					<th>操作</th>
				</tr>
			</thead>   
			<tbody>
				<?php if ($this->_tpl_vars['datalist']): ?>
        		<?php $_from = $this->_tpl_vars['datalist']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['vo']):
?>
				<tr>
					<td class="center"><?php echo $this->_tpl_vars['vo']['name']; ?>
</td>
					<td class="center"><?php echo $this->_tpl_vars['vo']['ver']; ?>
</td>
					<td class="center"><?php if ($this->_tpl_vars['vo']['type'] == 1): ?>强制更新<?php endif; ?><?php if ($this->_tpl_vars['vo']['type'] == 0): ?>提示更新<?php endif; ?><?php if ($this->_tpl_vars['vo']['type'] == 2): ?>不提示更新<?php endif; ?></td>
					<td class="center"><?php echo $this->_tpl_vars['vo']['JSdesc']; ?>
</script></td>
					<td class="center"><?php echo $this->_tpl_vars['vo']['mustUpVer']; ?>
</td>
					<td class="center"><?php echo $this->_tpl_vars['vo']['url']; ?>
</td>
					<td class="center"><?php if ($this->_tpl_vars['vo']['status'] == 1): ?>发布<?php else: ?>旧版本<?php endif; ?></td>
					<td class="center"><?php echo $this->_tpl_vars['vo']['upNum']; ?>
</td>
					<td class="center"><?php echo ((is_array($_tmp=$this->_tpl_vars['vo']['addTime'])) ? $this->_run_mod_handler('date_format', true, $_tmp, "%Y-%m-%d %H:%I:%S") : smarty_modifier_date_format($_tmp, "%Y-%m-%d %H:%I:%S")); ?>
</td>	
					<td class="center">
						<a class="btn btn-info btn-setting" href="#" onclick="edit_action('<?php echo $this->_tpl_vars['vo']['name']; ?>
','<?php echo $this->_tpl_vars['vo']['ver']; ?>
','<?php echo $this->_tpl_vars['vo']['type']; ?>
','<?php echo $this->_tpl_vars['vo']['describe']; ?>
','<?php echo $this->_tpl_vars['vo']['mustUpVer']; ?>
','<?php echo $this->_tpl_vars['vo']['url']; ?>
','<?php echo $this->_tpl_vars['vo']['auurl']; ?>
','<?php echo $this->_tpl_vars['vo']['aufilesize']; ?>
','<?php echo $this->_tpl_vars['vo']['tpver']; ?>
','<?php echo $this->_tpl_vars['vo']['tpurl']; ?>
','<?php echo $this->_tpl_vars['vo']['tpfilesize']; ?>
','<?php echo $this->_tpl_vars['vo']['status']; ?>
','<?php echo $this->_tpl_vars['vo']['upNum']; ?>
')" >
									<i class="icon-edit icon-white"></i>
									修改
								</a>
						<a class="btn btn-danger" href="/index.php/VerManage/banzouDelver?ver=<?php echo $this->_tpl_vars['vo']['ver']; ?>
">
							<i class="icon-trash icon-white"></i> 
							删除
						</a>
					</td>			
				</tr>
				<?php endforeach; endif; unset($_from); ?>
       			<?php endif; ?>
			</tbody>
		</table>            
					
	</div>
	<div id="myModal" class="modal hide fade">
	<form id="up_form" class="form-horizontal" method="post" action="/index.php/VerManage/banzouUpdateVer" enctype="multipart/form-data" name="myform">
		<div class="modal-header">
		<button class="close" data-dismiss="modal" type="button">×</button>
		<h3>修改配置</h3>
		</div>
		<div class="modal-body">
		<div class="box-content">
						 <fieldset>
						 	<div class="control-group">
							  <label class="control-label" for="typeahead">版本号</label>
							  <div class="controls">
								<input id="ver" name="ver" class="input-xlarge uneditable-input" type="text"  readonly="readonly" value="" >
							  </div>
							</div>
						 	<div class="control-group">
							  <label class="control-label" for="typeahead">版本名</label>
							  <div class="controls">
								<input type="text" class="span6 typeahead" name='name' id='name' value=''>
							  </div>
							</div>
							<div class="control-group">
							  <label class="control-label" for="typeahead">小于该版本全部强制升级</label>
							  <div class="controls">
								<input type="text" class="span6 typeahead" name='mustUpVer' id='mustUpVer' value=''>
							  </div>
							</div>
							<div class="control-group">
							  <label class="control-label" for="typeahead">版本地址</label>
							  <div class="controls">
								<input type="text" class="span6 typeahead" name='url' id='url' value=''>
							  </div>
							</div>
							<div class="control-group">
							  <label class="control-label" for="typeahead">自动升级的主程序安装包下载地址</label>
							  <div class="controls">
								<input type="text" class="span6 typeahead" name='auurl' id='auurl' value=''>
							  </div>
							</div>
							<div class="control-group">
							  <label class="control-label" for="typeahead">自动升级的主程序安装包文件大小</label>
							  <div class="controls">
								<input type="text" class="span6 typeahead" name='aufilesize'  id='aufilesize' value=''>
							  </div>
							</div>
							<div class="control-group">
							  <label class="control-label" for="typeahead">第三方库安装包版本</label>
							  <div class="controls">
								<input type="text" class="span6 typeahead" name='tpver' id='tpver'  value=''>
							  </div>
							</div>
							<div class="control-group">
							  <label class="control-label" for="typeahead">第三方库安装包下载地址</label>
							  <div class="controls">
								<input type="text" class="span6 typeahead" name='tpurl' id='tpurl' value=''>
							  </div>
							</div>
							<div class="control-group">
							  <label class="control-label" for="typeahead">第三方库安装包文件大小</label>
							  <div class="controls">
								<input type="text" class="span6 typeahead" name='tpfilesize' id='tpfilesize' value=''>
							  </div>
							</div>
							<div class="control-group">
								<label class="control-label">当前发布版本</label>
								<div class="controls">
									<select id="status" name="status" >
        								<option value='0'>不是</option> 
        								<option value='1'>是</option> 
									</select>
								</div>
							 </div>
							<div class="control-group">
								<label class="control-label">升级类型</label>
								<div class="controls">
								  	<select id="type" name="type" >
        								<option value='0'>提示升级</option> 
        								<option value='2'>不提示升级</option> 
									</select>
								</div>
							 </div>
							 <div class="control-group">
								<label class="control-label">灰度升级部分</label>
								<div class="controls">
								  <label class="checkbox inline">
									<input type="checkbox" id="Checkbox1" name="upNum1" value="1"> 1
								  </label>
								  <label class="checkbox inline">
									<input type="checkbox" id="Checkbox2" name="upNum2" value="1"> 2
								  </label>
								  <label class="checkbox inline">
									<input type="checkbox" id="Checkbox3" name="upNum3" value="1"> 3
								  </label>
								  <label class="checkbox inline">
									<input type="checkbox" id="Checkbox4" name="upNum4" value="1"> 4
								  </label>
								  <label class="checkbox inline">
									<input type="checkbox" id="Checkbox5" name="upNum5" value="1"> 5
								  </label>
								</div>
								<div class="controls">
									<label class="checkbox inline">
										<input type="checkbox" id="Checkbox6"  name="upNum6" value="1"> 6
									  </label>
									  <label class="checkbox inline">
										<input type="checkbox" id="Checkbox7"  name="upNum7"  value="1"> 7
									  </label>
									  <label class="checkbox inline">
										<input type="checkbox" id="Checkbox8"  name="upNum8"  value="1"> 8
									  </label>
									  <label class="checkbox inline">
										<input type="checkbox" id="Checkbox9"  name="upNum9"  value="1"> 9
									  </label>
									  <label class="checkbox inline">
										<input type="checkbox" id="Checkbox10"  name="upNum10"  value="1"> 10
									  </label>
								</div>
							  </div>
							  
						 	<div class="control-group">
								  <label class="control-label" for="textarea2">版本说明</label>
								  <div class="controls">
									<textarea name='describe'  id="describe" rows="3"></textarea>
								  </div>
							</div>
						 </fieldset>
				</div>
		</div>
		<div class="modal-footer">
			<a class="btn" data-dismiss="modal" href="#" >取消</a>
			<a class="btn btn-primary" type="submit" onclick="up_form.submit()">保存</a>
		</div>
		</form>
	</div>
</body>
</html>

<script type="text/javascript">
/**
 * 设置弹出窗口的信息
 */
function edit_action(name,ver,type,describe,mustUpVer,url,auurl,aufilesize,tpver,tpurl,tpfilesize,status,upNum)
{
	document.getElementById("name").value = name;
	document.getElementById("ver").value = ver;
	document.getElementById("type").value = type;
	document.getElementById("describe").value = describe.replace(/<br>/g,"\r\n");;
	document.getElementById("mustUpVer").value = mustUpVer;
	document.getElementById("url").value = url;
	document.getElementById("auurl").value = auurl;
	document.getElementById("aufilesize").value = aufilesize;
	document.getElementById("tpver").value = tpver;
	document.getElementById("tpurl").value = tpurl;
	document.getElementById("tpfilesize").value = tpfilesize;
	document.getElementById("status").value = status;

	if(upNum == 'all')
		upNum = '[1,2,3,4,5,6,7,8,9,10]';
	var options = JSON.parse(upNum);
	for(var i = 0 ; i < options.length; i ++)
	{
		var id = options[i];
		document.getElementById("uniform-Checkbox"+id).getElementsByTagName("span")[0].setAttribute("class","checked");
//		document.getElementById("uniform-Checkbox"+id).getElementsByTagName("input")[0].setAttribute("onclick","return true;");
		document.getElementById("uniform-Checkbox"+id).getElementsByTagName("input")[0].setAttribute("disabled","disabled");
		document.getElementById("uniform-Checkbox"+id).getElementsByTagName("input")[0].setAttribute("checked","checked");
		document.getElementById("uniform-Checkbox"+id).setAttribute("class","checker disabled");
	}
	$('#myModal').modal('show');
}
</script>