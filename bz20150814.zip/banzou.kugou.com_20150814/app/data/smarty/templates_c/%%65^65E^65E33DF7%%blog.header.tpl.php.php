<?php /* Smarty version 2.6.26, created on 2012-12-07 04:00:38
         compiled from common/blog.header.tpl.php */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'default', 'common/blog.header.tpl.php', 4, false),)), $this); ?>
<!DOCTYPE HTML>
<html>
	<head>
		<meta http-equiv='content' content='text/html;charset=<?php echo ((is_array($_tmp=@$this->_tpl_vars['pageCharset'])) ? $this->_run_mod_handler('default', true, $_tmp, "utf-8") : smarty_modifier_default($_tmp, "utf-8")); ?>
'></meta>
		<title><?php echo ((is_array($_tmp=@$this->_tpl_vars['pageTitle'])) ? $this->_run_mod_handler('default', true, $_tmp, '博客系统') : smarty_modifier_default($_tmp, '博客系统')); ?>
</title>
		<?php if ($this->_tpl_vars['pageKeywords']): ?>
			<meta name='keywords' content='<?php echo $this->_tpl_vars['pageKeywords']; ?>
' />	
		<?php endif; ?>
		<?php if ($this->_tpl_vars['pageDescription']): ?>
			<meta name='description' content='<?php echo $this->_tpl_vars['pageDescription']; ?>
' />	
		<?php endif; ?>
		
		<?php $_from = $this->_tpl_vars['arrCssFileList']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['css']):
?>

			<link rel=stylesheet href="<?php echo $this->_tpl_vars['css']; ?>
"></link>
		<?php endforeach; endif; unset($_from); ?>
		<?php $_from = $this->_tpl_vars['arrCssList']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['css']):
?>

			<style type="text/css">
				<?php echo $this->_tpl_vars['css']; ?>

			</style>
		<?php endforeach; endif; unset($_from); ?>
		<?php if ($this->_tpl_vars['jqueryUrl']): ?>

			<script type="text/javascript" src="<?php echo $this->_tpl_vars['jqueryUrl']; ?>
"></script>
		<?php endif; ?>
		<?php $_from = $this->_tpl_vars['arrJavascriptFileList']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['Javascript']):
?>

			<script type="text/javascript" src="<?php echo $this->_tpl_vars['Javascript']; ?>
"></script>
		<?php endforeach; endif; unset($_from); ?>
		<?php $_from = $this->_tpl_vars['arrJavascriptList']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['Javascript']):
?>

			<script type="text/javascript" language="javascript">
			<?php echo $this->_tpl_vars['Javascript']; ?>

			</script>
		<?php endforeach; endif; unset($_from); ?>