<?php /* Smarty version 2.6.26, created on 2014-12-16 17:18:40
         compiled from admin/effectIndex.tpl.php */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'date_format', 'admin/effectIndex.tpl.php', 37, false),)), $this); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/header.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<body>
	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/topbar.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/menus.tpl.php", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
	<!-- external javascript================================================== -->
	<!-- Placed at the end of the document so the pages load faster -->
	<div id="content" class="span10">
		<form action="/index.php/EffectManage/index" method="get" name="mainForm">
				类别:
				<select id="kindid" name="kindid" onchange="mainForm.submit()" value="<?php echo $this->_tpl_vars['kindid']; ?>
">
	        		<option value="1" <?php if (1 == $this->_tpl_vars['kindid']): ?>selected="true"<?php endif; ?>>挂件</option> 
	        		<option value="2" <?php if (2 == $this->_tpl_vars['kindid']): ?>selected="true"<?php endif; ?>>光影</option>
				</select>
				<a class="btn btn-info btn-setting" href="#" onclick="edit_action('')" >
							新增特效
				</a>
		</form>
		<table class="table table-striped table-bordered bootstrap-datatable datatable">
			<thead>
				<tr>
					<th>名称</th>
					<th>缩略图</th>
					<th>地址</th>
					<th>是否可用</th>
					<th>修改时间</th>
					<th>操作</th>
				</tr>
			</thead>
			<tbody>
				<?php if ($this->_tpl_vars['effect']): ?>
        		<?php $_from = $this->_tpl_vars['effect']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['vo']):
?>
				<tr>
					<td class="center"><?php echo $this->_tpl_vars['vo']['name']; ?>
</td>
					<td class="center"><img src="<?php echo $this->_tpl_vars['vo']['img']; ?>
 " height="50"/></td>
					<td class="center"><?php echo $this->_tpl_vars['vo']['url']; ?>
</td>
					<td class="center"><?php if ($this->_tpl_vars['vo']['status'] == 1): ?>可用<?php endif; ?><?php if ($this->_tpl_vars['vo']['status'] == 0): ?>不可用<?php endif; ?></td>
					<td class="center"><?php echo ((is_array($_tmp=$this->_tpl_vars['vo']['time'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%Y-%m-%d %H:%M:%S') : smarty_modifier_date_format($_tmp, '%Y-%m-%d %H:%M:%S')); ?>
</td>
					<td class="center">
						<a class="btn btn-info btn-setting" href="#" onclick="edit_action('<?php echo $this->_tpl_vars['vo']['id']; ?>
','<?php echo $this->_tpl_vars['vo']['status']; ?>
')" >
							<i class="icon-edit icon-white"></i>
							修改
						</a>
						<a class="btn btn-danger" href="/index.php/EffectManage/del?effectId=<?php echo $this->_tpl_vars['vo']['id']; ?>
" >
							<i class="icon-trash icon-white"></i> 
							删除
						</a>
					</td>			
				</tr>
				<?php endforeach; endif; unset($_from); ?>
       			<?php endif; ?>
			</tbody>
		</table>            
			
		<div id="myModal" class="modal hide fade">
			<form id="up_form" class="form-horizontal" method="post" action="/index.php/EffectManage/add" enctype="multipart/form-data" name="myform">
				<div class="modal-header">
					<button class="close" data-dismiss="modal" type="button">×</button>
					<h3>特效配置</h3>
				</div>
				<div class="modal-body">
					<div class="box-content">
						 <fieldset>
						 	<input id="effectId" name="effectId" class="input-xlarge uneditable-input" type="hidden"  readonly="readonly" value="">
							<input id="kind" name="kind" class="input-xlarge uneditable-input" type="hidden"  readonly="readonly" value="">
						 	<div class="control-group" id="imgGroup">
							  <label class="control-label" for="typeahead">缩略图</label>
							  <div class="controls">
								<input class="input-file uniform_on" id="img" name="img" type="file" >
							  </div>
							</div>
							<div class="control-group"  id="fileGroup">
							  <label class="control-label" for="typeahead">文件</label>
							  <div class="controls">
								<input class="input-file uniform_on" id="file" name="file" type="file">
							  </div>
							</div>
							<div class="control-group">
							  <label class="control-label" for="typeahead">是否可用</label>
							  <div class="controls">
								<select id="status" name="status">
									<option value="1">可用</option>
									<option value="0">不可用</option>
								</select>
							  </div>
							</div>
						 </fieldset>
					</div>
				</div>
				<div class="modal-footer">
					<a class="btn" data-dismiss="modal" href="#" >取消</a>
					<a class="btn btn-primary" type="submit" onclick="up_form.submit()">保存</a>
				</div>
			</form>
		</div>
	</div>
</body>
</html>
<script type="text/javascript">
/**
 * 设置弹出窗口的信息
 */
function edit_action(id,status)
{
	document.getElementById("kind").value = document.getElementById("kindid").value;
	
	if(id != "")
	{
		document.getElementById("effectId").value = id;
		document.getElementById("status").value = status;
		document.getElementById("imgGroup").innerHTML  = "" ;
		document.getElementById("fileGroup").innerHTML = "" ;
	}else
	{
		document.getElementById("imgGroup").innerHTML  = "<label class=\"control-label\" for=\"typeahead\">缩略图</label><div class=\"controls\"><input class=\"input-file uniform_on\" id=\"img\" name=\"img\" type=\"file\" ></div>" ;
		document.getElementById("fileGroup").innerHTML = "<label class=\"control-label\" for=\"typeahead\">文件</label><div class=\"controls\"><input class=\"input-file uniform_on\" id=\"file\" name=\"file\" type=\"file\"></div>" ;
	}
	$('#myModal').modal('show');
		
}
</script>