243
a:4:{s:8:"template";a:2:{s:83:"/mnt/develop/works/www/mmfei.cn/fw.mmfei.cn/static/themes/default/tpl/index.tpl.php";b:1;s:26:"common/blog.header.tpl.php";b:1;}s:9:"timestamp";i:1354880733;s:7:"expires";i:1354880733;s:13:"cache_serials";a:0:{}}<!--<b>警告</b> [512] Smarty error: unable to read resource: "common/blog.header.tpl.php"<br />
 /mnt/develop/works/www/mmfei.cn/fw.mmfei.cn/app/ext/smarty/Smarty.class.php 行号： 1093, PHP 5.3.6 (Linux)<br />
<br />
-->
这是首页的模板