162
a:4:{s:8:"template";a:1:{s:40:"/static/themes/default/tpl/index.tpl.php";b:1;}s:9:"timestamp";i:1354880146;s:7:"expires";i:1354880146;s:13:"cache_serials";a:0:{}}<b>警告</b> [512] Smarty error: unable to read resource: "/static/themes/default/tpl/index.tpl.php"<br />
 /mnt/develop/works/www/mmfei.cn/fw.mmfei.cn/app/ext/smarty/Smarty.class.php 行号： 1093, PHP 5.3.6 (Linux)<br />
<br />
