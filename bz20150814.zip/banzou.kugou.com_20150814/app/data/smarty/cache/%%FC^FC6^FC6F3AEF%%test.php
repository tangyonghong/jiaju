129
a:4:{s:8:"template";a:1:{s:8:"test.php";b:1;}s:9:"timestamp";i:1348505495;s:7:"expires";i:1348505495;s:13:"cache_serials";a:0:{}}123
<script type='text/javascript'>alert('d');</script>
1
4
6
