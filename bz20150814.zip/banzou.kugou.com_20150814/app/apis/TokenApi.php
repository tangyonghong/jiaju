<?php
class TokenApi extends MmApiBase
{
	/**
	 * createtoken?ip=xx.xx.xx.xx&appId=1&itemId=str1234567&expire=600&digest= ba90fa38bdb9728640dec81a2be2a931
	 * @return string
	 */
	public static function createTokenAction()
	{
		$ip 		= MmHtml::PG('ip');
		$appId 		= MmHtml::PG('appId');
		$itemId 	= MmHtml::PG('itemId');
		$expire 	= MmHtml::PG('expire');
		$digest 	= MmHtml::PG('digest');

		if(!MmValidate::isIp($ip))
			throw new ApiException('argumengs error ! [IP]',900);
		
		if(!MmValidate::isNatural($appId))
			throw new ApiException('argumengs error ! [appId]',900);
		
		if(!MmValidate::isNatural($itemId))
			throw new ApiException('argumengs error ! [itemId]',900);
		
		if(!MmValidate::isNatural($expire))
			throw new ApiException('argumengs error ! [expire]',900);
		
		if(empty($digest))
			throw new ApiException('argumengs error ! [digest]',900);
		
		return TokenModule::createToken($ip, $appId, $itemId, $expire, $digest);
	}
	/**
	 * 
	 */
	public static function checkTokenAction()
	{
		$token 	= MmHtml::PG('token');
		if(empty($token))
			throw new ApiException('argumengs error ! [token]',900);
		
		$allowIpList = include(MM_ROOT."/config/allowIpConfig.php");
		$ip = MmClientInfo::getClientIp();
		if(!in_array($ip , $allowIpList))
			throw new ApiException('Access deny! [ip deny]' , 905);
		
		return TokenModule::checkToken($token);
	}
	/**
	 * 获取ip列表
	 * @return array(
	 * 		127.0.0.1,
	 * 		127.0.0.1,
	 * 		127.0.0.1,
	 * 		...
	 * )
	 */
	public static function getAllowIpListAction()
	{
		return ApiIpAllowsDAL::getIpList();
	}
}