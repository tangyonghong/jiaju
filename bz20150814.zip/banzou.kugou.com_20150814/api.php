<?php
/**
 * 接口
 * 		api=apiClassNameWithoutApiString
 * 		action=functionName
 * 
 * demo:
 * 	?api=default&action=run
 * 	=> DefaultApi::runAction();
 */
define('APP_FILENAME', isset($_SERVER['SCRIPT_NAME']) ? $_SERVER['SCRIPT_NAME'] : (isset($argv[0]) ? $argv[0] : ''));
$dir = dirname(__FILE__);
$appConfig = include $dir.'/config/apiConfig.php';
include $dir.'/core/Mm.php';
Mm::setConfig($appConfig);
Mm::run();