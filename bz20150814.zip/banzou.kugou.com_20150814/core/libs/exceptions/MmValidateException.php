<?php
/**
 * 验证异常类
 * @author mmfei
 */
class MmValidateException extends MmException
{
	
}