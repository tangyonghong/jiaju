<?php
/**
 * 截止至 2011年3月24日， Windows 下还没有可用的 PECL Memcached 扩展
 * 因此该类是设计来专为 Windows 环境下开发和调试用途的
 * 该类不应应用于正式的生产环境中，正式的生产环境应采用基于 Linux/Unix 操作系统的 libmemcached 的 Memcached 扩展
 * 
 * 该类通过 PHP 的网络函数收发 Memcached 文本协议来模拟实现 Linux Memcached 扩展的相关方法
 * 
 * 注：由于 Linux 下 Memcached 的实现复杂度，该类未能完全模拟实现
 * 以下是没有实现的方法：
 * 	fetch()、fetchAll()、getDelayed()、getDelayedByKey()、getResultCode()、getResultMessage()
 * 	setOption() 只支持以下常量的设置：
 * 		Memcached::OPT_COMPRESSION、Memcached::OPT_PREFIX_KEY
 * 基于回调的机制未实现，如：
 * 	get() 的第二个参数、getByKey() 的第三个参数
 * 
 *
 * @category	Kugou.Com
 * @package		\
 * @copyright	广州酷狗科技有限公司版权所有 Copyright (c) 2000-2011 (http://www.kugou.com)
 * @author		Amor<amor.c@qq.com>
 */


class Memcached
{
    /**
     * 开启或关闭压缩功能。
     * 当开启的时候，item 的值超过某个阈值（当前是100 bytes）时，会首先对值进行压缩然后存储，并 在获取该值时进行解压缩然后返回，使得压缩对应用层透明。
     * 类型: boolean, 默认: TRUE。
     * 
     * @var int
     */
    const OPT_COMPRESSION = -1001;
    
    /**
     * 可以用于为key创建“域”。
     * 这个值将会被作为每个 key 的前缀，它不能长于128个字符， 并且将会缩短最大可允许的key的长度。
     * 这个前缀仅仅用于被存储的元素的 key，而不会用于服务器 key。
     * 类型: string 默认值: ""
     *
     * @var string
     */
    const OPT_PREFIX_KEY = -1002;
    
    /**
     * 指定对于非标量值进行序列化的序列化工具。
     * 可用的值有Memcached::SERIALIZER_PHP 和 Memcached::SERIALIZER_IGBINARY。
     * 后者仅在 memcached 配置时开启 --enable-memcached-igbinary 选项并且 igbinary 扩展被加载时才有效。
     *
     * @var int
     */
    const OPT_SERIALIZER = -1003;
    
	const HAVE_IGBINARY = 0;
	const HAVE_JSON = 1;
	const OPT_HASH = 2;
	const HASH_DEFAULT = 0;
	const HASH_MD5 = 1;
	const HASH_CRC = 2;
	const HASH_FNV1_64 = 3;
	const HASH_FNV1A_64 = 4;
	const HASH_FNV1_32 = 5;
	const HASH_FNV1A_32 = 6;
	const HASH_HSIEH = 7;
	const HASH_MURMUR = 8;
	const OPT_DISTRIBUTION = 9;
	const DISTRIBUTION_MODULA = 0;
	const DISTRIBUTION_CONSISTENT = 1;
	const OPT_LIBKETAMA_COMPATIBLE = 16;
	const OPT_BUFFER_WRITES = 10;
	const OPT_BINARY_PROTOCOL = 18;
	const OPT_NO_BLOCK = 0;
	const OPT_TCP_NODELAY = 1;
	const OPT_SOCKET_SEND_SIZE = 4;
	const OPT_SOCKET_RECV_SIZE = 5;
	const OPT_CONNECT_TIMEOUT = 14;
	const OPT_RETRY_TIMEOUT = 15;
	const OPT_SEND_TIMEOUT = 19;
	const OPT_RECV_TIMEOUT = 20;
	const OPT_POLL_TIMEOUT = 8;
	const OPT_CACHE_LOOKUPS = 6;
	const OPT_SERVER_FAILURE_LIMIT = 21;
	const RES_SUCCESS = 0;
	const RES_FAILURE = 1;
	const RES_HOST_LOOKUP_FAILURE = 2;
	const RES_UNKNOWN_READ_FAILURE = 7;
	const RES_PROTOCOL_ERROR = 8;
	const RES_CLIENT_ERROR = 9;
	const RES_SERVER_ERROR = 10;
	const RES_WRITE_FAILURE = 5;
	const RES_DATA_EXISTS = 12;
	const RES_NOTSTORED = 14;
	
	/**
	 * 元素未找到
	 *
	 * @var int
	 */
	const RES_NOTFOUND = 16;
	
	const RES_PARTIAL_READ = 18;
	const RES_SOME_ERRORS = 19;
	const RES_NO_SERVERS = 20;
	const RES_END = 21;
	const RES_ERRNO = 26;
	const RES_BUFFERED = 32;
	const RES_TIMEOUT = 31;
	const RES_BAD_KEY_PROVIDED = 33;
	const RES_CONNECTION_SOCKET_CREATE_FAILURE = 11;
	const RES_PAYLOAD_FAILURE = -1001;
	
    /**
     * 默认的PHP序列化工具（即serialize方法）。
     * 
     * @var int
     */
    const SERIALIZER_PHP = 1;
    
	const SERIALIZER_IGBINARY = 2;
	
    /**
     * JSON序列化，需要 PHP 5.2.10以上。
     * 
     * @var int
     */
    const SERIALIZER_JSON = 3;
    
    /**
     * JSON数组序列化方式,需要 PHP 5.2.10以上。
     * 
     * @var int
     */
    const SERIALIZER_JSON_ARRAY = 4;
    
	const GET_PRESERVE_ORDER = 1;
    
    
    
    
    
    /**
     * Memcached 选项设置
     * E
     * @var array
     */
    private $options = array(
        self::OPT_PREFIX_KEY=>'',
        self::OPT_COMPRESSION=>true,
        self::OPT_SERIALIZER=>self::SERIALIZER_PHP,
    );
    
    /**
     * 存储各个服务器资源连接的数组
     * 
     * @var array
     */
    private $handles = array();
    
    private $serverList = array();
    private $serverListKeyCaching = array();
    
    /**
     * 存储 Memcached 最后一次操作的结果代码
     * 
     * @var int
     */
    private $resultCode = 0;
    
    /**
     * 存储 Memcached 最后一次操作的结果描述消息
     * 
     * @var string
     */
    private $resultMessage = '';
    
    /**
     * 一致性哈希映射表
     * 
     * @var array
     */
    private $consistentHash = array();
    
    public function __construct($persistentId = null)
    {
//        if (isset($persistentId))
//        {
//            throw new InvalidArgumentException('请要不指定参数初始化 Memcached 的实例 —— 这是一个调试用途的类。');
//        }
        if ('\\' !== DIRECTORY_SEPARATOR)
        {
            throw new RuntimeException('自定义的 Memcached 只可以运行在 Windows 环境下，并且只能用于开发和调试用途。');
        }
    }// end constructor
    
    /**
     * 获取无符号的 Hash 校验码
     * 该方法的返回值是无符号数，从 0 到 4294967296
     *
     * @param string $str
     * @return int
     */
//    protected function getHashCode($str)
//    {
//        return vsprintf('%u', crc32($str));
//    }// end method getHashCode
    
    /**
     * 按照一致性哈希算法的规则，计算指定的 $str 落在 $this->serverList 的哪个索引上
     *
     * @param string $str
     * @return int 返回 $this->serverList 的索引编号
     */
    private function getServerIndexByString($str)
    {
        if (empty($this->serverList)) return array();
        
        if ('' === $str) return 0;
        
        $hashRingNumber = count($this->serverList);    // 环形的数量
        if (1 === $hashRingNumber) return 0;
        
        $scopeNumber = vsprintf('%u', 4294967296 / $hashRingNumber);    // 按 0 ~ 2^32 分成N份，每份的值范围
        
        $computedHashCode = vsprintf('%u', crc32($str));              // 计算 key 的哈希值
        
        $position = ceil($computedHashCode / $scopeNumber);            // 计算 key 的哈希值落在哪个区间内
        
        return ($position - 1);
    }// end method getServerIndexByString
    
    private function getAndOpenSocket($host, $port)
    {
        return fsockopen($host, $port);
    }// end method getAndOpenSocket
    
    private function getConnection($serverKey = '', $key = '', &$argIndex = null)
    {
        if (empty($this->serverList))
        {
            throw new RuntimeException('No servers added to memcache connection');
        }
        
        $tmpKey = $serverKey . $key;
        if (isset($this->consistentHash[$tmpKey]))
        {
            $index = $this->consistentHash[$tmpKey];
        }
        else
        {
            $this->consistentHash[$tmpKey] = $index = $this->getServerIndexByString($tmpKey);
        }
        
        if (func_num_args() > 2) $argIndex = $index;
        
        if (isset($this->handles[$index])) return $this->handles[$index];
        else
        {
            $opts = $this->serverList[$index];
            $this->handles[$index] = $handle = $this->getAndOpenSocket($opts['host'], $opts['port']);
            return $handle;
        }
    }// end method getConnection
    
    protected function sendCommand_StorageData($cmdName, $key, $data, $exptime = 0, $serverKey = '')
    {
        $this->resultCode = 0;
        $this->resultMessage = '';
        
        $rawData = $data;
        if (true === $this->options[self::OPT_COMPRESSION])
        {// 启用压缩处理
            if (is_scalar($data))
            {
                $bytes = strlen($data);
                if ($bytes > 100)
                {// 当数据长度大于100字节时，会首先对值进行压缩然后存储，并在获取该值时进行解压缩然后返回，使得压缩对应用层透明。
                    $data = gzcompress($data);
                    $bytes = strlen($data);
                    $flag = 16;    // 有压缩，无序列化
                }
                else $flag = 0;    // 无压缩，无序列化
            }
            else
            {
                if (self::SERIALIZER_PHP == $this->options[self::OPT_SERIALIZER])
                {
                    $data = serialize($data);
                    $bytes = strlen($data);
                    if ($bytes > 100)
                    {// 当数据长度大于100字节时，会首先对值进行压缩然后存储，并 在获取该值时进行解压缩然后返回，使得压缩对应用层透明。
                        $data = gzcompress($data);
                        $bytes = strlen($data);
                        $flag = 20;    // serialize 序列化并且压缩
                    }
                    else $flag = 4;    // 无压缩，有 serialize 序列化
                }
                else
                {
                    $data = json_encode($data);
                    $bytes = strlen($data);
                    if ($bytes > 100)
                    {// 当数据长度大于100字节时，会首先对值进行压缩然后存储，并 在获取该值时进行解压缩然后返回，使得压缩对应用层透明。
                        $data = gzcompress($data);
                        $bytes = strlen($data);
                        $flag = 22;    // json 序列化并且压缩
                    }
                    else $flag = 6;    // 无压缩，有 json 序列化
                }
            }
        }
        else
        {
            if (is_scalar($data))
            {
                $flag = 0;    // 无压缩，无序列化
                $bytes = strlen($data);
            }
            else
            {
                if (self::SERIALIZER_PHP == $this->options[self::OPT_SERIALIZER])
                {
                    $data = serialize($data);
                    $flag = 4;    // 无压缩，有 serialize 序列化
                }
                else
                {
                    $data = json_encode($data);
                    $flag = 6;    // 无压缩，有 json 序列化
                }
                $bytes = strlen($data);
            }
        }
        
        $key = $this->getRealKey($key);
        $handle = $this->getConnection($serverKey, $key);
        
        $command = "{$cmdName} {$key} {$flag} {$exptime} {$bytes}\r\n";
        $result = fwrite($handle, $command);
        if (false === $result) return false;
        
        if (false === fwrite($handle, $data . "\r\n")) return false;
        
        $result = rtrim(fgets($handle));
        if ('STORED' === rtrim($result)) return true;
        else return false;
    }// end method sendCommand_StorageData
    
    protected function sendCommand_Cas($casToken, $key, $data, $exptime = 0, $serverKey = '')
    {
        $this->resultCode = 0;
        $this->resultMessage = '';
        
        if (is_scalar($data))
        {
            $flag = 0;
        }
        else
        {
            $flag = 4;
            $data = serialize($data);
        }
        $bytes = strlen($data);
        
        $key = $this->getRealKey($key);
        $handle = $this->getConnection($serverKey, $key);
        
        $command = "cas {$key} {$flag} {$exptime} {$bytes} {$casToken}\r\n";
        $result = fwrite($handle, $command);
        if (false === $result) return false;
        
        if (false === fwrite($handle, "{$data}\r\n")) return false;
        
        $result = rtrim(fgets($handle));
        if ('STORED' === rtrim($result)) return true;
        else return false;
    }// end method sendCommand_Cas
    
    protected function sendCommand_get(array $keys, $serverKey = '', &$arrCasToken = null)
    {
        $this->resultCode = 0;
        $this->resultMessage = '';
        
        $retvl = array();
        $tmpArray = array();
        $tmpArray2 = array();
        $handleIndex = null;
        $realKeys = array();
        foreach ($keys as $key)
        {
//            $retvl[$key] = null;
            
            $realKey = $this->getRealKey($key);
            $handle = $this->getConnection($serverKey, $realKey, $handleIndex);
            $tmpArray[$handleIndex][] = $key;
            
            $tmpArray2[$realKey] = $key;
            $realKeys[$realKey] = $realKey;
        }
        if (func_num_args() > 2)
        {
            $arrCasToken = array();
            foreach ($tmpArray as $handleIndex => $keys)
            {
                $handle = $this->handles[$handleIndex];
                $command = "gets " . implode(' ', $realKeys) . "\r\n";
                if (false === fwrite($handle, $command))
                {
                    return false;
                }
                
                $dataLength = 0;
                $isFound = false; 
                $i = -1;
                do
                {
                    if ($dataLength <= 0)
                    {
                        $lineData = rtrim(fgets($handle));
                        if ('' === $lineData)
                        {
                            fgets($handle);    // 拿到 END
                            break;
                        }
                        if ('END' === $lineData)
                        {
                            if (false === $isFound)
                            {
                                $this->resultCode = self::RES_NOTFOUND;
                                $this->resultMessage = 'NOT FOUND';
                            }
                            break;
                        }
                        
                        if ('ERROR' === $lineData) return false;
                        if ('NOT_FOUND' === $lineData)
                        {
                            $this->resultCode = self::RES_NOTFOUND;
                            $this->resultMessage = 'NOT FOUND';
                            break;
                        }
                        if ('DELETED' === $lineData) break;
                        
                        $arrTmp = explode(' ', $lineData);
                        list(, $currRealKey, $currFlag, $dataLength, $currCasToken) = $arrTmp;                      
                        continue;
                    }
                    
                    $arrCasToken[$tmpArray2[$currRealKey]] = $currCasToken;
                    
                    $lineData = fgets($handle,$dataLength+1);
                    $dataLength = 0;
                    
                    if (3 == $currFlag)
                    {
                        $retvl[$tmpArray2[$currRealKey]] = $lineData ? true : false;
                    }
                    elseif (4 == $currFlag)
                    {// 无压缩，有 serialize 序列化
                        $retvl[$tmpArray2[$currRealKey]] = unserialize($lineData);
                    }
                    elseif (6 == $currFlag)
                    {// 无压缩，有 json 序列化
                        $retvl[$tmpArray2[$currRealKey]] = json_decode($lineData, true);
                    }
                    elseif (16 == $currFlag)
                    {// 有压缩，无序列化
                        $retvl[$tmpArray2[$currRealKey]] = gzuncompress($lineData);
                    }
                    elseif (20 == $currFlag)
                    {// serialize 序列化并且压缩
                        $retvl[$tmpArray2[$currRealKey]] = unserialize(gzuncompress($lineData));
                    }
                    elseif (22 == $currFlag)
                    {// json 序列化并且压缩
                        $retvl[$tmpArray2[$currRealKey]] = json_decode(gzuncompress($lineData), true);
                    }
                    elseif (in_array($currFlag, array(0, 1, 2)))
                    {// 无压缩无序列化
                        $retvl[$tmpArray2[$currRealKey]] = $lineData;
                    }
                    else
                    {
                        throw new RuntimeException('不支持的标志flag:' . $currFlag);
                    }

                    $isFound = true;
                } while (true);
            }
            
            return $retvl;
        }
        else
        {
            foreach ($tmpArray as $handleIndex => $keys)
            {
                $handle = $this->handles[$handleIndex];
                $command = "get " . implode(' ', $realKeys) . "\r\n";
                if (false === fwrite($handle, $command)) return false;
                $dataLength = 0;
                $isFound = false; 
                do
                {
                    if ($dataLength <= 0)
                    {
                        $lineData = rtrim(fgets($handle));
                        if ('' === $lineData)
                        {
                            fgets($handle);    // 拿到 END
                            break;
                        }
                        if ('END' === $lineData)
                        {
                            if (false === $isFound)
                            {
                                $this->resultCode = self::RES_NOTFOUND;
                                $this->resultMessage = 'NOT FOUND';
                            }
                            break;
                        }
                        
                        if ('ERROR' === $lineData) return false;
                        if ('NOT_FOUND' === $lineData)
                        {
                            $this->resultCode = self::RES_NOTFOUND;
                            $this->resultMessage = 'NOT FOUND';
                            break;
                        }
                        if ('DELETED' === $lineData) break;
                        
                        $arrTmp = explode(' ', $lineData);
                        list(, $currRealKey, $currFlag) = $arrTmp;
                        if (count($arrTmp) > 3) $dataLength = $arrTmp[3];
                        
                        continue;
                    }
                    $lineData = fgets($handle,$dataLength+1);
                    $dataLength = 0;
                    
                    
                    if (3 == $currFlag)
                    {
                        $retvl[$tmpArray2[$currRealKey]] = $lineData ? true : false;
                    }
                    elseif (4 == $currFlag)
                    {// 无压缩，有 serialize 序列化
                        $retvl[$tmpArray2[$currRealKey]] = unserialize($lineData);
                    }
                    elseif (6 == $currFlag)
                    {// 无压缩，有 json 序列化
                        $retvl[$tmpArray2[$currRealKey]] = json_decode($lineData, true);
                    }
                    elseif (16 == $currFlag)
                    {// 有压缩，无序列化
                        $retvl[$tmpArray2[$currRealKey]] = gzuncompress($lineData);
                    }
                    elseif (20 == $currFlag)
                    {// serialize 序列化并且压缩
                        $retvl[$tmpArray2[$currRealKey]] = unserialize(gzuncompress($lineData));
                    }
                    elseif (22 == $currFlag)
                    {// json 序列化并且压缩
                        $retvl[$tmpArray2[$currRealKey]] = json_decode(gzuncompress($lineData), true);
                    }
                    elseif (in_array($currFlag, array(0, 1, 2)))
                    {// 无压缩无序列化
                        $retvl[$tmpArray2[$currRealKey]] = $lineData;
                    }
                    else throw new RuntimeException('不支持的标志flag:' . $currFlag);
                    
                    fgets($handle);    // 拿到 END

                    $isFound = true;
                } while (true);
            }
            
            return $retvl;
        }
    }// end method sendCommand_get
    
    /**
     * 获取包含前缀的 key
     *
     * @param string $key
     * @return string
     */
    protected function getRealKey($key)
    {
        if (isset($this->options[self::OPT_PREFIX_KEY]))
        {
            return $this->options[self::OPT_PREFIX_KEY] . $key;
        }
        else
        {
            return $key;
        }
    }// end method getRealKey

    /**
     * 向一个新的key下面增加一个元素
     *
     * @param string $key		用于存储值的键名。
     * @param mixed $value		存储的值。
     * @param int $expiration	到期时间，默认为 0。
     * @return bool				成功时返回 TRUE， 或者在失败时返回 FALSE。如果key已经存在， Memcached::getResultCode方法将会返回Memcached::RES_NOTSTORED。
     */
    public function add($key, $value, $expiration = 0)
    {
        return $this->sendCommand_StorageData('add', $key, $value, $expiration);
    }// end method add
    
    /**
     * 在指定服务器上的一个新的key下增加一个元素
     *
     * @param string $serverKey
     * @param string $key
     * @param mixed $value
     * @param int $expiration
     * @return bool
     */
    public function addByKey($serverKey, $key, $value, $expiration = 0)
    {
        return $this->sendCommand_StorageData('add', $key, $value, $expiration, $serverKey);
    }// end method addByKey
    
    /**
     * 向服务器池中增加一个服务器
     *
     * @param string $host
     * @param int $port
     * @param int $weight
     * @return bool
     */
    public function addServer($host, $port, $weight = 0)
    {
        $key = $host . $port;
        if (isset($this->serverListKeyCaching[$key]))
        {
            $this->serverList[$this->serverListKeyCaching[$key]] = array(
                'host'=>$host,
                'port'=>$port,
                'weight'=>$weight,
            );
        }
        else
        {
            $this->serverList[] = array(
                'host'=>$host,
                'port'=>$port,
                'weight'=>$weight,
            );
            $this->serverListKeyCaching[$key] = count($this->serverList) - 1;
        }
        
        // 对服务器列表数组进行排序，以便于稍后的一致性哈希简单算法的实现
        if (count($this->serverList) > 1) ksort($this->serverList);
        
        return true;
    }// end method addServer
    
    /**
     * 向服务器池中增加多台服务器
     *
     * @param array $servers
     * @return bool
     */
    public function addServers(array $servers)
    {
        if (empty($servers)) return false;
        
        foreach ($servers as $index => $server)
        {
            if (!is_array($server))
            {
                throw new InvalidArgumentException('Argument $servers[' . $index . '] must be an array.');
            }
            $host = $server[0];
            $port = $server[1];
            $key = $host . $port;
            if (isset($this->serverListKeyCaching[$key]))
            {
                $this->serverList[$this->serverListKeyCaching[$key]] = array(
                    'host'=>$host,
                    'port'=>$port,
                    'weight'=>isset($server[2]) ? $server[2] : 0,
                );
            }
            else
            {
                $this->serverList[] = array(
                    'host'=>$host,
                    'port'=>$port,
                    'weight'=>isset($server[2]) ? $server[2] : 0,
                );
                $this->serverListKeyCaching[$key] = count($this->serverList) - 1;
            }
        }
        
        // 对服务器列表数组进行排序，以便于稍后的一致性哈希简单算法的实现
        if (count($this->serverList) > 1) ksort($this->serverList);
        
        return true;
    }// end method addServers
    
    /**
     * 向已存在元素后追加数据
     *
     * @param string $key
     * @param string $value
     * @return bool
     */
    public function append($key, $value)
    {
        return $this->sendCommand_StorageData('append', $key, $value);
    }// end method append
    
    /**
     * 向指定服务器上已存在元素后追加数据
     *
     * @param string $serverKey
     * @param string $key
     * @param string $value
     * @return bool
     */
    public function appendByKey($serverKey, $key, $value)
    {
        return $this->sendCommand_StorageData('append', $key, $value, 0, $serverKey);
    }// end method appendByKey
    
    /**
     * 比较并交换值
     *
     * @param float $casToken
     * @param string $key
     * @param mixed $value
     * @param int $expiration
     * @return bool
     */
    public function cas($casToken, $key, $value, $expiration = 0)
    {
        return $this->sendCommand_Cas($casToken, $key, $value, $expiration);
    }// end method cas
    
    /**
     * 在指定服务器上比较并交换值
     *
     * @param float $casToken
     * @param string $serverKey
     * @param string $key
     * @param mixed $value
     * @param int $expiration
     * @return bool
     */
    public function casByKey($casToken, $serverKey, $key, $value, $expiration = 0)
    {
        return $this->sendCommand_Cas($casToken, $key, $value, $expiration, $serverKey);
    }// end method casByKey
    
    /**
     * 减小数值元素的值
     *
     * @param string $key
     * @param int $offset
     * @return int			成功时返回元素新的值， 或者在失败时返回 FALSE。 如果key不存在， Memcached::getResultCode返回Memcached::RES_NOTFOUND。
     */
    public function decrement($key, $offset = 1)
    {
        $this->resultCode = 0;
        $this->resultMessage = '';
        
        $key = $this->getRealKey($key);
        $handle = $this->getConnection('', $key);
        if (false === fwrite($handle, "decr {$key} {$offset}\r\n")) return false;
        
        $newValue = rtrim(fgets($handle));
        if ('NOT_FOUND' === $newValue)
        {
            $this->resultCode = self::RES_NOTFOUND;
            $this->resultMessage = 'NOT FOUND';
            return false;
        }
        else return (int)$newValue;
    }// end method decrement
    
    /**
     * 删除一个元素
     *
     * @param string $key
     * @param int $time
     * @return bool
     */
    public function delete($key, $time = 0)
    {
        $this->resultCode = 0;
        $this->resultMessage = '';
        
        $handle = $this->getConnection('', $key);
        
        $key = $this->getRealKey($key);
        if (false === fwrite($handle, "delete {$key}\r\n")) return false;
        
        if ('DELETED' === rtrim(fgets($handle))) return true;
        else return false;
    }// end method delete

    /**
     * 删除批量元素
     * @param array $keys
     * @param int $time
     */
    public function deleteMulti(array $keys,$time=0)
    {
        foreach ($keys as $key) {
            $a = $this->delete($key,$time);
        }
        return $a;        
    }
    
    /**
     * 从指定的服务器删除一个元素
     *
     * @param string $serverKey
     * @param string $key
     * @param int $time
     * @return bool
     */
    public function deleteByKey($serverKey, $key, $time = 0)
    {
        $this->resultCode = 0;
        $this->resultMessage = '';
        
        $handle = $this->getConnection($serverKey, $key);
        
        $key = $this->getRealKey($key);
        if (false === fwrite($handle, "delete {$key}\r\n")) return false;
        
        if ('DELETED' === rtrim(fgets($handle))) return true;
        else return false;
    }// end method deleteByKey
    
    /**
     * 抓取下一个结果
     *
     * @return array
     */
    public function fetch()
    {
        $this->resultCode = 0;
        $this->resultMessage = '';
        
        throw new RuntimeException('方法“' . __METHOD__ . '”未实现');
    }// end method fetch
    
    /**
     * 抓取所有剩余的结果
     *
     * @return array
     */
    public function fetchAll()
    {
        $this->resultCode = 0;
        $this->resultMessage = '';
        
        throw new RuntimeException('方法“' . __METHOD__ . '”未实现');
    }// end method fetchAll
    
    /**
     * 作废缓存中的所有元素
     *
     * @param int $delay
     * @return bool
     */
    public function flush($delay = 0)
    {
        $this->resultCode = 0;
        $this->resultMessage = '';
        
        if (empty($this->serverList)) return false;
        
        foreach ($this->serverList as $index => $val)
        {
            if (isset($this->handles[$index])) $handle = $this->handles[$index];
            else
            {
                $this->handles[$index] = $handle = $this->getAndOpenSocket($val['host'], $val['port']);
            }
            fwrite($handle, "flush_all\r\n");
        }
        
        return true;
    }// end method flush
    
    /**
     * 检索一个元素
     *
     * @param string $key
     * @param callback $cacheDb
     * @param float $casToken
     * @return mixed
     */
    public function get($key, $cacheDb = null, &$casToken = null)
    {
        if (func_num_args() > 2)
        {
            $arrCasToken = array();
            $retvl = $this->sendCommand_get(array($key), '', $arrCasToken);
            if (false === $retvl) return false;
            $casToken = current($arrCasToken);
            $retvl = current($retvl);
            if (null === $retvl) return false;
            else return $retvl;
        }
        else
        {
            $retvl = $this->sendCommand_get(array($key));
            if (false === $retvl) return false;
            $retvl = current($retvl);
            if (null === $retvl) return false;
            else return $retvl;
        }
    }// end method get
    
    /**
     * 从特定的服务器检索元素
     *
     * @param string $serverKey
     * @param string $key
     * @param callback $cacheDb
     * @param float $casToken
     * @return mixed
     */
    public function getByKey($serverKey, $key, $cacheDb = null, &$casToken = 0)
    {
        if (func_num_args() > 2)
        {
            $arrCasToken = array();
            $retvl = $this->sendCommand_get(array($key), $serverKey, $arrCasToken);
            if (false === $retvl) return false;
            $casToken = current($arrCasToken);
            $retvl = current($retvl);
            if (null === $retvl) return false;
            else return $retvl;
        }
        else
        {
            $retvl = $this->sendCommand_get(array($key), $serverKey);
            if (false === $retvl) return false;
            $retvl = current($retvl);
            if (null === $retvl) return false;
            else return $retvl;
        }
    }// end method getByKey
    
    /**
     * 请求多个元素
     *
     * @param array $keys
     * @param bool $withCas
     * @param callback $valueCb
     * @return bool
     */
    public function getDelayed(array $keys, $withCas = false, $valueCb = null)
    {
        $this->resultCode = 0;
        $this->resultMessage = '';
        
        throw new RuntimeException('方法“' . __METHOD__ . '”未实现');
    }// end method getDelayed
    
    /**
     * 从指定的服务器上请求多个元素
     *
     * @param string $serverKey
     * @param array $keys
     * @param bool $withCas
     * @param callback $valueCb
     * @return bool
     */
    public function getDelayedByKey($serverKey, array $keys, $withCas = false, $valueCb = null)
    {
        $this->resultCode = 0;
        $this->resultMessage = '';
        
        throw new RuntimeException('方法“' . __METHOD__ . '”未实现');
    }// end method getDelayedByKey
    
    /**
     * 检索多个元素
     *
     * @param array $keys
     * @param array $casToken
     * @param int $flags
     * @return array|false
     */
    public function getMulti(array $keys, &$arrCasToken = null, $flags = null)
    {
        if (func_num_args() > 2)
        {
            return $this->sendCommand_get($keys, '', $arrCasToken);
        }
        else
        {
            return $this->sendCommand_get($keys);
        }
    }// end method getMulti
    
    /**
     * 从特定服务器检索多个元素
     *
     * @param string $serverKey
     * @param array $keys
     * @param array $arrCasToken
     * @param int $flags
     * @return array|false
     */
    public function getMultiByKey($serverKey, array $keys, &$arrCasToken = null, $flags = null)
    {
        if (func_num_args() > 2)
        {
            return $this->sendCommand_get($keys, $serverKey, $arrCasToken);
        }
        else
        {
            return $this->sendCommand_get($keys, $serverKey);
        }
    }// end method getMultiByKey

    /**
     * 获取Memcached的选项值
     *
     * @param int $option
     * @return mixed
     */
    public function getOption($option)
    {
        if (isset($this->options[$option])) return $this->options[$option];
        else return false;
    }// end method getOption
    
    /**
     * 返回最后一次操作的结果代码
     *
     * @return int
     */
    public function getResultCode()
    {
        return $this->resultCode;
    }// end method getResultCode
    
    /**
     * 返回最后一次操作的结果描述消息
     *
     * @return string
     */
    public function getResultMessage()
    {
        return $this->resultMessage;
    }// end method getResultMessage
    
    /**
     * Map a key to a server
     *
     * @param string $serverKey
     * @return array
     */
    public function getServerByKey($serverKey)
    {
        throw new RuntimeException('方法“' . __METHOD__ . '”未实现');
    }// end method getServerByKey
    
    /**
     * Get the list of the servers in the pool
     * 
     * @return array
     */
    public function getServerList()
    {
        return array_values($this->serverList);
    }// end method getServerList
    
    /**
     * 获取服务器统计信息
     *
     * @return array
     */
    public function getStats()
    {// 未完全实现
        $this->resultCode = 0;
        $this->resultMessage = '';
        
        if (empty($this->serverList)) return array();
        
        $retvl = array();
        foreach ($this->serverList as $index => $val)
        {
            if (isset($this->handles[$index])) $handle = $this->handles[$index];
            else
            {
                $this->handles[$index] = $handle = $this->getAndOpenSocket($val['host'], $val['port']);
            }
            
            $tmpKey = $val['host'] . ':' . $val['port'];
            if (false === fwrite($handle, "stats\r\n"))
            {
                $retvl[$tmpKey] = array();
                continue;
            }
            
            while ('END' !== ($tmpResult = rtrim(fgets($handle))))
            {
                list(, $key, $val) = explode(' ', $tmpResult);
                $retvl[$tmpKey][$key] = $val;
            }
        }
        return $retvl;
    }// end method getStats
    
    /**
     * 返回服务器版本信息
     *
     * @return array
     */
    public function getVersion()
    {
        $this->resultCode = 0;
        $this->resultMessage = '';
        
        if (empty($this->serverList)) return array();
        
        $retvl = array();
        foreach ($this->serverList as $index => $val)
        {
            if (isset($this->handles[$index])) $handle = $this->handles[$index];
            else
            {
                $this->handles[$index] = $handle = $this->getAndOpenSocket($val['host'], $val['port']);
            }
            
            $tmpKey = $val['host'] . ':' . $val['port'];
            if (false === fwrite($handle, "version\r\n"))
            {
                $retvl[$tmpKey] = array();
                continue;
            }
            
            list(, $version) = explode(' ', rtrim(fgets($handle)));
            $retvl[$tmpKey][$tmpKey] = $version;
        }
        return $retvl;
    }// end method getVersion
    
    /**
     * 增加一个元素的值
     *
     * @param string $key
     * @param int $offset
     * @return int
     */
    public function increment($key, $offset = 1)
    {
        $this->resultCode = 0;
        $this->resultMessage = '';
        
        $key = $this->getRealKey($key);
        $handle = $this->getConnection('', $key);
        if (false === fwrite($handle, "incr {$key} {$offset}\r\n")) return false;
        
        $newValue = rtrim(fgets($handle));
        if ('NOT_FOUND' === $newValue)
        {
            $this->resultCode = self::RES_NOTFOUND;
            $this->resultMessage = 'NOT FOUND';
            return false;
        }
        else return (int)$newValue;
    }// end method increment
    
    /**
     * 向已存在元素前追加数据
     *
     * @param string $key
     * @param string $value
     * @return bool
     */
    public function prepend($key, $value)
    {
        return $this->sendCommand_StorageData('prepend', $key, $value);
    }// end method prepend
    
    /**
     * 在指定服务器上向已存在元素前追加数据
     *
     * @param string $serverKey
     * @param string $key
     * @param string $value
     * @return bool
     */
    public function prependByKey($serverKey, $key, $value)
    {
        return $this->sendCommand_StorageData('prepend', $key, $value, $serverKey);
    }// end method prependByKey

    /**
     * 替换已经存在的元素的值
     *
     * @param string $key
     * @param mixed $value
     * @param int $expiration
     * @return bool
     */
    public function replace($key, $value, $expiration = 0)
    {
        return $this->sendCommand_StorageData('replace', $key, $value, $expiration);
    }// end method replace
    
    /**
     * 在指定服务器上替换已经存在的元素的值
     *
     * @param string $serverKey
     * @param string $key
     * @param mixed $value
     * @param int $expiration
     * @return bool
     */
    public function replaceByKey($serverKey, $key, $value, $expiration = 0)
    {
        return $this->sendCommand_StorageData('replace', $key, $value, $expiration, $serverKey);
    }// end method replaceByKey
    
    /**
     * 将数据存储在服务器上
     *
     * @param string $key
     * @param mixed $value
     * @param int $expiration
     * @return bool
     */
    public function set($key, $value, $expiration = 0)
    {
        return $this->sendCommand_StorageData('set', $key, $value, $expiration);
    }// end method set
    
    /**
     * 将数据存储在指定服务器上
     *
     * @param string $serverKey
     * @param string $key
     * @param mixed $value
     * @param int $expiration
     * @return bool
     */
    public function setByKey($serverKey, $key, $value, $expiration = 0)
    {
        return $this->sendCommand_StorageData('set', $key, $value, $expiration, $serverKey);
    }// end method setByKey
    
    /**
     * 将多个缓存项存储到服务器上
     *
     * @param array $items
     * @param int $expiration
     * @return bool
     */
    public function setMulti(array $items, $expiration = 0)
    {
        $this->resultCode = 0;
        $this->resultMessage = '';
        
        $flag = true;
        foreach ($items as $key => $value)
        {
           if (false === $this->sendCommand_StorageData('set', $key, $value, $expiration))
           {
               $flag = false;
           } 
        }
        return $flag;
    }// end method setMulti
    
    /**
     * 将多个缓存项存储到指定服务器上
     *
     * @param string $serverKey
     * @param array $items
     * @param int $expiration
     * @return bool
     */
    public function setMultiByKey($serverKey, array $items, $expiration = 0)
    {
        $this->resultCode = 0;
        $this->resultMessage = '';
        
        $flag = true;
        foreach ($items as $key => $value)
        {
           if (false === $this->sendCommand_StorageData('set', $key, $value, $expiration, $serverKey))
           {
               $flag = false;
           } 
        }
        return $flag;
    }// end method setMultiByKey
    
    /**
     * 设置 Memcached 选项
     *
     * @param int $option
     * @param mixed $value
     * @return bool
     */
    public function setOption($option, $value)
    {
        $this->options[$option] = $value;
    }// end method setOption
    
    /**
     * 批量设置Memcached 选项
     * @param array $options
     * @return boolean
     */
    public function setOptions(array $options)
    {
        foreach ($options as $option=>$value)
        {
            $this->options[$option] = $value;
        }    
    }//end method setOptions
    
}// end class Memcached

