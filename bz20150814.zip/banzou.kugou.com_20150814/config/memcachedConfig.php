<?php
return array(
	'memcachedServerList' => array(
		//array('192.168.10.52',11211,10,),//host , port , weight
		array('10.1.16.202',33211,10,),//host , port , weight
	),
	'memcachedServerOptions' => array(//memcached配置
		Memcached::OPT_SERVER_FAILURE_LIMIT=>3,//指定一个服务器连接的失败重试次数限制。在达到此数量的失败重连后此服务器将被从服务器池中移除
		Memcached::OPT_COMPRESSION=>false,//不启用压缩
		Memcached::OPT_SERIALIZER=>\Memcached::SERIALIZER_JSON_ARRAY,//配置memcached采用json序列化方式
		Memcached::OPT_PREFIX_KEY=>'fxtoken',
	),
);