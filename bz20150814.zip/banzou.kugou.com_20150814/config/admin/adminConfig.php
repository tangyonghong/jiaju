<?php
return array(
	'system' => array(//
		'titleName' => '系统', // 标题 , 顶级
		'menusList' => array(//二级标题列表
			'admin' => array(
				'menusName' => '管理员设置', //标题 , 二级
				'hrefList' => array(//三级标题列表
					array(
						'name' => '所有管理员', //标题 , 三级
						'href' => '/index.php?action=admin', //地址
						'attrs' => array(
							'id'=>'admin', //html属性 转化为  id="admin"
						),
					)
				),
			),
		),
	),
);