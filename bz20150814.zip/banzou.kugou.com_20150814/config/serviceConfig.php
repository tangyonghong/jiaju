<?php

$curDir = dirname(__FILE__)."/..";
return array(
	'app' => 'ServiceApp',//应用类名称
	'define' => array(//常量定义,可以覆盖框架原有的常量设定
		'MM_ROOT' => $curDir,
		'MM_CORE_ROOT' => $curDir . '/core',
		'MM_APP_ROOT' => $curDir.'/app',
// 		'MM_DEBUG' => 1, //是否开启调试
		'TABLE_PRE' => 't_', //表前缀
// 		'MM_APP_ACTION_DIR' => $curDir.'/app/apis', //action接口
		'LOG_PATH' => '/data1/logs/logdata/phpLog', //定义保存路径LOG_PATH常量
		'LOG_LEVEL' => 9 ,//0,1,2,3,9
	),
	'run' => array(//应用主入口，没有任何参数时进入
		'class'=>'servers',
		'function'=>'run',
	),
	
	'handler' => array(//错误捕捉函数
		'error' => 'mmErrorHandler',//错误捕捉函数
		'exception' => 'mmExceptionHandler',//异常捕捉函数
	),
	'errorReportLevel' => 0,//错误提示级别
	
	'includePath' => array(//需要导入的库目录，自动在对应的目录查找同名的$class.php文件
	),
	'autoIncludeFile' => array(//应用需要加载的文件,每次请求都会加载
		'MyHelper' => $curDir.'/app/MyHelper.php',
		'DailySongStat' => $curDir.'/app/bll/DailySongStat.php',
		'SimpleSHM' => $curDir.'/app/util/SimpleSHM.php',
		'Log' => $curDir.'/app/util/Log.php',
	),
	'db' => array(
		'host' => '10.1.2.22',
		'user' => 'fxbanzou_user',
		'pass' => 'fanseql@(!)end',
		'dbName' => 'd_fxbanzou',
		'port' => '3306',
		'charset' => 'utf8',
		'tablePre' => 't_',
	),
// 	'db' => array(
// 		'host' => '192.168.10.60',
// 		'user' => 'banzou',
// 		'pass' => 'kugou2013',
// 		'dbName' => 'd_fxbanzou',
// 		'port' => '3306',
// 		'charset' => 'utf8',
// 		'tablePre' => 't_',
// 	),
// 	'mysqlList' => array(
// 		array(
// 			'host' => 'localhost',
// 			'user' => 'root',
// 			'pass' => '123456',
// 			'dbName' => 'mm_test2',
// 			'port' => '3306',
// 			'charset' => 'utf8',
// 			'tablePre' => 'mm_',
// 		),
// 		array(
// 			'host' => 'localhost',
// 			'user' => 'root',
// 			'pass' => '123456',
// 			'dbName' => 'mm_test3',
// 			'port' => '3306',
// 			'charset' => 'utf8',
// 			'tablePre' => 'mm_',
// 		),
// 	),
	'switch' => array(//开关配置
		'*' => 0,//除下面设定的开关外的所有开关的权限
		'trace' => 1,//调试堆栈
		'sql' => 1,//调试SQL - 依赖trace
		'includeFile' => 1,//加载文件 - 依赖trace
		'time' => 1,//php执行时间 - 依赖trace
		'traceSystemVar' => array(//调试系统内置变量 - 依赖trace
			'post' => 0,//$_POST
			'get' => 0,//$_GET
			'cookie' => 0,//$_COOKIE
			'files' => 0,//$_FILES
			'server' => 0,//$_SERVER
		),
		'backTrace' => 0,//php的调用堆栈记录
		'traceDefine' => 0,//调试define - 依赖trace
	),
	'debugClass' => array(//设置输出调试类,会传入一个调试数组
		'class'=>'MmDebug',
		'in'=>'addTrace',
		'out' => 'getTrace',
		'show'=>'printData',
	),
	'actions' => array(
		'*' => false,//控制除下面设定的接口权限外的所有权限
		'api' => array('*'=>1),//defaultAction的所有接口可以访问
		'ac' => 1,
		'cv' => 1,
		'admin' => 1,
		'install' => 1,
//		'className' => array(//类1
//			'function1' => 1,	//function1:允许
//			'function2' => 0,	//function1:禁止
//		),
//		'action1' => 1, //action1允许访问
	),
	'streamServerIp' => '192.168.5.40',//流服务器地址,返回给flash
	'banzou_pre' => 'banzou_',//伴奏的log日志前缀
	'client_pre' => 'client_',//繁星客户端的日志前缀
	'hifi_pre' => 'hifi_',//高清插件的日志记录前缀
	'playSoftware_pre' => 'software_', //用户使用视频软件日志前缀
	'channel_pre' => 'channel_', //渠道日志前缀
	'func_pre' => 'func_', //用户功能使用记录的日志
	'behaviorLogPath' => '/data1/logs/logdata/behavior',//用户行为记录的目录
	'playSoftwareLogPath' => '/data1/logs/logdata/playSoftware',//用户使用视频录像设备
	'keydict' => '/data1/logs/logdata/temp/keys/keys' ,
	'keyMemoryId' => 1112,
	'channelLogPath' => '/data1/logs/logdata/channel',
	'RSAProgram' =>'/data1/logs/logdata/temp/keys/rsa',
	'artist_pre' => 'artist_',//艺人客户端
);