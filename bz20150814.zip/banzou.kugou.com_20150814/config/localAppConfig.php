<?php
$curDir = dirname(__FILE__)."/..";
return array(
	'app' => 'DefaultApp',//应用类名称
	'define' => array(//常量定义,可以覆盖框架原有的常量设定
		'MM_ROOT' => $curDir,
		'MM_CORE_ROOT' => $curDir . '/core',
		'MM_APP_ROOT' => $curDir.'/app',
		'MM_DEBUG' => 1, //是否开启调试
		'TABLE_PRE' => 't_', //表前缀
	),
	'run' => array(//应用主入口，没有任何参数时进入
		'class'=>'default',
		'function'=>'Index',
	),
	
//	'handler' => array(//错误捕捉函数
//		'error' => 'mmErrorHandler',//错误捕捉函数
//		'exception' => 'mmExceptionHandler',//异常捕捉函数
//	),
	'errorReportLevel' => E_ALL,//错误提示级别
	
	'includePath' => array(//需要导入的库目录，自动在对应的目录查找同名的$class.php文件
	),
	'autoIncludeFile' => array(//应用需要加载的文件,每次请求都会加载
		'MyHelper' => $curDir.'/app/MyHelper.php',
	),
		'db' => array(
				'host' => '192.168.10.52',
				'user' => 'banzou',
				'pass' => 'kugou2013',
				'dbName' => 'd_fxbanzou',
				'port' => '3306',
				'charset' => 'utf8',
				'tablePre' => 't_',
		),
// 	'db' => array(
// 		'host' => '192.168.10.60',
// 		'user' => 'banzou',
// 		'pass' => 'kugou2013',
// 		'dbName' => 'd_fxbanzou',
// 		'port' => '3306',
// 		'charset' => 'utf8',
// 		'tablePre' => 't_',
// 	),
// 	'mysqlList' => array(
// 		array(
// 			'host' => 'localhost',
// 			'user' => 'root',
// 			'pass' => '123456',
// 			'dbName' => 'mm_test2',
// 			'port' => '3306',
// 			'charset' => 'utf8',
// 			'tablePre' => 'mm_',
// 		),
// 		array(
// 			'host' => 'localhost',
// 			'user' => 'root',
// 			'pass' => '123456',
// 			'dbName' => 'mm_test3',
// 			'port' => '3306',
// 			'charset' => 'utf8',
// 			'tablePre' => 'mm_',
// 		),
// 	),
	'switch' => array(//开关配置
		'*' => 0,//除下面设定的开关外的所有开关的权限
		'trace' => 0,//调试堆栈
		'sql' => 1,//调试SQL - 依赖trace
		'includeFile' => 0,//加载文件 - 依赖trace
		'time' => 1,//php执行时间 - 依赖trace
		'traceSystemVar' => array(//调试系统内置变量 - 依赖trace
			'post' => 0,//$_POST
			'get' => 0,//$_GET
			'cookie' => 0,//$_COOKIE
			'files' => 0,//$_FILES
			'server' => 0,//$_SERVER
		),
		'backTrace' => 0,//php的调用堆栈记录
		'traceDefine' => 0,//调试define - 依赖trace
	),
	'debugClass' => array(//设置输出调试类,会传入一个调试数组
		'class'=>'MmDebug',
		'in'=>'addTrace',
		'out' => 'getTrace',
		'show'=>'printData',
	),
	'actions' => array(
		'*' => false,//控制除下面设定的接口权限外的所有权限
		'default' => array('*'=>1),//defaultAction的所有接口可以访问
		'token' => array('*'=>1),//defaultAction的所有接口可以访问
		'admin' => array('*'=>1),//adminAction的所有接口可以访问
		'adminManage' => array('*'=>1),//adminAction的所有接口可以访问
		'VerManage'=>array('*'=>1),
		'resource' => array('*'=>1),//adminAction的所有接口可以访问
		'ac' => 1,
		'cv' => 1,
		'admin' => 1,
		'install' => 1,
		'adminManage'=>1,
		'VerManage'=>1,
		'dbToCode' => 1,
//		'className' => array(//类1
//			'function1' => 1,	//function1:允许
//			'function2' => 0,	//function1:禁止
//		),
//		'action1' => 1, //action1允许访问
	),
);